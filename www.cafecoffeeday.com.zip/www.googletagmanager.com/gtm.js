// Copyright 2012 Google Inc. All rights reserved.

(function() {

    var data = {
        "resource": {
            "version": "3",

            "macros": [{
                "function": "__e"
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": false,
                "vtp_setTrackerName": false,
                "vtp_useDebugVersion": false,
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": false,
                "vtp_enableEcommerce": false,
                "vtp_trackingId": "UA-9107407-3",
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": true
            }, {
                "function": "__aev",
                "vtp_varType": "TEXT"
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementId",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementUrl",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementClasses",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }, {
                "function": "__v",
                "vtp_name": "gtm.element",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementTarget",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.element",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementClasses",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementId",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementTarget",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementUrl",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__aev",
                "vtp_varType": "TEXT"
            }, {
                "function": "__v",
                "vtp_name": "gtm.scrollThreshold",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.scrollUnits",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.visibleRatio",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.visibleTime",
                "vtp_dataLayerVersion": 1
            }],
            "tags": [{
                "function": "__gclidw",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_enableCrossDomain": false,
                "vtp_enableUrlPassthrough": false,
                "vtp_enableCookieOverrides": false,
                "vtp_enableCrossDomainFeature": true,
                "tag_id": 5
            }, {
                "function": "__awct",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_enableNewCustomerReporting": false,
                "vtp_enableConversionLinker": true,
                "vtp_enableProductReporting": false,
                "vtp_enableEnhancedConversion": false,
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_enableShippingData": false,
                "vtp_conversionId": "11081986475",
                "vtp_conversionLabel": "qr0zCOryo40YEKvjpqQp",
                "vtp_rdp": false,
                "vtp_url": ["macro", 2],
                "vtp_enableProductReportingCheckbox": true,
                "vtp_enableNewCustomerReportingCheckbox": true,
                "vtp_enableEnhancedConversionsCheckbox": false,
                "vtp_enableRdpCheckbox": true,
                "vtp_enableTransportUrl": false,
                "vtp_enableCustomParams": false,
                "tag_id": 7
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": false,
                "vtp_eventCategory": "Generic Click Listener",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 3],
                "vtp_eventAction": ["template", ["macro", 4], "|", ["macro", 5], "|", ["macro", 6], "|", ["macro", 7]],
                "vtp_eventLabel": ["macro", 1],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": true,
                "tag_id": 10
            }, {
                "function": "__cl",
                "tag_id": 11
            }],
            "predicates": [{
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "gtm.js"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "\/store-locator"
            }, {
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "gtm.click"
            }],
            "rules": [
                [
                    ["if", 0],
                    ["add", 0, 3]
                ],
                [
                    ["if", 0, 1],
                    ["add", 1]
                ],
                [
                    ["if", 2],
                    ["add", 2]
                ]
            ]
        },
        "runtime": []









    };


    var aa, da = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ea = function(a) {
            return a.raw = a
        },
        fa = function(a, b) {
            a.raw = b;
            return a
        },
        ha = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: da(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        ia = function(a) {
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        ja = "function" == typeof Object.create ? Object.create :
        function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ka;
    if ("function" == typeof Object.setPrototypeOf) ka = Object.setPrototypeOf;
    else {
        var la;
        a: {
            var ma = {
                    a: !0
                },
                na = {};
            try {
                na.__proto__ = ma;
                la = na.a;
                break a
            } catch (a) {}
            la = !1
        }
        ka = la ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var pa = ka,
        qa = function(a, b) {
            a.prototype = ja(b.prototype);
            a.prototype.constructor = a;
            if (pa) pa(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.ln = b.prototype
        };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var ra = this || self,
        sa = function(a) {
            return a
        };
    var ta = function() {},
        ua = function(a) {
            return "function" === typeof a
        },
        g = function(a) {
            return "string" === typeof a
        },
        va = function(a) {
            return "number" === typeof a && !isNaN(a)
        },
        xa = Array.isArray,
        ya = function(a, b) {
            if (a && xa(a))
                for (var c = 0; c < a.length; c++)
                    if (a[c] && b(a[c])) return a[c]
        },
        za = function(a, b) {
            if (!va(a) || !va(b) || a > b) a = 0, b = 2147483647;
            return Math.floor(Math.random() * (b - a + 1) + a)
        },
        Ca = function(a, b) {
            for (var c = new Ba, d = 0; d < a.length; d++) c.set(a[d], !0);
            for (var e = 0; e < b.length; e++)
                if (c.get(b[e])) return !0;
            return !1
        },
        k = function(a,
            b) {
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
        },
        Da = function(a) {
            return !!a && ("[object Arguments]" === Object.prototype.toString.call(a) || Object.prototype.hasOwnProperty.call(a, "callee"))
        },
        Ea = function(a) {
            return Math.round(Number(a)) || 0
        },
        Fa = function(a) {
            return "false" === String(a).toLowerCase() ? !1 : !!a
        },
        Ga = function(a) {
            var b = [];
            if (xa(a))
                for (var c = 0; c < a.length; c++) b.push(String(a[c]));
            return b
        },
        Ia = function(a) {
            return a ? a.replace(/^\s+|\s+$/g, "") : ""
        },
        Ja = function() {
            return new Date(Date.now())
        },
        Ka = function() {
            return Ja().getTime()
        },
        Ba = function() {
            this.prefix = "gtm.";
            this.values = {}
        };
    Ba.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    Ba.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    var La = function(a, b, c) {
            return a && a.hasOwnProperty(b) ? a[b] : c
        },
        Ma = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = void 0;
                    try {
                        c()
                    } catch (d) {}
                }
            }
        },
        Na = function(a, b) {
            for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
        },
        Oa = function(a, b) {
            for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
            return c
        },
        Pa = function(a, b) {
            return a.substring(0, b.length) === b
        },
        Qa = function(a, b) {
            for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
            d[e[e.length - 1]] = b;
            return c
        },
        Ra = /^\w{1,9}$/,
        Sa = function(a,
            b) {
            a = a || {};
            b = b || ",";
            var c = [];
            k(a, function(d, e) {
                Ra.test(d) && e && c.push(d)
            });
            return c.join(b)
        },
        Ta = function(a, b) {
            function c() {
                ++d === b && (e(), e = null, c.done = !0)
            }
            var d = 0,
                e = a;
            c.done = !1;
            return c
        };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
    var Ua = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        Va = function(a) {
            if (null == a) return String(a);
            var b = Ua.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        Xa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        Ya = function(a) {
            if (!a || "object" != Va(a) || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !Xa(a, "constructor") && !Xa(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return void 0 ===
                b || Xa(a, b)
        },
        z = function(a, b) {
            var c = b || ("array" == Va(a) ? [] : {}),
                d;
            for (d in a)
                if (Xa(a, d)) {
                    var e = a[d];
                    "array" == Va(e) ? ("array" != Va(c[d]) && (c[d] = []), c[d] = z(e, c[d])) : Ya(e) ? (Ya(c[d]) || (c[d] = {}), c[d] = z(e, c[d])) : c[d] = e
                }
            return c
        };
    var Za = function(a) {
        if (void 0 == a || xa(a) || Ya(a)) return !0;
        switch (typeof a) {
            case "boolean":
            case "number":
            case "string":
            case "function":
                return !0
        }
        return !1
    };

    function $a() {
        for (var a = ab, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function bb() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var ab, cb;

    function db(a) {
        ab = ab || bb();
        cb = cb || $a();
        for (var b = [], c = 0; c < a.length; c += 3) {
            var d = c + 1 < a.length,
                e = c + 2 < a.length,
                f = a.charCodeAt(c),
                h = d ? a.charCodeAt(c + 1) : 0,
                l = e ? a.charCodeAt(c + 2) : 0,
                m = f >> 2,
                n = (f & 3) << 4 | h >> 4,
                p = (h & 15) << 2 | l >> 6,
                q = l & 63;
            e || (q = 64, d || (p = 64));
            b.push(ab[m], ab[n], ab[p], ab[q])
        }
        return b.join("")
    }

    function eb(a) {
        function b(m) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = cb[n];
                if (null != p) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return m
        }
        ab = ab || bb();
        cb = cb || $a();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                h = b(64),
                l = b(64);
            if (64 === l && -1 === e) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            64 != h && (c += String.fromCharCode(f << 4 & 240 | h >> 2), 64 != l && (c += String.fromCharCode(h << 6 & 192 | l)))
        }
    };
    var fb = {},
        gb = function(a, b) {
            fb[a] = fb[a] || [];
            fb[a][b] = !0
        },
        hb = function() {
            delete fb.GA4_EVENT
        },
        ib = function(a) {
            var b = fb[a];
            if (!b || 0 === b.length) return "";
            for (var c = [], d = 0, e = 0; e < b.length; e++) 0 === e % 8 && 0 < e && (c.push(String.fromCharCode(d)), d = 0), b[e] && (d |= 1 << e % 8);
            0 < d && c.push(String.fromCharCode(d));
            return db(c.join("")).replace(/\.+$/, "")
        };
    var jb = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };
    var kb, lb = function() {
        if (void 0 === kb) {
            var a = null,
                b = ra.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: sa,
                        createScript: sa,
                        createScriptURL: sa
                    })
                } catch (c) {
                    ra.console && ra.console.error(c.message)
                }
                kb = a
            } else kb = a
        }
        return kb
    };
    var mb = function(a) {
        this.h = a
    };
    mb.prototype.toString = function() {
        return this.h + ""
    };
    var nb = {};
    var ob, pb;
    a: {
        for (var qb = ["CLOSURE_FLAGS"], rb = ra, sb = 0; sb < qb.length; sb++)
            if (rb = rb[qb[sb]], null == rb) {
                pb = null;
                break a
            }
        pb = rb
    }
    var tb = pb && pb[610401301];
    ob = null != tb ? tb : !1;

    function ub() {
        var a = ra.navigator;
        if (a) {
            var b = a.userAgent;
            if (b) return b
        }
        return ""
    }
    var vb, wb = ra.navigator;
    vb = wb ? wb.userAgentData || null : null;

    function xb(a) {
        return ob ? vb ? vb.brands.some(function(b) {
            var c = b.brand;
            return c && -1 != c.indexOf(a)
        }) : !1 : !1
    }

    function yb(a) {
        return -1 != ub().indexOf(a)
    };

    function zb() {
        return ob ? !!vb && 0 < vb.brands.length : !1
    }

    function Ab() {
        return zb() ? !1 : yb("Opera")
    }

    function Bb() {
        return yb("Firefox") || yb("FxiOS")
    }

    function Cb() {
        return zb() ? xb("Chromium") : (yb("Chrome") || yb("CriOS")) && !(zb() ? 0 : yb("Edge")) || yb("Silk")
    };
    var Db = {},
        Eb = function(a) {
            this.h = a
        };
    Eb.prototype.toString = function() {
        return this.h.toString()
    };
    var Fb = function(a) {
        return a instanceof Eb && a.constructor === Eb ? a.h : "type_error:SafeHtml"
    };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var Gb = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;

    function Hb(a) {
        var b = a.tagName;
        if ("SCRIPT" === b || "STYLE" === b) throw Error("");
    };
    var Ib = ea([""]),
        Jb = fa(["\x00"], ["\\0"]),
        Kb = fa(["\n"], ["\\n"]),
        Lb = fa(["\x00"], ["\\u0000"]);

    function Nb(a) {
        return -1 === a.toString().indexOf("`")
    }
    Nb(function(a) {
        return a(Ib)
    }) || Nb(function(a) {
        return a(Jb)
    }) || Nb(function(a) {
        return a(Kb)
    }) || Nb(function(a) {
        return a(Lb)
    });

    function Ob(a) {
        var b = a = Pb(a),
            c = lb(),
            d = c ? c.createHTML(b) : b;
        return new Eb(d, Db)
    }

    function Pb(a) {
        return null === a ? "null" : void 0 === a ? "undefined" : a
    };
    var C = window,
        F = document,
        Qb = navigator,
        Rb = F.currentScript && F.currentScript.src,
        Sb = function(a, b) {
            var c = C[a];
            C[a] = void 0 === c ? b : c;
            return C[a]
        },
        Tb = function(a, b) {
            b && (a.addEventListener ? a.onload = b : a.onreadystatechange = function() {
                a.readyState in {
                    loaded: 1,
                    complete: 1
                } && (a.onreadystatechange = null, b())
            })
        },
        Ub = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Vb = {
            onload: 1,
            src: 1,
            width: 1,
            height: 1,
            style: 1
        };

    function Wb(a, b, c) {
        b && k(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }
    var Xb = function(a, b, c, d, e) {
            var f = F.createElement("script");
            Wb(f, d, Ub);
            f.type = "text/javascript";
            f.async = d && !1 === d.async ? !1 : !0;
            var h, l = Pb(a),
                m = lb(),
                n = m ? m.createScriptURL(l) : l;
            h = new mb(n, nb);
            f.src = h instanceof mb && h.constructor === mb ? h.h : "type_error:TrustedResourceUrl";
            var p, q, t, r = null == (t = (q = (f.ownerDocument && f.ownerDocument.defaultView || window).document).querySelector) ? void 0 : t.call(q, "script[nonce]");
            (p = r ? r.nonce || r.getAttribute("nonce") || "" : "") && f.setAttribute("nonce", p);
            Tb(f, b);
            c && (f.onerror = c);
            if (e) e.appendChild(f);
            else {
                var u = F.getElementsByTagName("script")[0] || F.body || F.head;
                u.parentNode.insertBefore(f, u)
            }
            return f
        },
        Yb = function() {
            if (Rb) {
                var a = Rb.toLowerCase();
                if (0 === a.indexOf("https://")) return 2;
                if (0 === a.indexOf("http://")) return 3
            }
            return 1
        },
        Zb = function(a, b, c, d, e) {
            var f;
            f = void 0 === f ? !0 : f;
            var h = e,
                l = !1;
            h || (h = F.createElement("iframe"), l = !0);
            Wb(h, c, Vb);
            d && k(d, function(n, p) {
                h.dataset[n] = p
            });
            f && (h.height = "0", h.width = "0", h.style.display = "none", h.style.visibility = "hidden");
            if (l) {
                var m = F.body &&
                    F.body.lastChild || F.body || F.head;
                m.parentNode.insertBefore(h, m)
            }
            Tb(h, b);
            void 0 !== a && (h.src = a);
            return h
        },
        $b = function(a, b, c, d) {
            var e = new Image(1, 1);
            Wb(e, d, {});
            e.onload = function() {
                e.onload = null;
                b && b()
            };
            e.onerror = function() {
                e.onerror = null;
                c && c()
            };
            e.src = a
        },
        ac = function(a, b, c, d) {
            a.addEventListener ? a.addEventListener(b, c, !!d) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        bc = function(a, b, c) {
            a.removeEventListener ? a.removeEventListener(b, c, !1) : a.detachEvent && a.detachEvent("on" + b, c)
        },
        H = function(a) {
            C.setTimeout(a, 0)
        },
        cc = function(a, b) {
            return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value : null
        },
        dc = function(a) {
            var b = a.innerText || a.textContent || "";
            b && " " != b && (b = b.replace(/^[\s\xa0]+|[\s\xa0]+$/g, ""));
            b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
            return b
        },
        ec = function(a) {
            var b = F.createElement("div"),
                c = b,
                d = Ob("A<div>" + a + "</div>");
            1 === c.nodeType && Hb(c);
            c.innerHTML = Fb(d);
            b = b.lastChild;
            for (var e = []; b.firstChild;) e.push(b.removeChild(b.firstChild));
            return e
        },
        fc = function(a, b, c) {
            c = c || 100;
            for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
            for (var f = a, h = 0; f && h <= c; h++) {
                if (d[String(f.tagName).toLowerCase()]) return f;
                f = f.parentElement
            }
            return null
        },
        gc = function(a) {
            var b;
            try {
                b = Qb.sendBeacon && Qb.sendBeacon(a)
            } catch (c) {
                gb("TAGGING", 15)
            }
            b || $b(a)
        },
        hc = function(a, b) {
            var c = a[b];
            c && "string" === typeof c.animVal && (c = c.animVal);
            return c
        },
        ic = function(a) {
            var b = {
                headers: {
                    "Attribution-Reporting-Eligible": "trigger"
                },
                keepalive: !0,
                attributionReporting: {
                    eventSourceEligible: !0,
                    triggerEligible: !0
                }
            };
            try {
                C.fetch(a, b)
            } catch (c) {}
        },
        jc = function() {
            var a = C.performance;
            if (a && ua(a.now)) return a.now()
        },
        kc = function() {
            return C.performance || void 0
        };

    function lc(a) {
        switch (a) {
            case 1:
                return "1";
            case 2:
            case 4:
                return "0";
            default:
                return "-"
        }
    }

    function mc(a) {
        switch (a) {
            case 1:
                return "G";
            case 3:
                return "g";
            case 2:
                return "D";
            case 4:
                return "d";
            case 0:
                return "g";
            default:
                return "g"
        }
    }

    function nc(a, b) {
        var c = a[1] || 0,
            d = a[2] || 0;
        switch (b) {
            case 0:
                return "G1" + lc(c) + lc(d);
            case 1:
                return "G2" + mc(c) + mc(d);
            default:
                return "g1--"
        }
    };
    var oc = function() {
        var a = function(b) {
            return {
                toString: function() {
                    return b
                }
            }
        };
        return {
            Qi: a("consent"),
            zg: a("convert_case_to"),
            Ag: a("convert_false_to"),
            Bg: a("convert_null_to"),
            Cg: a("convert_true_to"),
            Dg: a("convert_undefined_to"),
            wm: a("debug_mode_metadata"),
            ma: a("function"),
            Kf: a("instance_name"),
            Uj: a("live_only"),
            Vj: a("malware_disabled"),
            Wj: a("metadata"),
            Zj: a("original_activity_id"),
            Mm: a("original_vendor_template_id"),
            Lm: a("once_on_load"),
            Yj: a("once_per_event"),
            Ih: a("once_per_load"),
            Qm: a("priority_override"),
            Rm: a("respected_consent_types"),
            Nh: a("setup_tags"),
            sd: a("tag_id"),
            Sh: a("teardown_tags")
        }
    }();
    var Lc;
    var Mc = [],
        Nc = [],
        Oc = [],
        Pc = [],
        Qc = [],
        Rc = {},
        Sc, Tc, Uc = function(a) {
            Tc = Tc || a
        },
        Vc = function(a) {},
        Wc, Xc = [],
        Yc = function(a, b) {
            var c = a[oc.ma],
                d = b && b.event;
            if (!c) throw Error("Error: No function name given for function call.");
            var e = Rc[c],
                f = b && 2 === b.type && d.reportMacroDiscrepancy && e && -1 !== Xc.indexOf(c),
                h = {},
                l = {},
                m;
            for (m in a) a.hasOwnProperty(m) && 0 === m.indexOf("vtp_") && (e && d && d.checkPixieIncompatibility && d.checkPixieIncompatibility(a[m]), e && (h[m] = a[m]), !e || f) && (l[m.substr(4)] = a[m]);
            e && d && d.cachedModelValues && (h.vtp_gtmCachedValues = d.cachedModelValues);
            if (b) {
                if (null == b.name) {
                    var n;
                    a: {
                        var p = b.index;
                        if (null == p) n = "";
                        else {
                            var q;
                            switch (b.type) {
                                case 2:
                                    q = Mc[p];
                                    break;
                                case 1:
                                    q = Pc[p];
                                    break;
                                default:
                                    n = "";
                                    break a
                            }
                            var t = q && q[oc.Kf];
                            n =
                                t ? String(t) : ""
                        }
                    }
                    b.name = n
                }
                e && (h.vtp_gtmEntityIndex = b.index, h.vtp_gtmEntityName = b.name)
            }
            var r, u;
            e && (r = e(h));
            if (!e || f) u = Lc(c, l, b);
            f && d && (Za(r) ? typeof r !== typeof u && d.reportMacroDiscrepancy(d.id, c) : r !== u && d.reportMacroDiscrepancy(d.id, c));
            return e ? r : u
        },
        $c = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = Zc(a[e], b, c));
            return d
        },
        Zc = function(a, b, c) {
            if (xa(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(Zc(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var h = Mc[f];
                        if (!h || b.isBlocked(h)) return;
                        c[f] = !0;
                        var l = String(h[oc.Kf]);
                        try {
                            var m = $c(h, b, c);
                            m.vtp_gtmEventId = b.id;
                            b.priorityId && (m.vtp_gtmPriorityId = b.priorityId);
                            d = Yc(m, {
                                event: b,
                                index: f,
                                type: 2,
                                name: l
                            });
                            Wc && (d = Wc.xk(d, m))
                        } catch (y) {
                            b.logMacroError && b.logMacroError(y, Number(f), l), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var n = 1; n < a.length; n += 2) d[Zc(a[n], b, c)] = Zc(a[n + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var p = !1, q = 1; q < a.length; q++) {
                            var t = Zc(a[q], b, c);
                            Tc &&
                                (p = p || Tc.pl(t));
                            d.push(t)
                        }
                        return Tc && p ? Tc.Ak(d) : d.join("");
                    case "escape":
                        d = Zc(a[1], b, c);
                        if (Tc && xa(a[1]) && "macro" === a[1][0] && Tc.ql(a)) return Tc.Pl(d);
                        d = String(d);
                        for (var r = 2; r < a.length; r++) pc[a[r]] && (d = pc[a[r]](d));
                        return d;
                    case "tag":
                        var u = a[1];
                        if (!Pc[u]) throw Error("Unable to resolve tag reference " + u + ".");
                        return d = {
                            di: a[2],
                            index: u
                        };
                    case "zb":
                        var v = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        v[oc.ma] = a[1];
                        var w = ad(v, b, c),
                            x = !!a[4];
                        return x || 2 !== w ? x !== (1 === w) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " +
                            a[0] + ".");
                }
            }
            return a
        },
        ad = function(a, b, c) {
            try {
                return Sc($c(a, b, c))
            } catch (d) {
                JSON.stringify(a)
            }
            return 2
        },
        bd = function(a) {
            var b = a[oc.ma];
            if (!b) throw Error("Error: No function name given for function call.");
            return !!Rc[b]
        };
    var ed = function(a) {
            function b(t) {
                for (var r = 0; r < t.length; r++) d[t[r]] = !0
            }
            for (var c = [], d = [], e = cd(a), f = 0; f < Nc.length; f++) {
                var h = Nc[f],
                    l = dd(h, e);
                if (l) {
                    for (var m = h.add || [], n = 0; n < m.length; n++) c[m[n]] = !0;
                    b(h.block || [])
                } else null === l && b(h.block || []);
            }
            for (var p = [], q = 0; q < Pc.length; q++) c[q] && !d[q] && (p[q] = !0);
            return p
        },
        dd = function(a, b) {
            for (var c = a["if"] || [], d = 0; d < c.length; d++) {
                var e = b(c[d]);
                if (0 === e) return !1;
                if (2 === e) return null
            }
            for (var f = a.unless || [], h = 0; h < f.length; h++) {
                var l = b(f[h]);
                if (2 === l) return null;
                if (1 === l) return !1
            }
            return !0
        },
        cd = function(a) {
            var b = [];
            return function(c) {
                void 0 === b[c] && (b[c] = ad(Oc[c], a));
                return b[c]
            }
        };
    var fd = {
        xk: function(a, b) {
            b[oc.zg] && "string" === typeof a && (a = 1 == b[oc.zg] ? a.toLowerCase() : a.toUpperCase());
            b.hasOwnProperty(oc.Bg) && null === a && (a = b[oc.Bg]);
            b.hasOwnProperty(oc.Dg) && void 0 === a && (a = b[oc.Dg]);
            b.hasOwnProperty(oc.Cg) && !0 === a && (a = b[oc.Cg]);
            b.hasOwnProperty(oc.Ag) && !1 === a && (a = b[oc.Ag]);
            return a
        }
    };
    var gd = [],
        hd = function(a) {
            return void 0 == gd[a] ? !1 : gd[a]
        };
    var vd = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"],
        wd = new Ba;
    var Dd = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;

    function Ed(a, b) {
        for (var c = "", d = !0; 7 < a;) {
            var e = a & 31;
            a >>= 5;
            d ? d = !1 : e |= 32;
            c = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [e] + c
        }
        a <<= 2;
        d || (a |= 32);
        return c = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [a | b] + c
    };
    var Gd = function(a) {
            return Fd ? F.querySelectorAll(a) : null
        },
        Hd = function(a, b) {
            if (!Fd) return null;
            if (Element.prototype.closest) try {
                return a.closest(b)
            } catch (e) {
                return null
            }
            var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
                d = a;
            if (!F.documentElement.contains(d)) return null;
            do {
                try {
                    if (c.call(d, b)) return d
                } catch (e) {
                    break
                }
                d = d.parentElement || d.parentNode
            } while (null !== d && 1 === d.nodeType);
            return null
        },
        Id = !1;
    if (F.querySelectorAll) try {
        var Jd = F.querySelectorAll(":root");
        Jd && 1 == Jd.length && Jd[0] == F.documentElement && (Id = !0)
    } catch (a) {}
    var Fd = Id;
    var K = function(a) {
        gb("GTM", a)
    };
    var Kd = function(a) {
            return null == a ? "" : g(a) ? Ia(String(a)) : "e0"
        },
        Md = function(a) {
            return a.replace(Ld, "")
        },
        Od = function(a) {
            return Nd(a.replace(/\s/g, ""))
        },
        Nd = function(a) {
            return Ia(a.replace(Pd, "").toLowerCase())
        },
        Rd = function(a) {
            a = a.replace(/[\s-()/.]/g, "");
            "+" !== a.charAt(0) && (a = "+" + a);
            return Qd.test(a) ? a : "e0"
        },
        Td = function(a) {
            var b = a.toLowerCase().split("@");
            if (2 == b.length) {
                var c = b[0];
                /^(gmail|googlemail)\./.test(b[1]) && (c = c.replace(/\./g, ""));
                c = c + "@" + b[1];
                if (Sd.test(c)) return c
            }
            return "e0"
        },
        Wd = function(a,
            b) {
            window.Promise || b([]);
            Promise.all(a.map(function(c) {
                return c.value && -1 !== Ud.indexOf(c.name) ? Vd(c.value).then(function(d) {
                    c.value = d
                }) : Promise.resolve()
            })).then(function() {
                b(a)
            }).catch(function() {
                b([])
            })
        },
        Vd = function(a) {
            if ("" === a || "e0" === a) return Promise.resolve(a);
            if (C.crypto && C.crypto.subtle) {
                if (Xd.test(a)) return Promise.resolve(a);
                try {
                    var b = Yd(a);
                    return C.crypto.subtle.digest("SHA-256", b).then(function(c) {
                        var d = Array.from(new Uint8Array(c)).map(function(e) {
                            return String.fromCharCode(e)
                        }).join("");
                        return C.btoa(d).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
                    }).catch(function() {
                        return "e2"
                    })
                } catch (c) {
                    return Promise.resolve("e2")
                }
            } else return Promise.resolve("e1")
        },
        Yd = function(a) {
            var b;
            if (C.TextEncoder) b = (new TextEncoder("utf-8")).encode(a);
            else {
                for (var c = [], d = 0; d < a.length; d++) {
                    var e = a.charCodeAt(d);
                    128 > e ? c.push(e) : 2048 > e ? c.push(192 | e >> 6, 128 | e & 63) : 55296 > e || 57344 <= e ? c.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : (e = 65536 + ((e & 1023) << 10 | a.charCodeAt(++d) & 1023), c.push(240 | e >> 18, 128 | e >> 12 & 63, 128 |
                        e >> 6 & 63, 128 | e & 63))
                }
                b = new Uint8Array(c)
            }
            return b
        },
        Pd = /[0-9`~!@#$%^&*()_\-+=:;<>,.?|/\\[\]]/g,
        Sd = /^\S+@\S+\.\S+$/,
        Qd = /^\+\d{10,15}$/,
        Ld = /[.~]/g,
        Zd = /^[0-9A-Za-z_-]{43}$/,
        Xd = /^[0-9A-Fa-f]{64}$/,
        $d = {},
        ae = ($d.email = "em", $d.phone_number = "pn", $d.first_name = "fn", $d.last_name = "ln", $d.street = "sa", $d.city = "ct", $d.region = "rg", $d.country = "co", $d.postal_code = "pc", $d.error_code = "ec", $d),
        be = {},
        ce = (be.email = "sha256_email_address", be.phone_number = "sha256_phone_number", be.first_name = "sha256_first_name", be.last_name =
            "sha256_last_name", be.street = "sha256_street", be),
        de = function(a, b) {
            function c(r, u, v, w) {
                var x = Kd(r);
                "" !== x && (Xd.test(x) ? m.push({
                    name: u,
                    value: x,
                    index: w
                }) : m.push({
                    name: u,
                    value: v(x),
                    index: w
                }))
            }

            function d(r, u) {
                var v = r;
                if (g(v) || xa(v)) {
                    v = xa(r) ? r : [r];
                    for (var w = 0; w < v.length; ++w) {
                        var x = Kd(v[w]),
                            y = Xd.test(x);
                        u && !y && K(89);
                        !u && y && K(88)
                    }
                }
            }

            function e(r, u) {
                var v = r[u];
                d(v, !1);
                var w = ce[u];
                r.hasOwnProperty(w) && (r.hasOwnProperty(u) && K(90), v = r[w], d(v, !0));
                return v
            }

            function f(r, u, v) {
                var w = e(r, u);
                w = xa(w) ? w : [w];
                for (var x =
                        0; x < w.length; ++x) c(w[x], u, v)
            }

            function h(r, u, v, w) {
                var x = e(r, u);
                c(x, u, v, w)
            }

            function l(r) {
                return function(u) {
                    K(64);
                    return r(u)
                }
            }
            var m = [];
            if ("https:" === C.location.protocol) {
                f(a, "email", Td);
                f(a, "phone_number", Rd);
                f(a, "first_name", l(Od));
                f(a, "last_name", l(Od));
                var n = a.home_address || {};
                f(n, "street", l(Nd));
                f(n, "city", l(Nd));
                f(n, "postal_code", l(Md));
                f(n, "region", l(Nd));
                f(n, "country", l(Md));
                var p = a.address || {};
                p = xa(p) ? p : [p];
                for (var q = 0; q < p.length; q++) {
                    var t = p[q];
                    h(t, "first_name", Od, q);
                    h(t, "last_name", Od, q);
                    h(t, "street", Nd, q);
                    h(t, "city", Nd, q);
                    h(t, "postal_code", Md, q);
                    h(t, "region", Nd, q);
                    h(t, "country", Md, q)
                }
                Wd(m, b)
            } else m.push({
                name: "error_code",
                value: "e3",
                index: void 0
            }), b(m)
        },
        ee = function(a, b) {
            de(a, function(c) {
                for (var d = ["tv.1"], e = 0, f = 0; f < c.length; ++f) {
                    var h = c[f].name,
                        l = c[f].value,
                        m = c[f].index,
                        n = ae[h];
                    n && l && (-1 === Ud.indexOf(h) || /^e\d+$/.test(l) || Zd.test(l) || Xd.test(l)) && (void 0 !== m && (n += m), d.push(n + "." + l), e++)
                }
                1 === c.length && "error_code" === c[0].name && (e = 0);
                b(encodeURIComponent(d.join("~")), e)
            })
        },
        fe = function(a) {
            if (C.Promise) try {
                return new Promise(function(b) {
                    ee(a,
                        function(c, d) {
                            b({
                                li: c,
                                Ml: d
                            })
                        })
                })
            } catch (b) {}
        },
        Ud = Object.freeze(["email", "phone_number", "first_name", "last_name", "street"]);
    var L = {
            g: {
                ya: "ad_personalization",
                H: "ad_storage",
                N: "ad_user_data",
                P: "analytics_storage",
                ac: "region",
                Sd: "consent_updated",
                jf: "wait_for_update",
                Ui: "ads",
                vm: "all",
                Vi: "maps",
                Wi: "playstore",
                Xi: "search",
                Yi: "shopping",
                Zi: "youtube",
                bj: "app_remove",
                cj: "app_store_refund",
                dj: "app_store_subscription_cancel",
                ej: "app_store_subscription_convert",
                fj: "app_store_subscription_renew",
                Eg: "add_payment_info",
                Fg: "add_shipping_info",
                bc: "add_to_cart",
                fc: "remove_from_cart",
                Gg: "view_cart",
                Gb: "begin_checkout",
                hc: "select_item",
                Xa: "view_item_list",
                jb: "select_promotion",
                Ya: "view_promotion",
                oa: "purchase",
                ic: "refund",
                Ba: "view_item",
                Hg: "add_to_wishlist",
                gj: "exception",
                ij: "first_open",
                jj: "first_visit",
                qa: "gtag.config",
                La: "gtag.get",
                kj: "in_app_purchase",
                jc: "page_view",
                lj: "screen_view",
                mj: "session_start",
                nj: "timing_complete",
                oj: "track_social",
                Td: "user_engagement",
                kb: "gclid",
                ra: "ads_data_redaction",
                X: "allow_ad_personalization_signals",
                pf: "allow_custom_scripts",
                qf: "allow_display_features",
                Ud: "allow_enhanced_conversions",
                Za: "allow_google_signals",
                Ca: "allow_interest_groups",
                pj: "app_id",
                qj: "app_installer_id",
                rj: "app_name",
                sj: "app_version",
                Hb: "auid",
                tj: "auto_detection_enabled",
                Ib: "aw_remarketing",
                rf: "aw_remarketing_only",
                Vd: "discount",
                Wd: "aw_feed_country",
                Xd: "aw_feed_language",
                Z: "items",
                Yd: "aw_merchant_id",
                Ig: "aw_basket_type",
                Hc: "campaign_content",
                Ic: "campaign_id",
                Jc: "campaign_medium",
                Kc: "campaign_name",
                Lc: "campaign",
                Mc: "campaign_source",
                Nc: "campaign_term",
                lb: "client_id",
                uj: "content_group",
                vj: "content_type",
                Ma: "conversion_cookie_prefix",
                kc: "conversion_id",
                Da: "conversion_linker",
                Jb: "conversion_api",
                Ra: "cookie_domain",
                Fa: "cookie_expires",
                Sa: "cookie_flags",
                mc: "cookie_name",
                Oc: "cookie_path",
                Na: "cookie_prefix",
                nb: "cookie_update",
                nc: "country",
                sa: "currency",
                Zd: "customer_lifetime_value",
                Pc: "custom_map",
                Jg: "gcldc",
                wj: "debug_mode",
                aa: "developer_id",
                xj: "disable_merchant_reported_purchases",
                Qc: "dc_custom_params",
                yj: "dc_natural_search",
                Kg: "dynamic_event_settings",
                Lg: "affiliation",
                ae: "checkout_option",
                tf: "checkout_step",
                Mg: "coupon",
                Rc: "item_list_name",
                uf: "list_name",
                zj: "promotions",
                Sc: "shipping",
                vf: "tax",
                be: "engagement_time_msec",
                ce: "enhanced_client_id",
                de: "enhanced_conversions",
                Ng: "enhanced_conversions_automatic_settings",
                ee: "estimated_delivery_date",
                wf: "euid_logged_in_state",
                Tc: "event_callback",
                Aj: "event_category",
                ob: "event_developer_id_string",
                Bj: "event_label",
                Og: "event",
                fe: "event_settings",
                he: "event_timeout",
                Cj: "description",
                Dj: "fatal",
                Ej: "experiments",
                xf: "firebase_id",
                ie: "first_party_collection",
                je: "_x_20",
                Kb: "_x_19",
                Pg: "fledge",
                Qg: "flight_error_code",
                Rg: "flight_error_message",
                Sg: "fl_activity_category",
                Tg: "fl_activity_group",
                yf: "fl_advertiser_id",
                Ug: "fl_ar_dedupe",
                Vg: "fl_random_number",
                Wg: "tran",
                Xg: "u",
                ke: "gac_gclid",
                oc: "gac_wbraid",
                Yg: "gac_wbraid_multiple_conversions",
                Zg: "ga_restrict_domain",
                ah: "ga_temp_client_id",
                me: "gdpr_applies",
                bh: "geo_granularity",
                pb: "value_callback",
                cb: "value_key",
                zm: "google_ono",
                Lb: "google_signals",
                eh: "google_tld",
                ne: "groups",
                fh: "gsa_experiment_id",
                gh: "iframe_state",
                Uc: "ignore_referrer",
                zf: "internal_traffic_results",
                rb: "is_legacy_converted",
                sb: "is_legacy_loaded",
                oe: "is_passthrough",
                pe: "_lps",
                Ga: "language",
                Af: "legacy_developer_id_string",
                Ha: "linker",
                Vc: "accept_incoming",
                Mb: "decorate_forms",
                T: "domains",
                qc: "url_position",
                hh: "method",
                Fj: "name",
                Wc: "new_customer",
                ih: "non_interaction",
                Gj: "optimize_id",
                Hj: "page_hostname",
                Xc: "page_path",
                Ia: "page_referrer",
                tb: "page_title",
                jh: "passengers",
                kh: "phone_conversion_callback",
                Ij: "phone_conversion_country_code",
                lh: "phone_conversion_css_class",
                Jj: "phone_conversion_ids",
                mh: "phone_conversion_number",
                nh: "phone_conversion_options",
                Bf: "_protected_audience_enabled",
                Yc: "quantity",
                qe: "redact_device_info",
                Cf: "referral_exclusion_definition",
                Nb: "restricted_data_processing",
                Kj: "retoken",
                Lj: "sample_rate",
                Df: "screen_name",
                ub: "screen_resolution",
                Mj: "search_term",
                Oa: "send_page_view",
                Ob: "send_to",
                Zc: "server_container_url",
                ad: "session_duration",
                se: "session_engaged",
                Ef: "session_engaged_time",
                vb: "session_id",
                te: "session_number",
                bd: "delivery_postal_code",
                Am: "temporary_client_id",
                Ff: "topmost_url",
                Nj: "tracking_id",
                Gf: "traffic_type",
                wa: "transaction_id",
                Pb: "transport_url",
                oh: "trip_type",
                Qb: "update",
                wb: "url_passthrough",
                dd: "_user_agent_architecture",
                ed: "_user_agent_bitness",
                fd: "_user_agent_full_version_list",
                gd: "_user_agent_mobile",
                hd: "_user_agent_model",
                jd: "_user_agent_platform",
                kd: "_user_agent_platform_version",
                ld: "_user_agent_wow64",
                Aa: "user_data",
                ph: "user_data_auto_latency",
                qh: "user_data_auto_meta",
                rh: "user_data_auto_multi",
                sh: "user_data_auto_selectors",
                th: "user_data_auto_status",
                ve: "user_data_mode",
                we: "user_data_settings",
                Pa: "user_id",
                Ta: "user_properties",
                uh: "_user_region",
                vh: "us_privacy_string",
                fa: "value",
                sc: "wbraid",
                wh: "wbraid_multiple_conversions",
                Ch: "_host_name",
                Dh: "_in_page_command",
                Eh: "_is_passthrough_cid",
                vc: "non_personalized_ads",
                rd: "_sst_parameters",
                ab: "conversion_label",
                za: "page_location",
                qb: "global_developer_id_string",
                ue: "tc_privacy_string"
            }
        },
        ge = {},
        he = Object.freeze((ge[L.g.X] = 1, ge[L.g.qf] = 1, ge[L.g.Ud] = 1, ge[L.g.Za] = 1, ge[L.g.Z] = 1, ge[L.g.Ra] = 1, ge[L.g.Fa] = 1, ge[L.g.Sa] = 1, ge[L.g.mc] = 1, ge[L.g.Oc] = 1, ge[L.g.Na] = 1, ge[L.g.nb] = 1, ge[L.g.Pc] = 1, ge[L.g.aa] =
            1, ge[L.g.Kg] = 1, ge[L.g.Tc] = 1, ge[L.g.fe] = 1, ge[L.g.he] = 1, ge[L.g.ie] = 1, ge[L.g.Zg] = 1, ge[L.g.Lb] = 1, ge[L.g.eh] = 1, ge[L.g.ne] = 1, ge[L.g.zf] = 1, ge[L.g.rb] = 1, ge[L.g.sb] = 1, ge[L.g.Ha] = 1, ge[L.g.Cf] = 1, ge[L.g.Nb] = 1, ge[L.g.Oa] = 1, ge[L.g.Ob] = 1, ge[L.g.Zc] = 1, ge[L.g.ad] = 1, ge[L.g.Ef] = 1, ge[L.g.bd] = 1, ge[L.g.Pb] = 1, ge[L.g.Qb] = 1, ge[L.g.we] = 1, ge[L.g.Ta] = 1, ge[L.g.rd] = 1, ge));
    Object.freeze([L.g.za, L.g.Ia, L.g.tb, L.g.Ga, L.g.Df, L.g.Pa, L.g.xf, L.g.uj]);
    var ie = {},
        je = Object.freeze((ie[L.g.bj] = 1, ie[L.g.cj] = 1, ie[L.g.dj] = 1, ie[L.g.ej] = 1, ie[L.g.fj] = 1, ie[L.g.ij] = 1, ie[L.g.jj] = 1, ie[L.g.kj] = 1, ie[L.g.mj] = 1, ie[L.g.Td] = 1, ie)),
        ke = {},
        le = Object.freeze((ke[L.g.Eg] = 1, ke[L.g.Fg] = 1, ke[L.g.bc] = 1, ke[L.g.fc] = 1, ke[L.g.Gg] = 1, ke[L.g.Gb] = 1, ke[L.g.hc] = 1, ke[L.g.Xa] = 1, ke[L.g.jb] = 1, ke[L.g.Ya] = 1, ke[L.g.oa] = 1, ke[L.g.ic] = 1, ke[L.g.Ba] = 1, ke[L.g.Hg] = 1, ke)),
        me = Object.freeze([L.g.X, L.g.Za, L.g.nb, L.g.Uc, L.g.Qb]),
        ne = Object.freeze([].concat(me)),
        oe = Object.freeze([L.g.Fa, L.g.he, L.g.ad, L.g.Ef,
            L.g.be
        ]),
        pe = Object.freeze([].concat(oe)),
        qe = {},
        re = (qe[L.g.H] = "1", qe[L.g.P] = "2", qe[L.g.N] = "3", qe[L.g.ya] = "4", qe),
        se = {},
        te = Object.freeze((se[L.g.X] = 1, se[L.g.Ud] = 1, se[L.g.Ca] = 1, se[L.g.Ib] = 1, se[L.g.rf] = 1, se[L.g.Vd] = 1, se[L.g.Wd] = 1, se[L.g.Xd] = 1, se[L.g.Z] = 1, se[L.g.Yd] = 1, se[L.g.Ma] = 1, se[L.g.Da] = 1, se[L.g.Ra] = 1, se[L.g.Fa] = 1, se[L.g.Sa] = 1, se[L.g.Na] = 1, se[L.g.sa] = 1, se[L.g.Zd] = 1, se[L.g.aa] = 1, se[L.g.xj] = 1, se[L.g.de] = 1, se[L.g.ee] = 1, se[L.g.xf] = 1, se[L.g.ie] = 1, se[L.g.rb] = 1, se[L.g.sb] = 1, se[L.g.Ga] = 1, se[L.g.Wc] = 1, se[L.g.za] =
            1, se[L.g.Ia] = 1, se[L.g.kh] = 1, se[L.g.lh] = 1, se[L.g.mh] = 1, se[L.g.nh] = 1, se[L.g.Nb] = 1, se[L.g.Oa] = 1, se[L.g.Ob] = 1, se[L.g.Zc] = 1, se[L.g.bd] = 1, se[L.g.wa] = 1, se[L.g.Pb] = 1, se[L.g.Qb] = 1, se[L.g.wb] = 1, se[L.g.Aa] = 1, se[L.g.Pa] = 1, se[L.g.fa] = 1, se)),
        ve = {},
        we = Object.freeze((ve[L.g.Xi] = "s", ve[L.g.Zi] = "y", ve[L.g.Wi] = "p", ve[L.g.Yi] = "h", ve[L.g.Ui] = "a", ve[L.g.Vi] = "m", ve));
    Object.freeze(L.g);
    var xe = {},
        ye = C.google_tag_manager = C.google_tag_manager || {},
        ze = Math.random();
    xe.Lf = "3b60";
    xe.qd = Number("0") || 0;
    xe.da = "dataLayer";
    xe.Si = "ChAIgN2nqgYQv8fopPq/+LIYEiQAbuwYeItyF3lRULOVkabQ8YiZvKDiGXy+c0eSWroeoigVJ3kaAmt0";
    var Ae = {
            __cl: 1,
            __ecl: 1,
            __ehl: 1,
            __evl: 1,
            __fal: 1,
            __fil: 1,
            __fsl: 1,
            __hl: 1,
            __jel: 1,
            __lcl: 1,
            __sdl: 1,
            __tl: 1,
            __ytl: 1
        },
        Be = {
            __paused: 1,
            __tg: 1
        },
        Ce;
    for (Ce in Ae) Ae.hasOwnProperty(Ce) && (Be[Ce] = 1);
    var De = Fa(""),
        Ee, Fe = !1;
    Ee = Fe;
    var Ge, He = !1;
    Ge = He;
    var Ie, Je = !1;
    Ie = Je;
    var Ke, Le = !1;
    Ke = Le;
    xe.Gc = "www.googletagmanager.com";
    var Me = "" + xe.Gc + (Ee ? "/gtag/js" : "/gtm.js"),
        Ne = null,
        Oe = null,
        Pe = {},
        Qe = {},
        Re = {},
        Se = function() {
            var a = ye.sequence || 1;
            ye.sequence = a + 1;
            return a
        };
    xe.Ri = "";
    var Te = "";
    xe.De = Te;
    var Ue = new Ba,
        Ve = {},
        We = {},
        Ze = {
            name: xe.da,
            set: function(a, b) {
                z(Qa(a, b), Ve);
                Xe()
            },
            get: function(a) {
                return Ye(a, 2)
            },
            reset: function() {
                Ue = new Ba;
                Ve = {};
                Xe()
            }
        },
        Ye = function(a, b) {
            return 2 != b ? Ue.get(a) : $e(a)
        },
        $e = function(a) {
            var b, c = a.split(".");
            b = b || [];
            for (var d = Ve, e = 0; e < c.length; e++) {
                if (null === d) return !1;
                if (void 0 === d) break;
                d = d[c[e]];
                if (-1 !== b.indexOf(d)) return
            }
            return d
        },
        af = function(a, b) {
            We.hasOwnProperty(a) || (Ue.set(a, b), z(Qa(a, b), Ve), Xe())
        },
        Xe = function(a) {
            k(We, function(b, c) {
                Ue.set(b, c);
                z(Qa(b), Ve);
                z(Qa(b,
                    c), Ve);
                a && delete We[b]
            })
        },
        bf = function(a, b) {
            var c, d = 1 !== (void 0 === b ? 2 : b) ? $e(a) : Ue.get(a);
            "array" === Va(d) || "object" === Va(d) ? c = z(d) : c = d;
            return c
        };
    var cf = function(a, b, c) {
            if (!c) return !1;
            var d = c.selector_type,
                e = String(c.value),
                f;
            if ("js_variable" === d) {
                e = e.replace(/\["?'?/g, ".").replace(/"?'?\]/g, "");
                for (var h = e.split(","), l = 0; l < h.length; l++) {
                    var m = h[l].trim();
                    if (m) {
                        if (0 === m.indexOf("dataLayer.")) f = Ye(m.substring(10));
                        else {
                            var n = m.split(".");
                            f = C[n.shift()];
                            for (var p = 0; p < n.length; p++) f = f && f[n[p]]
                        }
                        if (void 0 !== f) break
                    }
                }
            } else if ("css_selector" === d && Fd) {
                var q = Gd(e);
                if (q && 0 < q.length) {
                    f = [];
                    for (var t = 0; t < q.length && t < ("email" === b || "phone_number" === b ? 5 : 1); t++) f.push(dc(q[t]) ||
                        Ia(q[t].value));
                    f = 1 === f.length ? f[0] : f
                }
            }
            return f ? (a[b] = f, !0) : !1
        },
        df = function(a) {
            if (a) {
                var b = {},
                    c = !1;
                c = cf(b, "email", a.email) || c;
                c = cf(b, "phone_number", a.phone) || c;
                b.address = [];
                for (var d = a.name_and_address || [], e = 0; e < d.length; e++) {
                    var f = {};
                    c = cf(f, "first_name", d[e].first_name) || c;
                    c = cf(f, "last_name", d[e].last_name) || c;
                    c = cf(f, "street", d[e].street) || c;
                    c = cf(f, "city", d[e].city) || c;
                    c = cf(f, "region", d[e].region) || c;
                    c = cf(f, "country", d[e].country) || c;
                    c = cf(f, "postal_code", d[e].postal_code) || c;
                    b.address.push(f)
                }
                return c ?
                    b : void 0
            }
        },
        ef = function(a) {
            return Ya(a) ? !!a.enable_code : !1
        };
    var ff = function(a) {
            var b = a && a[L.g.Ng];
            return b && b[L.g.tj]
        },
        gf = function() {
            return -1 !== Qb.userAgent.toLowerCase().indexOf("firefox")
        },
        hf = function(a) {
            if (a && a.length) {
                for (var b = [], c = 0; c < a.length; ++c) {
                    var d = a[c];
                    d && d.estimated_delivery_date ? b.push("" + d.estimated_delivery_date) :
                        b.push("")
                }
                return b.join(",")
            }
        };
    var jf = function(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; 0 <= d; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = 0 !== c ? b ^ c >> 21 : b;
        return b
    };
    var kf = [];

    function lf(a) {
        switch (a) {
            case 35:
                return 3;
            case 61:
                return 14;
            case 62:
                return 8;
            case 74:
                return 11;
            case 75:
                return 12;
            case 78:
                return 10;
            case 80:
                return 13;
            case 76:
                return 15
        }
    }

    function N(a) {
        kf[a] = !0;
        var b = lf(a);
        b && (gd[b] = !0)
    }
    N(5);
    N(6);
    N(11);
    N(7);
    N(8);
    N(19);
    N(9);
    N(10);
    N(13);
    N(14);
    N(15);
    N(22);
    N(17);
    N(23);
    N(26);
    N(27);
    N(28);
    N(29);
    N(30);
    N(31);
    N(33);
    N(34);
    N(37);
    N(39);
    N(43);
    N(44);
    N(45);
    N(47);
    N(48);
    N(52);
    N(55);
    N(57);
    N(58);
    N(59);
    N(60);
    N(63);
    N(64);
    N(65);
    N(67);
    N(68);
    N(69);
    N(71);
    N(76);
    N(78);
    N(79);
    N(82);
    N(84);
    N(89);
    N(95);

    function P(a) {
        return !!kf[a]
    }
    var mf = !1;

    function nf(a) {}
    var of = Number('1');
    var pf = function(a) {
        gb("HEALTH", a)
    };
    var qf;
    try {
        qf = JSON.parse(eb("eyIwIjoiSU4iLCIxIjoiSU4tS0EiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jby5pbiIsIjQiOiIiLCI1Ijp0cnVlLCI2IjpmYWxzZSwiNyI6ImFkX3N0b3JhZ2V8YW5hbHl0aWNzX3N0b3JhZ2V8YWRfdXNlcl9kYXRhfGFkX3BlcnNvbmFsaXphdGlvbiJ9"))
    } catch (a) {
        K(123), pf(2), qf = {}
    }
    var rf = function() {
            return qf["0"] || ""
        },
        sf = function() {
            var a = !1;
            return a
        },
        tf = function() {
            var a = "";
            return a
        },
        uf = function() {
            var a = !1;
            a = !!qf["5"];
            return a
        },
        vf = function() {
            var a = "";
            return a
        };
    var wf = new function(a, b) {
        this.h = a;
        this.defaultValue = void 0 === b ? !1 : b
    }(1933);
    var xf = function(a) {
        xf[" "](a);
        return a
    };
    xf[" "] = function() {};
    var zf = function() {
        var a = yf,
            b = "Yf";
        if (a.Yf && a.hasOwnProperty(b)) return a.Yf;
        var c = new a;
        return a.Yf = c
    };
    var yf = function() {
        var a = {};
        this.h = function() {
            var b = wf.h,
                c = wf.defaultValue;
            return null != a[b] ? a[b] : c
        };
        this.C = function() {
            a[wf.h] = !0
        }
    };
    var Af = !1,
        Bf = !1,
        Cf = {},
        Df = {
            ad_storage: !1,
            ad_user_data: !1,
            ad_personalization: !1
        };

    function Ef() {
        var a = Sb("google_tag_data", {});
        return a.ics = a.ics || new Ff
    }
    var Ff = function() {
        this.entries = {};
        this.cps = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedSetCps = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.h = []
    };
    Ff.prototype.default = function(a, b, c, d, e, f) {
        this.usedDefault || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        gb("TAGGING", 19);
        void 0 == b ? gb("TAGGING", 18) : Gf(this, a, "granted" === b, c, d, e, f)
    };
    Ff.prototype.waitForUpdate = function(a, b) {
        for (var c = 0; c < a.length; c++) Gf(this, a[c], void 0, void 0, "", "", b)
    };
    var Gf = function(a, b, c, d, e, f, h) {
        var l = a.entries,
            m = l[b] || {},
            n = m.region,
            p = d && g(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (Kf(p, n, e, f)) {
            var q = !!(h && 0 < h && void 0 === m.update),
                t = {
                    region: p,
                    declare_region: m.declare_region,
                    implicit: m.implicit,
                    default: void 0 !== c ? c : m.default,
                    declare: m.declare,
                    update: m.update,
                    quiet: q
                };
            if ("" !== e || !1 !== m.default) l[b] = t;
            q && C.setTimeout(function() {
                l[b] === t && t.quiet && (gb("TAGGING", 2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0), a.notifyListeners())
            }, h)
        }
    };
    aa = Ff.prototype;
    aa.clearTimeout = function(a, b) {
        var c = [a],
            d;
        for (d in Cf) Cf.hasOwnProperty(d) && Cf[d] === a && c.push(d);
        var e = this.entries[a] || {},
            f = this.getConsentState(a);
        if (e.quiet) {
            e.quiet = !1;
            for (var h = ha(c), l = h.next(); !l.done; l = h.next()) Lf(this, l.value)
        } else if (void 0 !== b && f !== b) {
            var m = ha(c);
            for (l = m.next(); !l.done; l = m.next()) Lf(this, l.value)
        }
    };
    aa.update = function(a, b) {
        this.usedDefault || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (void 0 != b) {
            var c = this.getConsentState(a),
                d = this.entries;
            (d[a] = d[a] || {}).update = "granted" === b;
            this.clearTimeout(a, c)
        }
    };
    aa.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = this.entries,
            h = f[a] || {},
            l = h.declare_region,
            m = c && g(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (Kf(m, l, d, e)) {
            var n = {
                region: h.region,
                declare_region: m,
                declare: "granted" === b,
                implicit: h.implicit,
                default: h.default,
                update: h.update,
                quiet: h.quiet
            };
            if ("" !== d || !1 !== h.declare) f[a] = n
        }
    };
    aa.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = this.entries,
            d = c[a] = c[a] || {};
        !1 !== d.implicit && (d.implicit = "granted" === b)
    };
    aa.getConsentState = function(a) {
        var b = this.entries,
            c = b[a] || {},
            d = c.update;
        if (void 0 !== d) return d ? 1 : 2;
        d = c.default;
        if (void 0 !== d) return d ? 1 : 2;
        if (Cf.hasOwnProperty(a)) {
            var e = b[Cf[a]] || {};
            d = e.update;
            if (void 0 !== d) return d ? 1 : 2;
            d = e.default;
            if (void 0 !== d) return d ? 1 : 2
        }
        d = c.declare;
        if (void 0 !== d) return d ? 1 : 2;
        if (hd(3)) {
            d = c.implicit;
            if (void 0 !== d) return d ? 3 : 4;
            if (Df.hasOwnProperty(a)) return Df[a] ? 3 : 4
        }
        return 0
    };
    aa.setCps = function(a, b, c, d, e) {
        var f;
        a: {
            var h = this.cps,
                l, m = h[a] || {},
                n = m.region,
                p = c && g(c) ? c.toUpperCase() : void 0;l = d.toUpperCase();
            if (Kf(p, n, l, e.toUpperCase())) {
                var q = {
                    enabled: "granted" === b,
                    region: p
                };
                if ("" !== l || !1 !== m.enabled) {
                    h[a] = q;
                    f = !0;
                    break a
                }
            }
            f = !1
        }
        f && (this.usedSetCps = !0)
    };
    aa.addListener = function(a, b) {
        this.h.push({
            consentTypes: a,
            Hk: b
        })
    };
    var Lf = function(a, b) {
        for (var c = 0; c < a.h.length; ++c) {
            var d = a.h[c];
            xa(d.consentTypes) && -1 !== d.consentTypes.indexOf(b) && (d.ri = !0)
        }
    };
    Ff.prototype.notifyListeners = function(a, b) {
        for (var c = 0; c < this.h.length; ++c) {
            var d = this.h[c];
            if (d.ri) {
                d.ri = !1;
                try {
                    d.Hk({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };

    function Kf(a, b, c, d) {
        return "" === c || a === d ? !0 : a === c ? b !== d : !a && !b
    }
    var Mf = function(a) {
            var b = Ef();
            b.accessedAny = !0;
            return (g(a) ? [a] : a).every(function(c) {
                switch (b.getConsentState(c)) {
                    case 1:
                    case 3:
                        return !0;
                    case 2:
                    case 4:
                        return !1;
                    default:
                        return !0
                }
            })
        },
        Nf = function(a) {
            var b = Ef();
            b.accessedAny = !0;
            return b.getConsentState(a)
        },
        Of = function(a) {
            var b = Ef();
            b.accessedAny = !0;
            return !(b.entries[a] || {}).quiet
        },
        Pf = function() {
            if (!zf().h()) return !1;
            var a = Ef();
            a.accessedAny = !0;
            return a.active
        },
        Qf = function() {
            var a = Ef();
            a.accessedDefault = !0;
            return a.usedDefault
        },
        Rf = function(a, b) {
            Ef().addListener(a,
                b)
        },
        Sf = function(a, b) {
            Ef().notifyListeners(a, b)
        },
        Tf = function(a, b) {
            function c() {
                for (var e = 0; e < b.length; e++)
                    if (!Of(b[e])) return !0;
                return !1
            }
            if (c()) {
                var d = !1;
                Rf(b, function(e) {
                    d || c() || (d = !0, a(e))
                })
            } else a({})
        },
        Uf = function(a, b) {
            function c() {
                for (var l = [], m = 0; m < e.length; m++) {
                    var n = e[m];
                    Mf(n) && !f[n] && l.push(n)
                }
                return l
            }

            function d(l) {
                for (var m = 0; m < l.length; m++) f[l[m]] = !0
            }
            var e = g(b) ? [b] : b,
                f = {},
                h = c();
            h.length !== e.length && (d(h), Rf(e, function(l) {
                function m(q) {
                    0 !== q.length && (d(q), l.consentTypes = q, a(l))
                }
                var n = c();
                if (0 !== n.length) {
                    var p = Object.keys(f).length;
                    n.length + p >= e.length ? m(n) : C.setTimeout(function() {
                        m(c())
                    }, 500)
                }
            }))
        };

    function Vf() {}

    function Wf() {};
    var Xf = [L.g.H, L.g.P, L.g.N, L.g.ya],
        Yf = function(a) {
            for (var b = a[L.g.ac], c = Array.isArray(b) ? b : [b], d = {
                    Cd: 0
                }; d.Cd < c.length; d = {
                    Cd: d.Cd
                }, ++d.Cd) k(a, function(e) {
                return function(f, h) {
                    if (f !== L.g.ac) {
                        var l = c[e.Cd],
                            m = rf(),
                            n = qf["1"] || "";
                        Bf = !0;
                        Af && gb("TAGGING", 20);
                        Ef().declare(f, h, l, m, n)
                    }
                }
            }(d))
        },
        Zf = function(a) {
            var b = a[L.g.ac];
            b && K(40);
            var c = a[L.g.jf];
            c && K(41);
            for (var d = xa(b) ? b : [b], e = {
                    Dd: 0
                }; e.Dd < d.length; e = {
                    Dd: e.Dd
                }, ++e.Dd) k(a, function(f) {
                return function(h, l) {
                    if (h !== L.g.ac && h !== L.g.jf) {
                        var m = d[f.Dd],
                            n = Number(c),
                            p = rf(),
                            q = qf["1"] || "";
                        Af = !0;
                        Bf && gb("TAGGING", 20);
                        Ef().default(h, l, m, p, q, n)
                    }
                }
            }(e))
        },
        $f = function(a, b) {
            k(a, function(c, d) {
                Af = !0;
                Bf && gb("TAGGING", 20);
                Ef().update(c, d)
            });
            Sf(b.eventId, b.priorityId)
        },
        ag = function(a) {
            for (var b = a[L.g.ac], c = Array.isArray(b) ? b : [b], d = {
                    Ed: 0
                }; d.Ed < c.length; d = {
                    Ed: d.Ed
                }, ++d.Ed) k(a, function(e) {
                return function(f, h) {
                    if (f !== L.g.ac) {
                        var l = c[e.Ed],
                            m = rf(),
                            n = qf["1"] || "";
                        Ef().setCps(f, h, l, m, n)
                    }
                }
            }(d))
        },
        R = function(a) {
            Array.isArray(a) || (a = [a]);
            return a.every(function(b) {
                return Mf(b)
            })
        },
        bg = function(a,
            b) {
            Uf(a, b)
        },
        cg = function(a, b) {
            Tf(a, b)
        },
        dg = function() {
            var a = [L.g.H, L.g.ya, L.g.N];
            Ef().waitForUpdate(a, 500)
        },
        eg = function(a) {
            for (var b = ha(a), c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                Ef().clearTimeout(d, void 0)
            }
            Sf()
        };
    var fg = function(a) {
            var b = String(a[oc.ma] || "").replace(/_/g, "");
            0 === b.indexOf("cvt") && (b = "cvt");
            return b
        },
        gg = 0 <= C.location.search.indexOf("?gtm_latency=") || 0 <= C.location.search.indexOf("&gtm_latency=");
    var ig = function(a) {
            var b = hg();
            b.pending || (b.pending = []);
            ya(b.pending, function(c) {
                return c.target.ctid === a.ctid && c.target.isDestination === a.isDestination
            }) || b.pending.push({
                target: a,
                onLoad: void 0
            })
        },
        jg = function() {
            this.container = {};
            this.destination = {};
            this.canonical = {};
            this.pending = [];
            this.siloed = []
        },
        hg = function() {
            var a = Sb("google_tag_data", {}),
                b = a.tidr;
            b || (b = new jg, a.tidr = b);
            return b
        };
    var kg = {},
        lg = !1,
        mg = {
            ctid: "GTM-W8KNLGB",
            He: "30808714",
            ni: "GTM-W8KNLGB",
            oi: "GTM-W8KNLGB"
        };
    kg.nd = Fa("");
    var pg = function() {
            var a = ng();
            return lg ? a.map(og) : a
        },
        rg = function() {
            var a = qg();
            return lg ? a.map(og) : a
        },
        tg = function() {
            return sg(mg.ctid)
        },
        ug = function() {
            return sg(mg.He || "_" + mg.ctid)
        },
        ng = function() {
            return mg.ni ? mg.ni.split("|") : [mg.ctid]
        },
        qg = function() {
            return mg.oi ? mg.oi.split("|") : []
        },
        vg = function(a) {
            var b = hg();
            return a.isDestination ? b.destination[a.ctid] : b.container[a.ctid]
        },
        sg = function(a) {
            return lg ? og(a) : a
        },
        og = function(a) {
            return "siloed_" + a
        },
        wg = function(a) {
            a = String(a);
            return lg && 0 === a.indexOf("siloed_") ?
                a.substring(7) : a
        },
        xg = function() {
            var a = !1;
            if (a) {
                var b = hg();
                if (b.siloed) {
                    for (var c = [], d = ng(), e = qg(), f = {}, h = 0; h < b.siloed.length; f = {
                            wd: f.wd
                        }, h++) f.wd = b.siloed[h], !lg && ya(f.wd.isDestination ? e : d, function(l) {
                        return function(m) {
                            return m === l.wd.ctid
                        }
                    }(f)) ? lg = !0 : c.push(f.wd);
                    b.siloed = c
                }
            }
        };

    function yg() {
        var a = hg();
        if (a.pending) {
            for (var b, c = [], d = !1, e = pg(), f = rg(), h = {}, l = 0; l < a.pending.length; h = {
                    Bc: h.Bc
                }, l++) h.Bc = a.pending[l], ya(h.Bc.target.isDestination ? f : e, function(m) {
                return function(n) {
                    return n === m.Bc.target.ctid
                }
            }(h)) ? d || (b = h.Bc.onLoad, d = !0) : c.push(h.Bc);
            a.pending = c;
            if (b) try {
                b(ug())
            } catch (m) {}
        }
    }
    var zg = function() {
            for (var a = hg(), b = pg(), c = 0; c < b.length; c++) {
                var d = a.container[b[c]];
                d ? (d.state = 2, d.containers = pg(), d.destinations = rg()) : a.container[b[c]] = {
                    state: 2,
                    containers: pg(),
                    destinations: rg()
                }
            }
            for (var e = rg(), f = 0; f < e.length; f++) {
                var h = a.destination[e[f]];
                h && 0 === h.state && K(93);
                h ? (h.state = 2, h.containers = pg(), h.destinations = rg()) : a.destination[e[f]] = {
                    state: 2,
                    containers: pg(),
                    destinations: rg()
                }
            }
            a.canonical[ug()] = {};
            yg()
        },
        Ag = function(a) {
            return !!hg().container[a]
        },
        Bg = function() {
            return {
                ctid: tg(),
                isDestination: kg.nd
            }
        };

    function Cg(a) {
        var b = hg();
        (b.siloed = b.siloed || []).push(a)
    }
    var Dg = function() {
            var a = hg().container,
                b;
            for (b in a)
                if (a.hasOwnProperty(b) && 1 === a[b].state) return !0;
            return !1
        },
        Eg = function() {
            var a = {};
            k(hg().destination, function(b, c) {
                0 === c.state && (a[b] = c)
            });
            return a
        },
        Fg = function(a) {
            return !!(a && a.parent && a.context && 1 === a.context.source && 0 !== a.parent.ctid.indexOf("GTM-"))
        };
    var Gg = {
            sampleRate: "0.005000",
            Ni: "",
            Mi: Number("5"),
            mn: Number("")
        },
        Hg = [];

    function Ig(a) {
        Hg.push(a)
    }
    var Jg = !1,
        Kg;
    if (!(Kg = gg)) {
        var Lg = Math.random(),
            Mg = Gg.sampleRate;
        Kg = Lg < Number(Mg)
    }
    var Ng = Kg,
        Og = "https://www.googletagmanager.com/a?id=" + mg.ctid,
        Pg = void 0,
        Qg = {},
        Rg = void 0,
        Sg = new function() {
            var a = 5;
            0 < Gg.Mi && (a = Gg.Mi);
            this.h = 0;
            this.D = [];
            this.C = a
        },
        Tg = 1E3;

    function Ug(a, b) {
        var c = Pg;
        if (void 0 === c)
            if (b) c = Se();
            else return "";
        for (var d = [Og], e = 0; e < Hg.length; e++) {
            var f = Hg[e]({
                eventId: c,
                Fb: !!a,
                Bi: function() {
                    Jg = !0
                }
            });
            "&" === f[0] && d.push(f)
        }
        d.push("&z=0");
        return d.join("")
    }

    function Vg() {
        Rg && (C.clearTimeout(Rg), Rg = void 0);
        if (void 0 !== Pg && Wg) {
            var a;
            (a = Qg[Pg]) || (a = Sg.h < Sg.C ? !1 : 1E3 > Ka() - Sg.D[Sg.h % Sg.C]);
            if (a || 0 >= Tg--) K(1), Qg[Pg] = !0;
            else {
                var b = Sg.h++ % Sg.C;
                Sg.D[b] = Ka();
                var c = Ug(!0);
                $b(c);
                if (Jg) {
                    var d = c.replace("/a?", "/td?");
                    $b(d)
                }
                Wg = Jg = !1
            }
        }
    }
    var Wg = !1;

    function Xg(a) {
        Qg[a] || (a !== Pg && (Vg(), Pg = a), Wg = !0, Rg || (Rg = C.setTimeout(Vg, 500)), 2022 <= Ug().length && Vg())
    }
    var Yg = za();

    function Zg() {
        Yg = za()
    }

    function $g() {
        return ["&v=3&t=t", "&pid=" + Yg].join("")
    };
    var ah = function(a, b, c, d, e, f, h, l, m, n, p, q) {
            this.eventId = a;
            this.priorityId = b;
            this.h = c;
            this.M = d;
            this.D = e;
            this.K = f;
            this.R = h;
            this.C = l;
            this.eventMetadata = m;
            this.onSuccess = n;
            this.onFailure = p;
            this.isGtmEvent = q
        },
        T = function(a, b, c) {
            if (void 0 !== a.h[b]) return a.h[b];
            if (void 0 !== a.M[b]) return a.M[b];
            if (void 0 !== a.D[b]) return a.D[b];
            Ng && bh(a, a.K[b], a.R[b]) && (K(71), K(79));
            return void 0 !== a.K[b] ? a.K[b] : void 0 !== a.C[b] ? a.C[b] : c
        },
        ch = function(a) {
            function b(h) {
                for (var l = Object.keys(h), m = 0; m < l.length; ++m) c[l[m]] = 1
            }
            var c = {};
            b(a.h);
            b(a.M);
            b(a.D);
            b(a.K);
            if (Ng)
                for (var d = Object.keys(a.R), e = 0; e < d.length; e++) {
                    var f = d[e];
                    if ("event" !== f && "gtm" !== f && "tagTypeBlacklist" !== f && !c.hasOwnProperty(f)) {
                        K(71);
                        K(80);
                        break
                    }
                }
            return Object.keys(c)
        },
        dh = function(a, b, c) {
            function d(m) {
                Ya(m) && k(m, function(n, p) {
                    f = !0;
                    e[n] = p
                })
            }
            var e = {},
                f = !1;
            c && 1 !== c || (d(a.C[b]), d(a.K[b]), d(a.D[b]), d(a.M[b]));
            c && 2 !== c || d(a.h[b]);
            if (Ng) {
                var h = f,
                    l = e;
                e = {};
                f = !1;
                c && 1 !== c || (d(a.C[b]), d(a.R[b]), d(a.D[b]), d(a.M[b]));
                c && 2 !== c || d(a.h[b]);
                if (f !== h || bh(a, e, l)) K(71), K(81);
                f = h;
                e = l
            }
            return f ? e : void 0
        },
        eh = function(a) {
            var b = [L.g.Lc, L.g.Hc, L.g.Ic, L.g.Jc, L.g.Kc, L.g.Mc, L.g.Nc],
                c = {},
                d = !1,
                e = function(l) {
                    for (var m = 0; m < b.length; m++) void 0 !== l[b[m]] && (c[b[m]] = l[b[m]], d = !0);
                    return d
                };
            if (e(a.h) || e(a.M) || e(a.D)) return c;
            e(a.K);
            if (Ng) {
                var f = c,
                    h = d;
                c = {};
                d = !1;
                e(a.R);
                bh(a, c, f) && (K(71), K(82));
                c = f;
                d = h
            }
            if (d) return c;
            e(a.C);
            return c
        },
        bh = function(a, b, c) {
            if (!Ng) return !1;
            try {
                if (b === c) return !1;
                var d = Va(b);
                if (d !== Va(c) || !(Ya(b) && Ya(c) || "array" === d)) return !0;
                if ("array" === d) {
                    if (b.length !== c.length) return !0;
                    for (var e = 0; e < b.length; e++)
                        if (bh(a, b[e], c[e])) return !0
                } else {
                    for (var f in c)
                        if (!b.hasOwnProperty(f)) return !0;
                    for (var h in b)
                        if (!c.hasOwnProperty(h) || bh(a, b[h], c[h])) return !0
                }
            } catch (l) {
                K(72)
            }
            return !1
        },
        fh = function(a, b) {
            this.ye = a;
            this.ze = b;
            this.K = {};
            this.Rb = {};
            this.h = {};
            this.M = {};
            this.C = {};
            this.yb = {};
            this.D = {};
            this.xb = function() {};
            this.Ea = function() {};
            this.R = !1
        },
        gh = function(a, b) {
            a.K = b;
            return a
        },
        hh = function(a, b) {
            a.Rb = b;
            return a
        },
        ih = function(a, b) {
            a.h = b;
            return a
        },
        jh = function(a, b) {
            a.M = b;
            return a
        },
        kh = function(a,
            b) {
            a.C = b;
            return a
        },
        lh = function(a, b) {
            a.yb = b;
            return a
        },
        mh = function(a, b) {
            a.D = b || {};
            return a
        },
        nh = function(a, b) {
            a.xb = b;
            return a
        },
        oh = function(a, b) {
            a.Ea = b;
            return a
        },
        ph = function(a, b) {
            a.R = b;
            return a
        },
        qh = function(a) {
            return new ah(a.ye, a.ze, a.K, a.Rb, a.h, a.M, a.C, a.yb, a.D, a.xb, a.Ea, a.R)
        };

    function rh(a, b) {
        if ("" === a) return b;
        var c = Number(a);
        return isNaN(c) ? b : c
    };
    var xh = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        yh = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };
    var zh = function(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };

    function Ah() {
        return ob ? !!vb && !!vb.platform : !1
    }

    function Bh() {
        return yb("iPhone") && !yb("iPod") && !yb("iPad")
    }

    function Ch() {
        Bh() || yb("iPad") || yb("iPod")
    };
    Ab();
    zb() || yb("Trident") || yb("MSIE");
    yb("Edge");
    !yb("Gecko") || -1 != ub().toLowerCase().indexOf("webkit") && !yb("Edge") || yb("Trident") || yb("MSIE") || yb("Edge"); - 1 != ub().toLowerCase().indexOf("webkit") && !yb("Edge") && yb("Mobile");
    Ah() || yb("Macintosh");
    Ah() || yb("Windows");
    (Ah() ? "Linux" === vb.platform : yb("Linux")) || Ah() || yb("CrOS");
    Ah() || yb("Android");
    Bh();
    yb("iPad");
    yb("iPod");
    Ch();
    ub().toLowerCase().indexOf("kaios");
    var Dh = function(a, b, c, d) {
            for (var e = b, f = c.length; 0 <= (e = a.indexOf(c, e)) && e < d;) {
                var h = a.charCodeAt(e - 1);
                if (38 == h || 63 == h) {
                    var l = a.charCodeAt(e + f);
                    if (!l || 61 == l || 38 == l || 35 == l) return e
                }
                e += f + 1
            }
            return -1
        },
        Eh = /#|$/,
        Fh = function(a, b) {
            var c = a.search(Eh),
                d = Dh(a, 0, b, c);
            if (0 > d) return null;
            var e = a.indexOf("&", d);
            if (0 > e || e > c) e = c;
            d += b.length + 1;
            return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
        },
        Gh = /[?&]($|#)/,
        Hh = function(a, b, c) {
            for (var d, e = a.search(Eh), f = 0, h, l = []; 0 <= (h = Dh(a, f, b, e));) l.push(a.substring(f,
                h)), f = Math.min(a.indexOf("&", h) + 1 || e, e);
            l.push(a.slice(f));
            d = l.join("").replace(Gh, "$1");
            var m, n = null != c ? "=" + encodeURIComponent(String(c)) : "";
            var p = b + n;
            if (p) {
                var q, t = d.indexOf("#");
                0 > t && (t = d.length);
                var r = d.indexOf("?"),
                    u;
                0 > r || r > t ? (r = t, u = "") : u = d.substring(r + 1, t);
                q = [d.slice(0, r), u, d.slice(t)];
                var v = q[1];
                q[1] = p ? v ? v + "&" + p : p : v;
                m = q[0] + (q[1] ? "?" + q[1] : "") + q[2]
            } else m = d;
            return m
        };
    var Ih = function(a) {
            try {
                var b;
                if (b = !!a && null != a.location.href) a: {
                    try {
                        xf(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        },
        Jh = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        };

    function Kh(a) {
        if (!a || !F.head) return null;
        var b = Lh("META");
        F.head.appendChild(b);
        b.httpEquiv = "origin-trial";
        b.content = a;
        return b
    }
    var Mh = function(a) {
            if (C.top == C) return 0;
            if (void 0 === a ? 0 : a) {
                var b = C.location.ancestorOrigins;
                if (b) return b[b.length - 1] == C.location.origin ? 1 : 2
            }
            return Ih(C.top) ? 1 : 2
        },
        Lh = function(a, b) {
            b = void 0 === b ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function Nh(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Lh("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var h = a.google_image_requests,
                        l = jb(h, e);
                    0 <= l && Array.prototype.splice.call(h, l, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, !1);
                e.removeEventListener && e.removeEventListener("error", f, !1)
            };
            zh(e, "load", f);
            zh(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }
    var Ph = function(a) {
            var b;
            b = void 0 === b ? !1 : b;
            var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
            Jh(a, function(d, e) {
                if (d || 0 === d) c += "&" + e + "=" + encodeURIComponent("" + d)
            });
            Oh(c, b)
        },
        Oh = function(a, b) {
            var c = window,
                d;
            b = void 0 === b ? !1 : b;
            d = void 0 === d ? !1 : d;
            if (c.fetch) {
                var e = {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                };
                d && (e.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? e.attributionReporting = {
                        eventSourceEligible: "true",
                        triggerEligible: "false"
                    } :
                    e.headers = {
                        "Attribution-Reporting-Eligible": "event-source"
                    });
                c.fetch(a, e)
            } else Nh(c, a, void 0 === b ? !1 : b, void 0 === d ? !1 : d)
        };
    var Qh = function() {};
    var Rh = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        Sh = function(a, b) {
            b = void 0 === b ? {} : b;
            this.C = a;
            this.h = null;
            this.M = {};
            this.Ea = 0;
            var c;
            this.R = null != (c = b.im) ? c : 500;
            var d;
            this.K = null != (d = b.Ym) ? d : !1;
            this.D = null
        };
    qa(Sh, Qh);
    var Uh = function(a) {
        return "function" === typeof a.C.__tcfapi || null != Th(a)
    };
    Sh.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.K
            },
            d = yh(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.R && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.R));
        var f = function(h, l) {
            clearTimeout(e);
            h ? (c = h, c.internalErrorState = Rh(c), c.internalBlockOnErrors = b.K, l && 0 === c.internalErrorState || (c.tcString = "tcunavailable", l || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            Vh(this, "addEventListener", f)
        } catch (h) {
            c.tcString =
                "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    Sh.prototype.removeEventListener = function(a) {
        a && a.listenerId && Vh(this, "removeEventListener", null, a.listenerId)
    };
    var Xh = function(a, b, c) {
            var d;
            d = void 0 === d ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (void 0 !== f) {
                        e = f[void 0 === d ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var h = e;
            if (0 === h) return !1;
            var l = c;
            2 === c ? (l = 0, 2 === h && (l = 1)) : 3 === c && (l = 1, 1 === h && (l = 0));
            var m;
            if (0 === l)
                if (a.purpose && a.vendor) {
                    var n = Wh(a.vendor.consents, void 0 === d ? "755" : d);
                    m = n && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? !0 : n && Wh(a.purpose.consents, b)
                } else m = !0;
            else m = 1 === l ? a.purpose && a.vendor ? Wh(a.purpose.legitimateInterests,
                b) && Wh(a.vendor.legitimateInterests, void 0 === d ? "755" : d) : !0 : !0;
            return m
        },
        Wh = function(a, b) {
            return !(!a || !a[b])
        },
        Vh = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.C.__tcfapi) {
                var e = a.C.__tcfapi;
                e(b, 2, c, d)
            } else if (Th(a)) {
                Yh(a);
                var f = ++a.Ea;
                a.M[f] = c;
                if (a.h) {
                    var h = {};
                    a.h.postMessage((h.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: f,
                        parameter: d
                    }, h), "*")
                }
            } else c({}, !1)
        },
        Th = function(a) {
            if (a.h) return a.h;
            var b;
            a: {
                for (var c = a.C, d = 0; 50 > d; ++d) {
                    var e;
                    try {
                        e = !(!c.frames || !c.frames.__tcfapiLocator)
                    } catch (l) {
                        e = !1
                    }
                    if (e) {
                        b = c;
                        break a
                    }
                    var f;
                    b: {
                        try {
                            var h = c.parent;
                            if (h && h != c) {
                                f = h;
                                break b
                            }
                        } catch (l) {}
                        f = null
                    }
                    if (!(c = f)) break
                }
                b = null
            }
            a.h = b;
            return a.h
        },
        Yh = function(a) {
            a.D || (a.D = function(b) {
                try {
                    var c;
                    c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.M[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, zh(a.C, "message", a.D))
        },
        Zh = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = Rh(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ?
                (Ph({
                    e: String(a.internalErrorState)
                }), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        };
    var $h = {
            1: 0,
            3: 0,
            4: 0,
            7: 3,
            9: 3,
            10: 3
        },
        ai = rh('', 500);

    function bi() {
        var a = ye.tcf || {};
        return ye.tcf = a
    }
    var ci = function() {
            return new Sh(C, {
                im: -1
            })
        },
        ji = function() {
            var a = bi(),
                b = ci();
            Uh(b) && di() && K(124);
            if ((ei() || P(62)) && !a.active && Uh(b)) {
                ei() && (a.active = !0, a.Eb = {}, a.cmpId = 0, a.tcfPolicyVersion = 0, P(62) ? Ef().active = !0 : fi(), a.tcString = "tcunavailable");
                P(62) && dg();
                try {
                    b.addEventListener(function(c) {
                        if (0 !== c.internalErrorState) gi(a), P(62) ? (eg([L.g.H, L.g.ya, L.g.N]), Ef().active = !0) : hi(a);
                        else {
                            a.gdprApplies = c.gdprApplies;
                            if (P(62)) {
                                a.cmpId = c.cmpId;
                                a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode;
                                !0 ===
                                    bi().enableAdvertiserConsentMode && (a.active = !0);
                                if (ii(c) && di()) {
                                    eg([L.g.H, L.g.ya, L.g.N]);
                                    return
                                }
                                a.tcfPolicyVersion = c.tcfPolicyVersion
                            }
                            var d;
                            if (!1 === c.gdprApplies) {
                                var e = {},
                                    f;
                                for (f in $h) $h.hasOwnProperty(f) && (e[f] = !0);
                                d = e;
                                b.removeEventListener(c)
                            } else if (ii(c)) {
                                var h = {},
                                    l;
                                for (l in $h)
                                    if ($h.hasOwnProperty(l))
                                        if ("1" === l) {
                                            var m, n = c,
                                                p = !0;
                                            p = void 0 === p ? !1 : p;
                                            m = Zh(n) ? !1 === n.gdprApplies || "tcunavailable" === n.tcString || void 0 === n.gdprApplies && !p || "string" !== typeof n.tcString || !n.tcString.length ? !0 : Xh(n, "1",
                                                0) : !1;
                                            h["1"] = m
                                        } else h[l] = Xh(c, l, $h[l]);
                                d = h
                            }
                            d && (a.tcString = c.tcString || "tcempty", a.Eb = d, hi(a))
                        }
                    })
                } catch (c) {
                    gi(a), P(62) ? (eg([L.g.H, L.g.ya, L.g.N]), Ef().active = !0) : hi(a)
                }
            }
        };

    function gi(a) {
        a.type = "e";
        a.tcString = "tcunavailable"
    }

    function ii(a) {
        return "tcloaded" === a.eventStatus || "useractioncomplete" === a.eventStatus || "cmpuishown" === a.eventStatus
    }

    function fi() {
        var a = {},
            b = (a[L.g.H] = "denied", a[L.g.jf] = ai, a);
        Zf(b)
    }
    var ei = function() {
            return !0 === C.gtag_enable_tcf_support
        },
        di = function() {
            var a = ei();
            return P(62) ? !a && !0 !== bi().enableAdvertiserConsentMode : !a
        };

    function hi(a) {
        var b = {},
            c = (b[L.g.H] = a.Eb["1"] ? "granted" : "denied", b);
        if (P(62)) {
            if (!0 !== a.gdprApplies) {
                eg([L.g.H, L.g.ya, L.g.N]);
                Ef().active = !0;
                return
            }
            c[L.g.ya] = a.Eb["3"] && a.Eb["4"] ? "granted" : "denied";
            "number" === typeof a.tcfPolicyVersion && 4 <= a.tcfPolicyVersion ? c[L.g.N] = a.Eb["1"] && a.Eb["7"] ? "granted" : "denied" : eg([L.g.N])
        }
        $f(c, {
            eventId: 0
        }, {
            gdprApplies: a ? a.gdprApplies : void 0,
            tcString: ki() || ""
        })
    }
    var ki = function() {
            var a = bi();
            if (a.active) return a.tcString
        },
        li = function() {
            var a = bi();
            if (a.active && void 0 !== a.gdprApplies) return a.gdprApplies ? "1" : "0"
        },
        mi = function(a) {
            if (!$h.hasOwnProperty(String(a))) return !0;
            var b = bi();
            return b.active && b.Eb ? !!b.Eb[String(a)] : !0
        };
    var ni = [L.g.H, L.g.P],
        oi = [L.g.H, L.g.P, L.g.N, L.g.ya],
        pi = {},
        qi = (pi[L.g.H] = 1, pi[L.g.P] = 2, pi);

    function ri(a) {
        if (void 0 === a) return 0;
        switch (T(a, L.g.X)) {
            case void 0:
                return 1;
            case !1:
                return 3;
            default:
                return 2
        }
    }
    var si = function(a) {
            var b = ri(a);
            if (3 === b) return !1;
            if (P(54)) switch (Nf(L.g.ya)) {
                case 1:
                case 3:
                    break;
                case 2:
                    return !1;
                case 4:
                    return 2 === b;
                case 0:
                    break;
                default:
                    return !1
            }
            return !0
        },
        ti = function() {
            return Pf() || !Mf(L.g.H) || !Mf(L.g.P)
        },
        ui = function() {
            var a = {},
                b;
            for (b in qi) qi.hasOwnProperty(b) && (a[qi[b]] = Nf(b));
            var c = P(40) && ni.every(Mf),
                d = P(36);
            return c || d ? nc(a, 1) : nc(a, 0)
        },
        vi = {},
        wi = (vi[L.g.H] = 0, vi[L.g.P] = 1, vi[L.g.N] = 2, vi[L.g.ya] = 3, vi);

    function xi(a) {
        switch (a) {
            case void 0:
                return 1;
            case !0:
                return 3;
            case !1:
                return 2;
            default:
                return 0
        }
    }
    var yi = function(a) {
            if (P(37)) {
                for (var b = "1", c = 0; c < oi.length; c++) {
                    var d = b,
                        e, f = oi[c],
                        h = Cf[f];
                    e = void 0 === h ? 0 : wi.hasOwnProperty(h) ? 12 | wi[h] : 8;
                    var l = Ef();
                    l.accessedAny = !0;
                    var m = l.entries[f] || {};
                    e = e << 2 | xi(m.implicit);
                    b = d + ("" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [e] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [xi(m.declare) << 4 | xi(m.default) << 2 | xi(m.update)])
                }
                var n = b,
                    p;
                p = "" + (Pf() << 2 | ri(a));
                return n + p
            }
            for (var q = "G1", t = 0; t < ni.length; t++) {
                var r;
                a: {
                    var u = ni[t],
                        v = Ef();v.accessedDefault = !0;
                    switch ((v.entries[u] || {}).default) {
                        case !0:
                            r = 3;
                            break a;
                        case !1:
                            r = 2;
                            break a;
                        default:
                            r = 1
                    }
                }
                switch (r) {
                    case 3:
                        q += "1";
                        break;
                    case 2:
                        q += "0";
                        break;
                    case 1:
                        q += "-"
                }
            }
            return q
        },
        zi = function() {
            if (!Mf(L.g.N)) return "-";
            var a = {},
                b = Ef().cps,
                c;
            for (c in b) b.hasOwnProperty(c) && (a[c] = {
                enabled: b[c].enabled,
                region: b[c].region
            });
            for (var d = {}, e = ha(Object.keys(a)), f = e.next(); !f.done; f = e.next()) {
                var h = f.value;
                d[h] = a[h].enabled
            }
            for (var l = "", m = ha(Object.keys(we)), n = m.next(); !n.done; n = m.next()) {
                var p =
                    n.value;
                !1 !== d[p] && (l += we[p])
            }
            return "" === l ? "-" : l
        };

    function Ai() {
        var a = !!qf["6"],
            b = !1;
        P(62) && (b = !di() && "1" === li());
        return a || b
    }
    var Bi = function() {
            return Ai() ? "1" : "0"
        },
        Ci = function() {
            return Ai() || Ef().usedSetCps || !Mf(L.g.N)
        },
        Di = function() {
            var a = "0",
                b = "0",
                c;
            var d = bi();
            c = d.active && P(62) ? d.cmpId : void 0;
            "number" === typeof c && 0 <= c && 4095 >= c && (a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c >> 6 & 63], b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c & 63]);
            var e = "0",
                f;
            var h = bi();
            f = h.active && P(62) ? h.tcfPolicyVersion : void 0;
            "number" === typeof f && 0 <= f && 63 >= f && (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [f]);
            var l = 0;
            qf["6"] && (l |= 1);
            "1" === li() && (l |= 2);
            ei() && (l |= 4);
            var m;
            var n = bi();
            m = void 0 !== n.enableAdvertiserConsentMode ? n.enableAdvertiserConsentMode ? "1" : "0" : void 0;
            "1" === m && (l |= 8);
            Ef().waitPeriodTimedOut && (l |= 16);
            return "1" + a + b + e + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [l]
        };
    var Ei = function(a, b, c) {
        for (var d = [], e = b.split(";"), f = 0; f < e.length; f++) {
            var h = e[f].split("="),
                l = h[0].replace(/^\s*|\s*$/g, "");
            if (l && l == a) {
                var m = h.slice(1).join("=").replace(/^\s*|\s*$/g, "");
                m && c && (m = decodeURIComponent(m));
                d.push(m)
            }
        }
        return d
    };

    function Fi(a) {
        return "null" !== a.origin
    };
    var Ii = function(a, b, c, d) {
            return Gi(d) ? Ei(a, String(b || Hi()), c) : []
        },
        Li = function(a, b, c, d, e) {
            if (Gi(e)) {
                var f = Ji(a, d, e);
                if (1 === f.length) return f[0].id;
                if (0 !== f.length) {
                    f = Ki(f, function(h) {
                        return h.Je
                    }, b);
                    if (1 === f.length) return f[0].id;
                    f = Ki(f, function(h) {
                        return h.Nd
                    }, c);
                    return f[0] ? f[0].id : void 0
                }
            }
        };

    function Mi(a, b, c, d) {
        var e = Hi(),
            f = window;
        Fi(f) && (f.document.cookie = a);
        var h = Hi();
        return e != h || void 0 != c && 0 <= Ii(b, h, !1, d).indexOf(c)
    }
    var Qi = function(a, b, c) {
            function d(r, u, v) {
                if (null == v) return delete h[u], r;
                h[u] = v;
                return r + "; " + u + "=" + v
            }

            function e(r, u) {
                if (null == u) return delete h[u], r;
                h[u] = !0;
                return r + "; " + u
            }
            if (!Gi(c.ib)) return 2;
            var f;
            void 0 == b ? f = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = Ni(b), f = a + "=" + b);
            var h = {};
            f = d(f, "path", c.path);
            var l;
            c.expires instanceof Date ? l = c.expires.toUTCString() : null != c.expires && (l = "" + c.expires);
            f = d(f, "expires", l);
            f = d(f, "max-age", c.fn);
            f = d(f, "samesite",
                c.hn);
            c.jn && (f = e(f, "secure"));
            var m = c.domain;
            if (m && "auto" === m.toLowerCase()) {
                for (var n = Oi(), p = 0; p < n.length; ++p) {
                    var q = "none" !== n[p] ? n[p] : void 0,
                        t = d(f, "domain", q);
                    t = e(t, c.flags);
                    if (!Pi(q, c.path) && Mi(t, a, b, c.ib)) return 0
                }
                return 1
            }
            m && "none" !== m.toLowerCase() && (f = d(f, "domain", m));
            f = e(f, c.flags);
            return Pi(m, c.path) ? 1 : Mi(f, a, b, c.ib) ? 0 : 1
        },
        Ri = function(a, b, c) {
            null == c.path && (c.path = "/");
            c.domain || (c.domain = "auto");
            return Qi(a, b, c)
        };

    function Ki(a, b, c) {
        for (var d = [], e = [], f, h = 0; h < a.length; h++) {
            var l = a[h],
                m = b(l);
            m === c ? d.push(l) : void 0 === f || m < f ? (e = [l], f = m) : m === f && e.push(l)
        }
        return 0 < d.length ? d : e
    }

    function Ji(a, b, c) {
        for (var d = [], e = Ii(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var h = e[f].split("."),
                l = h.shift();
            if (!b || -1 !== b.indexOf(l)) {
                var m = h.shift();
                m && (m = m.split("-"), d.push({
                    id: h.join("."),
                    Je: 1 * m[0] || 1,
                    Nd: 1 * m[1] || 1
                }))
            }
        }
        return d
    }
    var Ni = function(a) {
            a && 1200 < a.length && (a = a.substring(0, 1200));
            return a
        },
        Si = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Ti = /(^|\.)doubleclick\.net$/i,
        Pi = function(a, b) {
            return Ti.test(window.document.location.hostname) || "/" === b && Si.test(a)
        },
        Hi = function() {
            return Fi(window) ? window.document.cookie : ""
        },
        Oi = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (4 === b.length) {
                var c = b[b.length - 1];
                if (parseInt(c, 10).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; 0 <= d; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            Ti.test(e) || Si.test(e) || a.push("none");
            return a
        },
        Gi = function(a) {
            return a && zf().h() ? (g(a) ? [a] : a).every(function(b) {
                return Of(b) && Mf(b)
            }) : !0
        };
    var Ui = function(a) {
            var b = Math.round(2147483647 * Math.random());
            return a ? String(b ^ jf(a) & 2147483647) : String(b)
        },
        Vi = function(a) {
            return [Ui(a), Math.round(Ka() / 1E3)].join(".")
        },
        Yi = function(a, b, c, d, e) {
            var f = Wi(b);
            return Li(a, f, Xi(c), d, e)
        },
        Zi = function(a, b, c, d) {
            var e = "" + Wi(c),
                f = Xi(d);
            1 < f && (e += "-" + f);
            return [b, e, a].join(".")
        },
        Wi = function(a) {
            if (!a) return 1;
            a = 0 === a.indexOf(".") ? a.substr(1) : a;
            return a.split(".").length
        },
        Xi = function(a) {
            if (!a || "/" === a) return 1;
            "/" !== a[0] && (a = "/" + a);
            "/" !== a[a.length - 1] && (a += "/");
            return a.split("/").length -
                1
        };
    var $i = function() {
        ye.dedupe_gclid || (ye.dedupe_gclid = "" + Vi());
        return ye.dedupe_gclid
    };
    var aj = function() {
        var a = !1;
        return a
    };
    var bj = {
            UA: 1,
            AW: 2,
            DC: 3,
            G: 4,
            GF: 5,
            GT: 12,
            GTM: 14,
            HA: 6,
            MC: 7
        },
        cj = function(a, b) {
            var c = mg.ctid.split("-")[0].toUpperCase(),
                d = {};
            d.ctid = mg.ctid;
            d.Xl = xe.qd;
            d.Zl = xe.Lf;
            d.Bl = kg.nd ? 2 : 1;
            d.Xh = mg.He;
            d.Xh !== a && (d.bf = a);
            P(91) ? d.Ei = 1 : P(90) && (d.Ei = 2);
            Ee ? (d.Ze = bj[c], d.Ze || (d.Ze = 0)) : d.Ze = Ke ? 13 : 10;
            Ie ? d.ig = 1 : aj() ? d.ig = 2 : d.ig = 3;
            var e;
            var f = d.Ze,
                h = d.ig;
            void 0 === f ? e = "" : (h || (h = 0), e = "" + Ed(1, 1) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [f << 2 | h]);
            var l = d.Xm,
                m = 4 + e + (l ? "" + Ed(2, 1) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [l] :
                    ""),
                n, p = d.Zl;
            n = p && Dd.test(p) ? "" + Ed(3, 2) + p : "";
            var q, t = d.Xl;
            q = t ? "" + Ed(4, 1) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [t] : "";
            var r;
            var u = d.ctid;
            if (u && b) {
                var v = u.split("-"),
                    w = v[0].toUpperCase();
                if ("GTM" !== w && "OPT" !== w) r = "";
                else {
                    var x = v[1];
                    r = "" + Ed(5, 3) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [1 + x.length] + (d.Bl || 0) + x
                }
            } else r = "";
            var y = d.Ei,
                A = d.Xh,
                B = d.bf,
                D = d.kn;
            return m + n + q + r + (y ? "" + Ed(6, 1) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [y] :
                "") + (A ? "" + Ed(7, 3) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [A.length] + A : "") + (B ? "" + Ed(8, 3) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [B.length] + B : "") + (D ? "" + Ed(9, 3) + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [D.length] + D : "")
        };
    var dj = void 0;

    function ej(a) {
        var b = "";
        return b
    };
    Bb();
    Bh() || yb("iPod");
    yb("iPad");
    !yb("Android") || Cb() || Bb() || Ab() || yb("Silk");
    Cb();
    !yb("Safari") || Cb() || (zb() ? 0 : yb("Coast")) || Ab() || (zb() ? 0 : yb("Edge")) || (zb() ? xb("Microsoft Edge") : yb("Edg/")) || (zb() ? xb("Opera") : yb("OPR")) || Bb() || yb("Silk") || yb("Android") || Ch();
    var fj = {},
        gj = null,
        hj = function(a) {
            for (var b = [], c = 0, d = 0; d < a.length; d++) {
                var e = a.charCodeAt(d);
                255 < e && (b[c++] = e & 255, e >>= 8);
                b[c++] = e
            }
            var f = 4;
            void 0 === f && (f = 0);
            if (!gj) {
                gj = {};
                for (var h = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), l = ["+/=", "+/", "-_=", "-_.", "-_"], m = 0; 5 > m; m++) {
                    var n = h.concat(l[m].split(""));
                    fj[m] = n;
                    for (var p = 0; p < n.length; p++) {
                        var q = n[p];
                        void 0 === gj[q] && (gj[q] = p)
                    }
                }
            }
            for (var t = fj[f], r = Array(Math.floor(b.length / 3)), u = t[64] || "", v = 0, w = 0; v < b.length - 2; v += 3) {
                var x = b[v],
                    y = b[v + 1],
                    A = b[v + 2],
                    B = t[x >> 2],
                    D = t[(x & 3) << 4 | y >> 4],
                    I = t[(y & 15) << 2 | A >> 6],
                    J = t[A & 63];
                r[w++] = "" + B + D + I + J
            }
            var E = 0,
                G = u;
            switch (b.length - v) {
                case 2:
                    E = b[v + 1], G = t[(E & 15) << 2] || u;
                case 1:
                    var M = b[v];
                    r[w] = "" + t[M >> 2] + t[(M & 3) << 4 | E >> 4] + G + u
            }
            return r.join("")
        };
    Object.freeze({});
    var ij = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function jj() {
        var a;
        return null != (a = C.google_tag_data) ? a : C.google_tag_data = {}
    }

    function kj() {
        var a = C.google_tag_data,
            b;
        if (null != a && a.uach) {
            var c = a.uach,
                d = Object.assign({}, c);
            c.fullVersionList && (d.fullVersionList = c.fullVersionList.slice(0));
            b = d
        } else b = null;
        return b
    }

    function lj() {
        var a, b;
        return null != (b = null == (a = C.google_tag_data) ? void 0 : a.uach_promise) ? b : null
    }

    function mj() {
        var a, b;
        return "function" === typeof(null == (a = C.navigator) ? void 0 : null == (b = a.userAgentData) ? void 0 : b.getHighEntropyValues)
    }

    function nj() {
        if (!mj()) return null;
        var a = jj();
        if (a.uach_promise) return a.uach_promise;
        var b = C.navigator.userAgentData.getHighEntropyValues(ij).then(function(c) {
            null != a.uach || (a.uach = c);
            return c
        });
        return a.uach_promise = b
    };
    var oj, pj = function() {
            if (mj() && (oj = Ka(), !lj())) {
                var a = nj();
                a && (a.then(function() {
                    K(95);
                }), a.catch(function() {
                    K(96)
                }))
            }
        },
        rj = function(a) {
            var b = qj.mm,
                c = function(h, l) {
                    try {
                        a(h, l)
                    } catch (m) {}
                },
                d = kj();
            if (d) c(d);
            else {
                var e = lj();
                if (e) {
                    b =
                        Math.min(Math.max(isFinite(b) ? b : 0, 0), 1E3);
                    var f = C.setTimeout(function() {
                        c.Jd || (c.Jd = !0, K(106), c(null, Error("Timeout")))
                    }, b);
                    e.then(function(h) {
                        c.Jd || (c.Jd = !0, K(104), C.clearTimeout(f), c(h))
                    }).catch(function(h) {
                        c.Jd || (c.Jd = !0, K(105), C.clearTimeout(f), c(null, h))
                    })
                } else c(null)
            }
        },
        sj = function(a, b) {
            a && (b.h[L.g.dd] = a.architecture, b.h[L.g.ed] = a.bitness, a.fullVersionList && (b.h[L.g.fd] = a.fullVersionList.map(function(c) {
                    return encodeURIComponent(c.brand || "") + ";" + encodeURIComponent(c.version || "")
                }).join("|")),
                b.h[L.g.gd] = a.mobile ? "1" : "0", b.h[L.g.hd] = a.model, b.h[L.g.jd] = a.platform, b.h[L.g.kd] = a.platformVersion, b.h[L.g.ld] = a.wow64 ? "1" : "0")
        };
    var tj = /:[0-9]+$/,
        uj = /^\d+\.fls\.doubleclick\.net$/,
        vj = function(a, b, c) {
            function d(p) {
                return hd(10) ? decodeURIComponent(p.replace(/\+/g, " ")) : decodeURIComponent(p).replace(/\+/g, " ")
            }
            for (var e = ha(a.split("&")), f = e.next(); !f.done; f = e.next()) {
                var h = ha(f.value.split("=")),
                    l = h.next().value,
                    m = ia(h);
                if (d(l) === b) {
                    var n = m.join("=");
                    return c ? n : d(n)
                }
            }
        },
        yj = function(a, b, c, d, e) {
            b && (b = String(b).toLowerCase());
            if ("protocol" === b || "port" === b) a.protocol = wj(a.protocol) || wj(C.location.protocol);
            "port" === b ? a.port = String(Number(a.hostname ?
                a.port : C.location.port) || ("http" === a.protocol ? 80 : "https" === a.protocol ? 443 : "")) : "host" === b && (a.hostname = (a.hostname || C.location.hostname).replace(tj, "").toLowerCase());
            return xj(a, b, c, d, e)
        },
        xj = function(a, b, c, d, e) {
            var f, h = wj(a.protocol);
            b && (b = String(b).toLowerCase());
            switch (b) {
                case "url_no_fragment":
                    f = zj(a);
                    break;
                case "protocol":
                    f = h;
                    break;
                case "host":
                    f = a.hostname.replace(tj, "").toLowerCase();
                    if (c) {
                        var l = /^www\d*\./.exec(f);
                        l && l[0] && (f = f.substr(l[0].length))
                    }
                    break;
                case "port":
                    f = String(Number(a.port) ||
                        ("http" === h ? 80 : "https" === h ? 443 : ""));
                    break;
                case "path":
                    a.pathname || a.hostname || gb("TAGGING", 1);
                    f = "/" === a.pathname.substr(0, 1) ? a.pathname : "/" + a.pathname;
                    var m = f.split("/");
                    0 <= (d || []).indexOf(m[m.length - 1]) && (m[m.length - 1] = "");
                    f = m.join("/");
                    break;
                case "query":
                    f = a.search.replace("?", "");
                    e && (f = vj(f, e));
                    break;
                case "extension":
                    var n = a.pathname.split(".");
                    f = 1 < n.length ? n[n.length - 1] : "";
                    f = f.split("/")[0];
                    break;
                case "fragment":
                    f = a.hash.replace("#", "");
                    break;
                default:
                    f = a && a.href
            }
            return f
        },
        wj = function(a) {
            return a ?
                a.replace(":", "").toLowerCase() : ""
        },
        zj = function(a) {
            var b = "";
            if (a && a.href) {
                var c = a.href.indexOf("#");
                b = 0 > c ? a.href : a.href.substr(0, c)
            }
            return b
        },
        Aj = function(a) {
            var b = F.createElement("a");
            a && (b.href = a);
            var c = b.pathname;
            "/" !== c[0] && (a || gb("TAGGING", 1), c = "/" + c);
            var d = b.hostname.replace(tj, "");
            return {
                href: b.href,
                protocol: b.protocol,
                host: b.host,
                hostname: d,
                pathname: c,
                search: b.search,
                hash: b.hash,
                port: b.port
            }
        },
        Bj = function(a) {
            function b(n) {
                var p = n.split("=")[0];
                return 0 > d.indexOf(p) ? n : p + "=0"
            }

            function c(n) {
                return n.split("&").map(b).filter(function(p) {
                    return void 0 !==
                        p
                }).join("&")
            }
            var d = "gclid dclid gbraid wbraid gclaw gcldc gclha gclgf gclgb _gl".split(" "),
                e = Aj(a),
                f = a.split(/[?#]/)[0],
                h = e.search,
                l = e.hash;
            "?" === h[0] && (h = h.substring(1));
            "#" === l[0] && (l = l.substring(1));
            h = c(h);
            l = c(l);
            "" !== h && (h = "?" + h);
            "" !== l && (l = "#" + l);
            var m = "" + f + h + l;
            "/" === m[m.length - 1] && (m = m.substring(0, m.length - 1));
            return m
        },
        Cj = function(a) {
            var b = Aj(C.location.href),
                c = yj(b, "host", !1);
            if (c && c.match(uj)) {
                var d = yj(b, "path").split(a + "=");
                if (1 < d.length) return d[1].split(";")[0].split("?")[0]
            }
        };

    function Dj(a, b, c, d) {
        var e, f = Number(null != a.Bb ? a.Bb : void 0);
        0 !== f && (e = new Date((b || Ka()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            ib: d
        }
    };
    var Ej;
    var Ij = function() {
            var a = Fj,
                b = Gj,
                c = Hj(),
                d = function(h) {
                    a(h.target || h.srcElement || {})
                },
                e = function(h) {
                    b(h.target || h.srcElement || {})
                };
            if (!c.init) {
                ac(F, "mousedown", d);
                ac(F, "keyup", d);
                ac(F, "submit", e);
                var f = HTMLFormElement.prototype.submit;
                HTMLFormElement.prototype.submit = function() {
                    b(this);
                    f.call(this)
                };
                c.init = !0
            }
        },
        Jj = function(a, b, c, d, e) {
            var f = {
                callback: a,
                domains: b,
                fragment: 2 === c,
                placement: c,
                forms: d,
                sameHost: e
            };
            Hj().decorators.push(f)
        },
        Kj = function(a, b, c) {
            for (var d = Hj().decorators, e = {}, f = 0; f < d.length; ++f) {
                var h =
                    d[f],
                    l;
                if (l = !c || h.forms) a: {
                    var m = h.domains,
                        n = a,
                        p = !!h.sameHost;
                    if (m && (p || n !== F.location.hostname))
                        for (var q = 0; q < m.length; q++)
                            if (m[q] instanceof RegExp) {
                                if (m[q].test(n)) {
                                    l = !0;
                                    break a
                                }
                            } else if (0 <= n.indexOf(m[q]) || p && 0 <= m[q].indexOf(n)) {
                        l = !0;
                        break a
                    }
                    l = !1
                }
                if (l) {
                    var t = h.placement;
                    void 0 == t && (t = h.fragment ? 2 : 1);
                    t === b && Na(e, h.callback())
                }
            }
            return e
        };

    function Hj() {
        var a = Sb("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var Lj = /(.*?)\*(.*?)\*(.*)/,
        Mj = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        Nj = /^(?:www\.|m\.|amp\.)+/,
        Oj = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function Pj(a, b) {
        var c = [Qb.userAgent, (new Date).getTimezoneOffset(), Qb.userLanguage || Qb.language, Math.floor(Ka() / 60 / 1E3) - (void 0 === b ? 0 : b), a].join("*"),
            d;
        if (!(d = Ej)) {
            for (var e = Array(256), f = 0; 256 > f; f++) {
                for (var h = f, l = 0; 8 > l; l++) h = h & 1 ? h >>> 1 ^ 3988292384 : h >>> 1;
                e[f] = h
            }
            d = e
        }
        Ej = d;
        for (var m = 4294967295, n = 0; n < c.length; n++) m = m >>> 8 ^ Ej[(m ^ c.charCodeAt(n)) & 255];
        return ((m ^ -1) >>> 0).toString(36)
    }

    function Qj() {
        return function(a) {
            var b = Aj(C.location.href),
                c = b.search.replace("?", ""),
                d = vj(c, "_gl", !0) || "";
            a.query = Rj(d) || {};
            var e = yj(b, "fragment"),
                f;
            var h = -1;
            if (Pa(e, "_gl=")) h = 4;
            else {
                var l = e.indexOf("&_gl=");
                0 < l && (h = l + 3 + 2)
            }
            if (0 > h) f = void 0;
            else {
                var m = e.indexOf("&", h);
                f = 0 > m ? e.substring(h) : e.substring(h, m)
            }
            a.fragment = Rj(f || "") || {}
        }
    }
    var Sj = function(a) {
            var b = Qj(),
                c = Hj();
            c.data || (c.data = {
                query: {},
                fragment: {}
            }, b(c.data));
            var d = {},
                e = c.data;
            e && (Na(d, e.query), a && Na(d, e.fragment));
            return d
        },
        Rj = function(a) {
            try {
                var b = Tj(a, 3);
                if (void 0 !== b) {
                    for (var c = {}, d = b ? b.split("*") : [], e = 0; e + 1 < d.length; e += 2) {
                        var f = d[e],
                            h = eb(d[e + 1]);
                        c[f] = h
                    }
                    gb("TAGGING", 6);
                    return c
                }
            } catch (l) {
                gb("TAGGING", 8)
            }
        };

    function Tj(a, b) {
        if (a) {
            var c;
            a: {
                for (var d = a, e = 0; 3 > e; ++e) {
                    var f = Lj.exec(d);
                    if (f) {
                        c = f;
                        break a
                    }
                    d = decodeURIComponent(d)
                }
                c = void 0
            }
            var h = c;
            if (h && "1" === h[1]) {
                var l = h[3],
                    m;
                a: {
                    for (var n = h[2], p = 0; p < b; ++p)
                        if (n === Pj(l, p)) {
                            m = !0;
                            break a
                        }
                    m = !1
                }
                if (m) return l;
                gb("TAGGING", 7)
            }
        }
    }

    function Uj(a, b, c, d, e) {
        function f(q) {
            var t = q,
                r = (new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")).exec(t),
                u = t;
            if (r) {
                var v = r[2],
                    w = r[4];
                u = r[1];
                w && (u = u + v + w)
            }
            q = u;
            var x = q.charAt(q.length - 1);
            q && "&" !== x && (q += "&");
            return q + p
        }
        d = void 0 === d ? !1 : d;
        e = void 0 === e ? !1 : e;
        var h = Oj.exec(c);
        if (!h) return "";
        var l = h[1],
            m = h[2] || "",
            n = h[3] || "",
            p = a + "=" + b;
        d ? 0 !== n.substring(1).length && e || (n = "#" + f(n.substring(1))) : m = "?" + f(m.substring(1));
        return "" + l + m + n
    }

    function Vj(a, b) {
        function c(n, p, q) {
            if (Object.keys(n).length) {
                var t, r = [],
                    u;
                for (u in n)
                    if (n.hasOwnProperty(u)) {
                        var v = n[u];
                        void 0 !== v && v === v && null !== v && "[object Object]" !== v.toString() && (r.push(u), r.push(db(String(v))))
                    }
                var w = r.join("*");
                t = ["1", Pj(w), w].join("*");
                d ? (hd(13) || hd(11) || !p) && Wj("_gl", t, a, p, q) : Xj("_gl", t, a, p, q)
            }
        }
        var d = "FORM" === (a.tagName || "").toUpperCase(),
            e = Kj(b, 1, d),
            f = Kj(b, 2, d),
            h = Kj(b, 4, d),
            l = Kj(b, 3, d);
        c(e, !1, !1);
        c(f, !0, !1);
        hd(11) && c(h, !0, !0);
        for (var m in l) l.hasOwnProperty(m) && Yj(m, l[m],
            a)
    }

    function Yj(a, b, c) {
        if (c.tagName) {
            if ("a" === c.tagName.toLowerCase()) {
                Xj(a, b, c);
                return
            }
            if ("form" === c.tagName.toLowerCase()) {
                Wj(a, b, c);
                return
            }
        }
        "string" == typeof c && Uj(a, b, c)
    }

    function Xj(a, b, c, d, e) {
        if (c.href) {
            var f = Uj(a, b, c.href, void 0 === d ? !1 : d, void 0 === e ? !1 : e);
            Gb.test(f) && (c.href = f)
        }
    }

    function Wj(a, b, c, d, e) {
        d = void 0 === d ? !1 : d;
        e = void 0 === e ? !1 : e;
        if (c && c.action) {
            var f = (c.method || "").toLowerCase();
            if ("get" !== f || d) {
                if ("get" === f || "post" === f) {
                    var h = Uj(a, b, c.action, d, e);
                    Gb.test(h) && (c.action = h)
                }
            } else {
                for (var l = c.childNodes || [], m = !1, n = 0; n < l.length; n++) {
                    var p = l[n];
                    if (p.name === a) {
                        p.setAttribute("value", b);
                        m = !0;
                        break
                    }
                }
                if (!m) {
                    var q = F.createElement("input");
                    q.setAttribute("type", "hidden");
                    q.setAttribute("name", a);
                    q.setAttribute("value", b);
                    c.appendChild(q)
                }
            }
        }
    }

    function Fj(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && 0 < d;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                "http:" !== f && "https:" !== f || Vj(e, e.hostname)
            }
        } catch (h) {}
    }

    function Gj(a) {
        try {
            if (a.action) {
                var b = yj(Aj(a.action), "host");
                Vj(a, b)
            }
        } catch (c) {}
    }
    var Zj = function(a, b, c, d) {
            Ij();
            Jj(a, b, "fragment" === c ? 2 : 1, !!d, !1)
        },
        ak = function(a, b) {
            Ij();
            Jj(a, [xj(C.location, "host", !0)], b, !0, !0)
        },
        bk = function() {
            var a = F.location.hostname,
                b = Mj.exec(F.referrer);
            if (!b) return !1;
            var c = b[2],
                d = b[1],
                e = "";
            if (c) {
                var f = c.split("/"),
                    h = f[1];
                e = "s" === h ? decodeURIComponent(f[2]) : decodeURIComponent(h)
            } else if (d) {
                if (0 === d.indexOf("xn--")) return !1;
                e = d.replace(/-/g, ".").replace(/\.\./g, "-")
            }
            var l = a.replace(Nj, ""),
                m = e.replace(Nj, ""),
                n;
            if (!(n = l === m)) {
                var p = "." + m;
                n = l.substring(l.length - p.length,
                    l.length) === p
            }
            return n
        },
        ck = function(a, b) {
            return !1 === a ? !1 : a || b || bk()
        };
    var dk = ["1"],
        ek = {},
        fk = {},
        kk = function(a, b) {
            b = void 0 === b ? !0 : b;
            var c = gk(a.prefix);
            if (!ek[c])
                if (hk(c, a.path, a.domain)) {
                    var d = fk[gk(a.prefix)];
                    ik(a, d ? d.id : void 0, d ? d.gg : void 0)
                } else {
                    var e = Cj("auiddc");
                    if (e) gb("TAGGING", 17), ek[c] = e;
                    else if (b) {
                        var f = gk(a.prefix),
                            h = Vi();
                        if (0 === jk(f, h, a)) {
                            var l = Sb("google_tag_data", {});
                            l._gcl_au || (l._gcl_au = h)
                        }
                        hk(c, a.path, a.domain)
                    }
                }
        };

    function ik(a, b, c) {
        var d = gk(a.prefix),
            e = ek[d];
        if (e) {
            var f = e.split(".");
            if (2 === f.length) {
                var h = Number(f[1]) || 0;
                if (h) {
                    var l = e;
                    b && (l = e + "." + b + "." + (c ? c : Math.floor(Ka() / 1E3)));
                    jk(d, l, a, 1E3 * h)
                }
            }
        }
    }

    function jk(a, b, c, d) {
        var e = Zi(b, "1", c.domain, c.path),
            f = Dj(c, d);
        f.ib = lk();
        return Ri(a, e, f)
    }

    function hk(a, b, c) {
        var d = Yi(a, b, c, dk, lk());
        if (!d) return !1;
        mk(a, d);
        return !0
    }

    function mk(a, b) {
        var c = b.split(".");
        5 === c.length ? (ek[a] = c.slice(0, 2).join("."), fk[a] = {
            id: c.slice(2, 4).join("."),
            gg: Number(c[4]) || 0
        }) : 3 === c.length ? fk[a] = {
            id: c.slice(0, 2).join("."),
            gg: Number(c[2]) || 0
        } : ek[a] = b
    }

    function gk(a) {
        return (a || "_gcl") + "_au"
    }

    function nk(a) {
        function b() {
            Mf(c) && a()
        }
        var c = lk();
        Tf(function() {
            b();
            Mf(c) || Uf(b, c)
        }, c)
    }

    function ok(a) {
        var b = Sj(!0),
            c = gk(a.prefix);
        nk(function() {
            var d = b[c];
            if (d) {
                mk(c, d);
                var e = 1E3 * Number(ek[c].split(".")[1]);
                if (e) {
                    gb("TAGGING", 16);
                    var f = Dj(a, e);
                    f.ib = lk();
                    var h = Zi(d, "1", a.domain, a.path);
                    Ri(c, h, f)
                }
            }
        })
    }

    function pk(a, b, c, d, e) {
        e = e || {};
        var f = function() {
            var h = {},
                l = Yi(a, e.path, e.domain, dk, lk());
            l && (h[a] = l);
            return h
        };
        nk(function() {
            Zj(f, b, c, d)
        })
    }

    function lk() {
        return hd(14) ? ["ad_storage", "ad_user_data"] : ["ad_storage"]
    };
    var qk = function(a) {
        for (var b = [], c = F.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                rg: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(h, l) {
            return l.timestamp - h.timestamp
        });
        return b
    };

    function rk(a, b) {
        var c = qk(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!("1" !== f[0] || b && 3 > f.length || !b && 3 !== f.length) && Number(f[1])) {
                d[c[e].rg] || (d[c[e].rg] = []);
                var h = {
                    version: f[0],
                    timestamp: 1E3 * Number(f[1]),
                    W: f[2]
                };
                b && 3 < f.length && (h.labels = f.slice(3));
                d[c[e].rg].push(h)
            }
        }
        return d
    };
    var sk = /^\w+$/,
        tk = /^[\w-]+$/,
        uk = {
            aw: "_aw",
            dc: "_dc",
            gf: "_gf",
            ha: "_ha",
            gp: "_gp",
            gb: "_gb"
        };

    function vk() {
        return hd(14) ? ["ad_storage", "ad_user_data"] : ["ad_storage"]
    }
    var wk = function() {
            return zf().h() ? Mf(vk()) : !0
        },
        xk = function(a) {
            function b() {
                var c = wk();
                c && a();
                return c
            }
            Tf(function() {
                b() || Uf(b, vk())
            }, vk())
        },
        zk = function(a) {
            return yk(a).map(function(b) {
                return b.W
            })
        },
        yk = function(a) {
            var b = [];
            if (!Fi(C) || !F.cookie) return b;
            var c = Ii(a, F.cookie, void 0, vk());
            if (!c || 0 == c.length) return b;
            for (var d = {}, e = 0; e < c.length; d = {
                    W: d.W
                }, e++) {
                var f = Ak(c[e]);
                if (null != f) {
                    var h = f,
                        l = h.version;
                    d.W = h.W;
                    var m = h.timestamp,
                        n = h.labels,
                        p = ya(b, function(q) {
                            return function(t) {
                                return t.W === q.W
                            }
                        }(d));
                    p ? (p.timestamp = Math.max(p.timestamp, m), p.labels = Bk(p.labels, n || [])) : b.push({
                        version: l,
                        W: d.W,
                        timestamp: m,
                        labels: n
                    })
                }
            }
            b.sort(function(q, t) {
                return t.timestamp - q.timestamp
            });
            return Ck(b)
        };

    function Bk(a, b) {
        for (var c = {}, d = [], e = 0; e < a.length; e++) c[a[e]] = !0, d.push(a[e]);
        for (var f = 0; f < b.length; f++) c[b[f]] || d.push(b[f]);
        return d
    }

    function Dk(a) {
        return a && "string" == typeof a && a.match(sk) ? a : "_gcl"
    }
    var Fk = function() {
            var a = Aj(C.location.href),
                b = yj(a, "query", !1, void 0, "gclid"),
                c = yj(a, "query", !1, void 0, "gclsrc"),
                d = yj(a, "query", !1, void 0, "wbraid"),
                e = yj(a, "query", !1, void 0, "dclid");
            if (!b || !c || !d) {
                var f = a.hash.replace("#", "");
                b = b || vj(f, "gclid");
                c = c || vj(f, "gclsrc");
                d = d || vj(f, "wbraid")
            }
            return Ek(b, c, e, d)
        },
        Ek = function(a, b, c, d) {
            var e = {},
                f = function(h, l) {
                    e[l] || (e[l] = []);
                    e[l].push(h)
                };
            e.gclid = a;
            e.gclsrc = b;
            e.dclid = c;
            void 0 !== d && tk.test(d) && (e.gbraid = d, f(d, "gb"));
            if (void 0 !== a && a.match(tk)) switch (b) {
                case void 0:
                    f(a,
                        "aw");
                    break;
                case "aw.ds":
                    f(a, "aw");
                    f(a, "dc");
                    break;
                case "ds":
                    f(a, "dc");
                    break;
                case "3p.ds":
                    f(a, "dc");
                    break;
                case "gf":
                    f(a, "gf");
                    break;
                case "ha":
                    f(a, "ha")
            }
            c && f(c, "dc");
            return e
        },
        Qk = function(a) {
            var b = Fk();
            xk(function() {
                Gk(b, !1, a)
            })
        };

    function Gk(a, b, c, d, e) {
        function f(w, x) {
            var y = Rk(w, h);
            y && (Ri(y, x, l), m = !0)
        }
        c = c || {};
        e = e || [];
        var h = Dk(c.prefix);
        d = d || Ka();
        var l = Dj(c, d, !0);
        l.ib = vk();
        var m = !1,
            n = Math.round(d / 1E3),
            p = function(w) {
                var x = ["GCL", n, w];
                0 < e.length && x.push(e.join("."));
                return x.join(".")
            };
        a.aw && f("aw", p(a.aw[0]));
        a.dc && f("dc", p(a.dc[0]));
        a.gf && f("gf", p(a.gf[0]));
        a.ha && f("ha", p(a.ha[0]));
        a.gp && f("gp", p(a.gp[0]));
        if (!m && a.gb) {
            var q = a.gb[0],
                t = Rk("gb", h),
                r = !1;
            if (!b)
                for (var u = yk(t), v = 0; v < u.length; v++) u[v].W === q && u[v].labels && 0 < u[v].labels.length &&
                    (r = !0);
            r || f("gb", p(q))
        }
    }
    var Tk = function(a, b) {
            var c = Sj(!0);
            xk(function() {
                for (var d = Dk(b.prefix), e = 0; e < a.length; ++e) {
                    var f = a[e];
                    if (void 0 !== uk[f]) {
                        var h = Rk(f, d),
                            l = c[h];
                        if (l) {
                            var m = Math.min(Sk(l), Ka()),
                                n;
                            b: {
                                var p = m;
                                if (Fi(C))
                                    for (var q = Ii(h, F.cookie, void 0, vk()), t = 0; t < q.length; ++t)
                                        if (Sk(q[t]) > p) {
                                            n = !0;
                                            break b
                                        }
                                n = !1
                            }
                            if (!n) {
                                var r = Dj(b, m, !0);
                                r.ib = vk();
                                Ri(h, l, r)
                            }
                        }
                    }
                }
                Gk(Ek(c.gclid, c.gclsrc), !1, b)
            })
        },
        Rk = function(a, b) {
            var c = uk[a];
            if (void 0 !== c) return b + c
        },
        Sk = function(a) {
            return 0 !== Uk(a.split(".")).length ? 1E3 * (Number(a.split(".")[1]) || 0) :
                0
        };

    function Ak(a) {
        var b = Uk(a.split("."));
        return 0 === b.length ? null : {
            version: b[0],
            W: b[2],
            timestamp: 1E3 * (Number(b[1]) || 0),
            labels: b.slice(3)
        }
    }

    function Uk(a) {
        return 3 > a.length || "GCL" !== a[0] && "1" !== a[0] || !/^\d+$/.test(a[1]) || !tk.test(a[2]) ? [] : a
    }
    var Vk = function(a, b, c, d, e) {
            if (xa(b) && Fi(C)) {
                var f = Dk(e),
                    h = function() {
                        for (var l = {}, m = 0; m < a.length; ++m) {
                            var n = Rk(a[m], f);
                            if (n) {
                                var p = Ii(n, F.cookie, void 0, vk());
                                p.length && (l[n] = p.sort()[p.length - 1])
                            }
                        }
                        return l
                    };
                xk(function() {
                    Zj(h, b, c, d)
                })
            }
        },
        Ck = function(a) {
            return a.filter(function(b) {
                return tk.test(b.W)
            })
        },
        Wk = function(a, b) {
            if (Fi(C)) {
                for (var c = Dk(b.prefix), d = {}, e = 0; e < a.length; e++) uk[a[e]] && (d[a[e]] = uk[a[e]]);
                xk(function() {
                    k(d, function(f, h) {
                        var l = Ii(c + h, F.cookie, void 0, vk());
                        l.sort(function(r, u) {
                            return Sk(u) -
                                Sk(r)
                        });
                        if (l.length) {
                            var m = l[0],
                                n = Sk(m),
                                p = 0 !== Uk(m.split(".")).length ? m.split(".").slice(3) : [],
                                q = {},
                                t;
                            t = 0 !== Uk(m.split(".")).length ? m.split(".")[2] : void 0;
                            q[f] = [t];
                            Gk(q, !0, b, n, p)
                        }
                    })
                })
            }
        };

    function Xk(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }
    var Yk = function(a) {
            function b(e, f, h) {
                h && (e[f] = h)
            }
            if (Pf()) {
                var c = Fk();
                if (Xk(c, a)) {
                    var d = {};
                    b(d, "gclid", c.gclid);
                    b(d, "dclid", c.dclid);
                    b(d, "gclsrc", c.gclsrc);
                    b(d, "wbraid", c.gbraid);
                    ak(function() {
                        return d
                    }, 3);
                    ak(function() {
                        var e = {};
                        return e._up = "1", e
                    }, 1)
                }
            }
        },
        Zk = function(a) {
            if (!hd(11)) return null;
            var b = Sj(!0).gad_source;
            if (null != b) return C.location.hash = "", b;
            if (hd(12)) {
                var c = Aj(C.location.href);
                b = yj(c, "query", !1, void 0, "gad_source");
                if (null != b) return b;
                var d = Fk();
                if (Xk(d, a)) return "0"
            }
            return null
        },
        $k = function(a) {
            var b =
                Zk(a);
            null != b && ak(function() {
                var c = {};
                return c.gad_source = b, c
            }, 4)
        },
        al = function(a, b, c, d) {
            var e = [];
            c = c || {};
            if (!wk()) return e;
            var f = yk(a);
            if (!f.length) return e;
            for (var h = 0; h < f.length; h++) - 1 === (f[h].labels || []).indexOf(b) ? e.push(0) : e.push(1);
            if (d) return e;
            if (1 !== e[0]) {
                var l = f[0],
                    m = f[0].timestamp,
                    n = [l.version, Math.round(m / 1E3), l.W].concat(l.labels || [], [b]).join("."),
                    p = Dj(c, m, !0);
                p.ib = vk();
                Ri(a, n, p)
            }
            return e
        };

    function bl(a, b) {
        var c = Dk(b),
            d = Rk(a, c);
        if (!d) return 0;
        for (var e = yk(d), f = 0, h = 0; h < e.length; h++) f = Math.max(f, e[h].timestamp);
        return f
    }

    function cl(a) {
        var b = 0,
            c;
        for (c in a)
            for (var d = a[c], e = 0; e < d.length; e++) b = Math.max(b, Number(d[e].timestamp));
        return b
    }
    var dl = function(a) {
        var b = Math.max(bl("aw", a), cl(wk() ? rk() : {}));
        return Math.max(bl("gb", a), cl(wk() ? rk("_gac_gb", !0) : {})) > b
    };
    var fl = function(a, b) {
            var c = a && !R(el());
            return b && c ? "0" : b
        },
        il = function(a) {
            var b = function() {
                function c(y) {
                    var A = R(el()),
                        B = m && A,
                        D;
                    ye.reported_gclid || (ye.reported_gclid = {});
                    D = ye.reported_gclid;
                    var I = function() {
                        var Z = l.prefix || "_gcl";
                        return P(61) ? (B ? Z : "") + "." + (R(L.g.H) ? 1 : 0) + "." + (R(L.g.N) ? 1 : 0) : m && R(L.g.H) ? p + "." + Z + (y ? "gcu" : "gcs") : p + (y ? "gcu" : "gcs")
                    }();
                    if (!D[I]) {
                        D[I] = !0;
                        var J = [],
                            E = {},
                            G = function(Z, U) {
                                U && (J.push(Z + "=" + encodeURIComponent(U)), E[Z] = !0)
                            },
                            M = "https://www.google.com";
                        ti() && (G("gcs", ui()), y && G("gcu",
                            "1"));
                        (P(37) || Qf()) && G("gcd", yi(h));
                        if (Pf()) {
                            G("rnd", $i());
                            if ((!p || q && "aw.ds" !== q) && A) {
                                var Q = zk("_gcl_aw");
                                G("gclaw", Q.join("."))
                            }
                            G("url", String(C.location).split(/[?#]/)[0]);
                            G("dclid", fl(e, t));
                            A || (M = "https://pagead2.googlesyndication.com")
                        }
                        P(39) && (Ci() && G("dma_cps", zi()), G("dma", Bi()));
                        P(41) && G("npa", si(h) ? "0" : "1");
                        P(62) && Uh(ci()) && G("tcfd", Di());
                        G("gdpr_consent", ki() || "");
                        G("gdpr", li() ||
                            "");
                        "1" === Sj(!1)._up && G("gtm_up", "1");
                        G("gclid", fl(e, p));
                        G("gclsrc", q);
                        if (!(E.gclid || E.dclid || E.gclaw) && (G("gbraid", fl(e, r)), !E.gbraid && Pf() && R(L.g.H))) {
                            var ba = zk("_gcl_gb");
                            0 < ba.length && G("gclgb", ba.join("."))
                        }
                        G("gtm", cj(h.eventMetadata.source_canonical_id, !f));
                        m && R(L.g.H) && (kk(l || {}), B && G("auid", ek[gk(l.prefix)] || ""));
                        hl || a.ai && G("did", a.ai);
                        a.Vf && G("gdid", a.Vf);
                        a.Rf && G("edid", a.Rf);
                        var S = P(21) ? kj() : null;
                        if (S) {
                            var O = function(Z, U) {
                                J.push(Z + "=" + encodeURIComponent(U));
                                E[Z] = !0
                            };
                            O("uaa", S.architecture);
                            O("uab", S.bitness);
                            S.fullVersionList && O("uafvl", S.fullVersionList.map(function(Z) {
                                return encodeURIComponent(Z.brand || "") + ";" + encodeURIComponent(Z.version || "")
                            }).join("|"));
                            O("uam", S.model);
                            O("uap", S.platform);
                            O("uapv", S.platformVersion);
                            O("uaw", S.wow64 ? "1" : "0")
                        }
                        var ca = M + "/pagead/landing?" + J.join("&");
                        gc(ca)
                    }
                }
                var d = !!a.Pf,
                    e = !!a.Ye,
                    f = a.targetId,
                    h = a.s,
                    l = void 0 === a.xc ? {} : a.xc,
                    m = void 0 === a.Re ? !0 : a.Re,
                    n = Fk(),
                    p = n.gclid || "",
                    q = n.gclsrc,
                    t = n.dclid || "",
                    r = n.gbraid || "",
                    u = !d && ((!p || q && "aw.ds" !== q ? !1 : !0) || r),
                    v = Pf();
                if (u || v)
                    if (v) {
                        var w = P(61) ? [L.g.H, L.g.N, L.g.ya] : [L.g.H],
                            x = function() {
                                R(w) || bg(function(y) {
                                    return c(!0, y.consentEventId, y.consentPriorityId)
                                }, w)
                            };
                        P(62) ? (c(), x()) : cg(function() {
                            c();
                            x()
                        }, w)
                    } else c()
            };
            P(62) ? cg(b, [L.g.H, L.g.N, L.g.ya]) : b()
        },
        el = function() {
            return P(61) ? [L.g.H, L.g.N] : [L.g.H]
        },
        gl = function(a) {
            var b = String(C.location).split(/[?#]/)[0],
                c = xe.Si || C._CONSENT_MODE_SALT;
            return a ? c ? String(jf(b + a + c)) : "0" : ""
        },
        hl = !1;
    var jl = /[A-Z]+/,
        kl = /\s/,
        ll = function(a, b) {
            if (g(a)) {
                a = Ia(a);
                var c = a.indexOf("-");
                if (!(0 > c)) {
                    var d = a.substring(0, c);
                    if (jl.test(d)) {
                        var e = a.substring(c + 1),
                            f;
                        if (b) {
                            var h = function(n) {
                                var p = n.indexOf("/");
                                return 0 > p ? [n] : [n.substring(0, p), n.substring(p + 1)]
                            };
                            f = h(e);
                            if ("DC" === d && 2 === f.length) {
                                var l = h(f[1]);
                                2 === l.length && (f[1] = l[0], f.push(l[1]))
                            }
                        } else {
                            f = e.split("/");
                            for (var m = 0; m < f.length; m++)
                                if (!f[m] || kl.test(f[m]) && ("AW" !== d || 1 !== m)) return
                        }
                        return {
                            id: a,
                            prefix: d,
                            ba: d + "-" + f[0],
                            O: f
                        }
                    }
                }
            }
        },
        nl = function(a, b) {
            for (var c = {}, d = 0; d < a.length; ++d) {
                var e = ll(a[d], b);
                e && (c[e.id] = e)
            }
            ml(c);
            var f = [];
            k(c, function(h, l) {
                f.push(l)
            });
            return f
        };

    function ml(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                "AW" === d.prefix && d.O[1] && b.push(d.ba)
            }
        for (var e = 0; e < b.length; ++e) delete a[b[e]]
    };
    var ol = function(a, b, c, d) {
        var e = Yb(),
            f;
        if (1 === e) a: {
            var h = Me;h = h.toLowerCase();
            for (var l = "https://" + h, m = "http://" + h, n = 1, p = F.getElementsByTagName("script"), q = 0; q < p.length && 100 > q; q++) {
                var t = p[q].src;
                if (t) {
                    t = t.toLowerCase();
                    if (0 === t.indexOf(m)) {
                        f = 3;
                        break a
                    }
                    1 === n && 0 === t.indexOf(l) && (n = 2)
                }
            }
            f = n
        }
        else f = e;
        return (2 === f || d || "http:" != C.location.protocol ? a : b) + c
    };
    var ql = function(a, b, c) {
            if (C[a.functionName]) return b.kg && H(b.kg), C[a.functionName];
            var d = pl();
            C[a.functionName] = d;
            if (a.Fe)
                for (var e = 0; e < a.Fe.length; e++) C[a.Fe[e]] = C[a.Fe[e]] || pl();
            a.Qe && void 0 === C[a.Qe] && (C[a.Qe] = c);
            Xb(ol("https://", "http://", a.qg), b.kg, b.Il);
            return d
        },
        pl = function() {
            var a = function() {
                a.q = a.q || [];
                a.q.push(arguments)
            };
            return a
        },
        rl = {
            functionName: "_googWcmImpl",
            Qe: "_googWcmAk",
            qg: "www.gstatic.com/wcm/loader.js"
        },
        sl = {
            functionName: "_gaPhoneImpl",
            Qe: "ga_wpid",
            qg: "www.gstatic.com/gaphone/loader.js"
        },
        tl = {
            Pi: "",
            fk: "5"
        },
        ul = {
            functionName: "_googCallTrackingImpl",
            Fe: [sl.functionName, rl.functionName],
            qg: "www.gstatic.com/call-tracking/call-tracking_" + (tl.Pi || tl.fk) + ".js"
        },
        vl = {},
        wl = function(a, b, c, d) {
            K(22);
            if (c) {
                d = d || {};
                var e = ql(rl, d, a),
                    f = {
                        ak: a,
                        cl: b
                    };
                void 0 === d.hb && (f.autoreplace = c);
                e(2, d.hb, f, c, 0, Ja(), d.options)
            }
        },
        xl = function(a, b, c, d) {
            K(21);
            if (b && c) {
                d = d || {};
                for (var e = {
                        countryNameCode: c,
                        destinationNumber: b,
                        retrievalTime: Ja()
                    }, f = 0; f < a.length; f++) {
                    var h = a[f];
                    vl[h.id] ||
                        (h && "AW" === h.prefix && !e.adData && 2 <= h.O.length ? (e.adData = {
                            ak: h.O[0],
                            cl: h.O[1]
                        }, vl[h.id] = !0) : h && "UA" === h.prefix && !e.gaData && (e.gaData = {
                            gaWpid: h.ba
                        }, vl[h.id] = !0))
                }(e.gaData || e.adData) && ql(ul, d)(d.hb, e, d.options)
            }
        },
        yl = function() {
            var a = !1;
            return a
        },
        zl = function(a, b) {
            if (a)
                if (aj()) {} else {
                    if (g(a)) {
                        var c =
                            ll(a);
                        if (!c) return;
                        a = c
                    }
                    var d = void 0,
                        e = !1,
                        f = T(b, L.g.Jj);
                    if (f && xa(f)) {
                        d = [];
                        for (var h = 0; h < f.length; h++) {
                            var l = ll(f[h]);
                            l && (d.push(l), (a.id === l.id || a.id === a.ba && a.ba === l.ba) && (e = !0))
                        }
                    }
                    if (!d || e) {
                        var m = T(b, L.g.mh),
                            n;
                        if (m) {
                            xa(m) ? n = m : n = [m];
                            var p = T(b, L.g.kh),
                                q = T(b, L.g.lh),
                                t = T(b, L.g.nh),
                                r = T(b, L.g.Ij),
                                u = p || q,
                                v = 1;
                            "UA" !== a.prefix || d || (v = 5);
                            for (var w = 0; w < n.length; w++)
                                if (w < v)
                                    if (d) xl(d, n[w], r, {
                                        hb: u,
                                        options: t
                                    });
                                    else if ("AW" === a.prefix && a.O[1]) yl() ? xl([a], n[w], r || "US", {
                                hb: u,
                                options: t
                            }) : wl(a.O[0], a.O[1], n[w], {
                                hb: u,
                                options: t
                            });
                            else if ("UA" === a.prefix)
                                if (yl()) xl([a], n[w], r || "US", {
                                    hb: u
                                });
                                else {
                                    var x = a.ba,
                                        y = n[w],
                                        A = {
                                            hb: u
                                        };
                                    K(23);
                                    if (y) {
                                        A = A || {};
                                        var B = ql(sl, A, x),
                                            D = {};
                                        void 0 !== A.hb ? D.receiver = A.hb : D.replace = y;
                                        D.ga_wpid = x;
                                        D.destination = y;
                                        B(2, Ja(), D)
                                    }
                                }
                        }
                    }
                }
        };
    var Al, Bl = !1,
        Cl = function(a) {
            if (!Bl) {
                Bl = !0;
                Al = Al || {}
            }
            return Al[a]
        };
    var Dl = function(a, b, c) {
        this.target = a;
        this.eventName = b;
        this.s = c;
        this.h = {};
        this.metadata = z(c.eventMetadata || {});
        this.isAborted = !1
    };
    Dl.prototype.copyToHitData = function(a, b, c) {
        var d = T(this.s, a);
        void 0 === d && (d = b);
        if (void 0 !== d && void 0 !== c && g(d) && P(68)) try {
            d = c(d)
        } catch (e) {}
        void 0 !== d && (this.h[a] = d)
    };
    var El = function(a) {
            return a.metadata.source_canonical_id
        },
        Fl = function(a, b, c) {
            var d = Cl(a.target.ba);
            return d && d.hasOwnProperty(b) ? d[b] : c
        };

    function Gl(a) {
        return {
            getDestinationId: function() {
                return a.target.ba
            },
            getEventName: function() {
                return a.eventName
            },
            setEventName: function(b) {
                a.eventName = b
            },
            getHitData: function(b) {
                return a.h[b]
            },
            setHitData: function(b, c) {
                a.h[b] = c
            },
            setHitDataIfNotDefined: function(b, c) {
                void 0 === a.h[b] && (a.h[b] = c)
            },
            copyToHitData: function(b, c) {
                a.copyToHitData(b, c)
            },
            getMetadata: function(b) {
                return a.metadata[b]
            },
            setMetadata: function(b, c) {
                a.metadata[b] = c
            },
            isAborted: function() {
                return a.isAborted
            },
            abort: function() {
                a.isAborted = !0
            },
            getFromEventContext: function(b) {
                return T(a.s, b)
            },
            dn: function() {
                return a
            },
            getHitKeys: function() {
                return Object.keys(a.h)
            }
        }
    };
    var Il = function(a) {
            var b = Hl[a.target.ba];
            if (!a.isAborted && b)
                for (var c = Gl(a), d = 0; d < b.length; ++d) {
                    try {
                        b[d](c)
                    } catch (e) {
                        a.isAborted = !0
                    }
                    if (a.isAborted) break
                }
        },
        Hl = {};
    var Ll = function(a) {
            a = a || {};
            var b;
            if (R(Jl)) {
                (b = Kl(a)) || (b = Vi());
                var c = a,
                    d = gk(c.prefix);
                ik(c, b);
                delete ek[d];
                delete fk[d];
                hk(d, c.path, c.domain);
                return Kl(a)
            }
        },
        Kl = function(a) {
            if (R(Jl)) {
                a = a || {};
                kk(a, !1);
                var b = fk[gk(Dk(a.prefix))];
                if (b && !(18E5 < Ka() - 1E3 * b.gg)) {
                    var c = b.id,
                        d = c.split(".");
                    if (2 === d.length && !(864E5 < Ka() - 1E3 * (Number(d[1]) || 0))) return c
                }
            }
        },
        Jl = L.g.H;

    function Ml(a, b) {
        if (a) {
            var c = "" + a;
            0 !== c.indexOf("http://") && 0 !== c.indexOf("https://") && (c = "https://" + c);
            "/" === c[c.length - 1] && (c = c.substring(0, c.length - 1));
            return Aj("" + c + b).href
        }
    }

    function Nl() {
        return !!xe.De && "SGTM_TOKEN" !== xe.De.split("@@").join("")
    }

    function Ol(a) {
        for (var b = ha([L.g.Zc, L.g.Pb]), c = b.next(); !c.done; c = b.next()) {
            var d = T(a, c.value);
            if (d) return d
        }
    };
    var Pl = "",
        Ql = [];

    function Rl(a) {
        var b = "";
        Pl && (b = "&dl=" + encodeURIComponent(Pl));
        0 < Ql.length && (b += "&tdp=" + Ql.join("."));
        a.Fb && (Pl = "", Ql.length = 0, b && a.Bi());
        return b
    };
    var Sl = [];

    function Tl(a) {
        if (!Sl.length) return "";
        var b = "&tdc=" + Sl.join("!");
        a.Fb && (a.Bi(), Sl.length = 0);
        return b
    };
    var Ul = {
            initialized: 11,
            complete: 12,
            interactive: 13
        },
        Vl = {},
        Wl = Object.freeze((Vl[L.g.Oa] = !0, Vl)),
        Xl = 0 <= F.location.search.indexOf("?gtm_diagnostics=") || 0 <= F.location.search.indexOf("&gtm_diagnostics="),
        Zl = function(a, b, c) {
            if (Ng && "config" === a && !(1 < ll(b).O.length)) {
                var d, e = Sb("google_tag_data", {});
                e.td || (e.td = {});
                d = e.td;
                var f = z(c.K);
                z(c.h, f);
                var h = [],
                    l;
                for (l in d) {
                    var m = Yl(d[l], f);
                    m.length && (Xl && console.log(m), h.push(l))
                }
                h.length && (h.length && Ng && Sl.push(b + "*" + h.join(".")), gb("TAGGING", Ul[F.readyState] ||
                    14));
                d[b] = f
            }
        };

    function $l(a, b) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
        for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
        return c
    }

    function Yl(a, b, c, d) {
        c = void 0 === c ? {} : c;
        d = void 0 === d ? "" : d;
        if (a === b) return [];
        var e = function(q, t) {
                var r = t[q];
                return void 0 === r ? Wl[q] : r
            },
            f;
        for (f in $l(a, b)) {
            var h = (d ? d + "." : "") + f,
                l = e(f, a),
                m = e(f, b),
                n = "object" === Va(l) || "array" === Va(l),
                p = "object" === Va(m) || "array" === Va(m);
            if (n && p) Yl(l, m, c, h);
            else if (n || p || l !== m) c[h] = !0
        }
        return Object.keys(c)
    };
    var am = {};

    function bm(a, b, c) {
        Ng && void 0 !== a && (am[a] = am[a] || [], am[a].push(c + b), Xg(a))
    }

    function cm(a) {
        var b = a.eventId,
            c = a.Fb,
            d = "",
            e = am[b] || [];
        e.length && (d += "&epr=" + e.join("."));
        c && delete am[b];
        return d
    };
    var em = function(a, b, c, d) {
            var e = ll(c, d.isGtmEvent);
            e && dm.push("event", [b, a], e, d)
        },
        fm = function(a, b, c, d) {
            var e = ll(c, d.isGtmEvent);
            e && dm.push("get", [a, b], e, d)
        },
        gm = function() {
            this.status = 1;
            this.K = {};
            this.h = {};
            this.M = {};
            this.R = null;
            this.D = {};
            this.C = !1
        },
        hm = function(a, b, c, d) {
            var e = Ka();
            this.type = a;
            this.D = e;
            this.h = b;
            this.C = c;
            this.messageContext = d
        },
        im = function() {
            this.C = {};
            this.D = {};
            this.h = []
        },
        jm = function(a, b) {
            var c = b.ba;
            return a.C[c] = a.C[c] || new gm
        },
        km = function(a, b, c, d) {
            if (d.h) {
                var e = jm(a, d.h),
                    f = e.R;
                if (f) {
                    var h =
                        z(c),
                        l = z(e.K[d.h.id]),
                        m = z(e.D),
                        n = z(e.h),
                        p = z(a.D),
                        q = {};
                    if (Ng) try {
                        q = z(Ve)
                    } catch (v) {
                        K(72)
                    }
                    var t = d.h.prefix,
                        r = function(v) {
                            bm(d.messageContext.eventId, t, v)
                        },
                        u = qh(ph(oh(nh(mh(kh(jh(lh(ih(hh(gh(new fh(d.messageContext.eventId, d.messageContext.priorityId), h), l), m), n), p), q), d.messageContext.eventMetadata), function() {
                            if (r) {
                                var v = r;
                                r = void 0;
                                v("2");
                                if (d.messageContext.onSuccess) d.messageContext.onSuccess()
                            }
                        }), function() {
                            if (r) {
                                var v = r;
                                r = void 0;
                                v("3");
                                if (d.messageContext.onFailure) d.messageContext.onFailure()
                            }
                        }), !!d.messageContext.isGtmEvent));
                    try {
                        bm(d.messageContext.eventId, t, "1"), Zl(d.type, d.h.id, u), f(d.h.id, b, d.D, u)
                    } catch (v) {
                        bm(d.messageContext.eventId, t, "4")
                    }
                }
            }
        };
    im.prototype.register = function(a, b, c) {
        var d = jm(this, a);
        3 !== d.status && (d.R = b, d.status = 3, c && (z(d.h, c), d.h = c), this.flush())
    };
    im.prototype.push = function(a, b, c, d) {
        void 0 !== c && (1 === jm(this, c).status && (jm(this, c).status = 2, this.push("require", [{}], c, {})), jm(this, c).C && (d.deferrable = !1));
        this.h.push(new hm(a, c, b, d));
        d.deferrable || this.flush()
    };
    im.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.h.length;) {
            e = {
                Ab: e.Ab,
                Ke: e.Ke
            };
            var f = this.h[0],
                h = f.h;
            if (f.messageContext.deferrable) !h || jm(this, h).C ? (f.messageContext.deferrable = !1, this.h.push(f)) : c.push(f), this.h.shift();
            else {
                switch (f.type) {
                    case "require":
                        if (3 !== jm(this, h).status && !a) {
                            this.h.push.apply(this.h, c);
                            return
                        }
                        break;
                    case "set":
                        k(f.C[0], function(t, r) {
                            z(Qa(t, r), b.D)
                        });
                        break;
                    case "config":
                        var l = jm(this, h);
                        e.Ab = {};
                        k(f.C[0], function(t) {
                            return function(r, u) {
                                z(Qa(r, u), t.Ab)
                            }
                        }(e));
                        var m = !!e.Ab[L.g.Qb];
                        delete e.Ab[L.g.Qb];
                        var n = h.ba === h.id;
                        m || (n ? l.D = {} : l.K[h.id] = {});
                        l.C && m || km(this, L.g.qa, e.Ab, f);
                        l.C = !0;
                        n ? z(e.Ab, l.D) : (z(e.Ab, l.K[h.id]), K(70));
                        d = !0;
                        break;
                    case "event":
                        e.Ke = {};
                        k(f.C[0], function(t) {
                            return function(r, u) {
                                z(Qa(r, u), t.Ke)
                            }
                        }(e));
                        km(this, f.C[1], e.Ke, f);
                        break;
                    case "get":
                        var p = {},
                            q = (p[L.g.cb] = f.C[0], p[L.g.pb] = f.C[1], p);
                        km(this, L.g.La, q, f)
                }
                this.h.shift();
                lm(this, f)
            }
        }
        this.h.push.apply(this.h, c);
        d && this.flush()
    };
    var lm = function(a, b) {
            if ("require" !== b.type)
                if (b.h)
                    for (var c = jm(a, b.h).M[b.type] || [], d = 0; d < c.length; d++) c[d]();
                else
                    for (var e in a.C)
                        if (a.C.hasOwnProperty(e)) {
                            var f = a.C[e];
                            if (f && f.M)
                                for (var h = f.M[b.type] || [], l = 0; l < h.length; l++) h[l]()
                        }
        },
        mm = function(a, b) {
            var c = dm,
                d = z(b);
            z(jm(c, a).h, d);
            jm(c, a).h = d
        },
        dm = new im;
    var nm = function(a, b, c) {
            var d = ye.joined_auid = ye.joined_auid || {},
                e = (c ? a || "_gcl" : "") + "." + b;
            if (d[e]) return !0;
            d[e] = !0;
            return !1
        },
        om = function() {
            var a = Aj(C.location.href),
                b = yj(a, "query", !1, void 0, "gad_source");
            if (void 0 === b) {
                var c = a.hash.replace("#", "");
                b = vj(c, "gad_source")
            }
            return b
        },
        pm = function() {
            var a = Aj(C.location.href).search.replace("?", "");
            return "1" === vj(a, "gad", !0)
        },
        qm = function(a) {
            var b = [];
            k(a, function(c, d) {
                d = Ck(d);
                for (var e = [], f = 0; f < d.length; f++) e.push(d[f].W);
                e.length && b.push(c + ":" + e.join(","))
            });
            return b.join(";")
        },
        sm = function(a, b, c) {
            if ("aw" === a || "dc" === a || "gb" === a) {
                var d = Cj("gcl" + a);
                if (d) return d.split(".")
            }
            var e = Dk(b);
            if ("_gcl" == e) {
                c = void 0 === c ? !0 : c;
                var f = !R(rm()) && c,
                    h;
                h = Fk()[a] || [];
                if (0 < h.length) return f ? ["0"] : h
            }
            var l = Rk(a, e);
            return l ? zk(l) : []
        },
        tm = function(a) {
            var b = rm();
            cg(function() {
                a();
                R(b) || Uf(a, b)
            }, b)
        },
        rm = function() {
            return P(61) ? [L.g.H, L.g.N] : [L.g.H]
        },
        um = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
        vm = /^www.googleadservices.com$/,
        wm = function(a, b) {
            return sm("aw", a, b)
        },
        xm = function(a, b) {
            return sm("dc",
                a, b)
        },
        ym = function(a) {
            var b = Cj("gac");
            return b ? !R(rm()) && a ? "0" : decodeURIComponent(b) : qm(wk() ? rk() : {})
        },
        zm = function(a) {
            var b = Cj("gacgb");
            return b ? !R(rm()) && a ? "0" : decodeURIComponent(b) : qm(wk() ? rk("_gac_gb", !0) : {})
        },
        Am = function(a, b, c) {
            var d = Fk(),
                e = [],
                f = d.gclid,
                h = d.dclid,
                l = d.gclsrc || "aw",
                m = pm(),
                n = om();
            !f || "aw.ds" !== l && "aw" !== l && "ds" !== l || e.push({
                W: f,
                zd: l
            });
            h && e.push({
                W: h,
                zd: "ds"
            });
            0 === e.length && d.gbraid && e.push({
                W: d.gbraid,
                zd: "gb"
            });
            P(27) && 0 === e.length && "aw.ds" === l && e.push({
                W: "",
                zd: "aw.ds"
            });
            tm(function() {
                if (P(61) &&
                    P(66) || R(L.g.H)) {
                    var p = R(rm());
                    kk(a);
                    var q;
                    if (p && (q = ek[gk(a.prefix)], void 0 === q && !P(61))) return;
                    var t = [];
                    q && t.push("auid=" + q);
                    if (P(9)) {
                        var r = F.referrer ? yj(Aj(F.referrer), "host") : "";
                        0 === e.length && (um.test(r) || vm.test(r)) && e.push({
                            W: "",
                            zd: ""
                        });
                        if (0 === e.length && !m && void 0 === n) return;
                        r && t.push("ref=" + encodeURIComponent(r));
                        var u = 1 === Mh(!0) ? C.top.location.href : C.location.href;
                        u = u.replace(/[\?#].*$/, "");
                        t.push("url=" + encodeURIComponent(u));
                        t.push("tft=" + Ka());
                        var v = jc();
                        void 0 !== v && t.push("tfd=" + Math.round(v));
                        var w = Mh(!0);
                        t.push("frm=" + w);
                        m && t.push("gad=1");
                        void 0 !== n && t.push("gad_source=" + encodeURIComponent(n))
                    }
                    if (P(93)) {
                        var x = c;
                        void 0 === x && (x = dm.D[L.g.X]);
                        var y = {},
                            A = qh(gh(new fh(0), (y[L.g.X] = x, y)));
                        t.push("gtm=" + cj(b), "gcs=" + ui(), "gcd=" + yi(A));
                        P(39) && (Ci() && t.push("dma_cps=" + zi()), t.push("dma=" + Bi()));
                        si(A) ? P(41) && t.push("npa=0") : t.push("npa=1");
                        if (P(62)) {
                            Uh(ci()) && t.push("tcfd=" + Di());
                            var B = li();
                            B && t.push("gdpr=" + B);
                            var D = ki();
                            D && t.push("gdpr_consent=" + D)
                        }
                    }
                    var I = p ? 'https://adservice.google.com/pagead/regclk' :
                        "https://adservice.googlesyndication.com/pagead/regclk";
                    if (0 < e.length)
                        for (var J = 0; J < e.length; J++) {
                            var E = e[J],
                                G = E.W,
                                M = E.zd;
                            if (!nm(a.prefix, M + "." + G, void 0 !== q)) {
                                var Q = I + "?" + t.join("&");
                                "" !== G ? Q = "gb" === M ? Q + "&wbraid=" + G : Q + "&gclid=" + G + "&gclsrc=" + M : "aw.ds" === M && (Q += "&gclsrc=aw.ds");
                                gc(Q)
                            }
                        } else if ((m || void 0 !== n) && !nm(a.prefix, "gad", void 0 !== q)) {
                            var ba = I + "?" + t.join("&");
                            gc(ba)
                        }
                }
            })
        },
        Bm = function(a) {
            return Cj("gclaw") || Cj("gac") || 0 < (Fk().aw || []).length ? !1 : 0 < (Fk().gb || []).length ? !0 : dl(a)
        };
    var Dm = function(a, b) {
            var c = a.ji,
                d = a.Ii,
                e = a.bf,
                f = a.Vh;
            a.Yh && (ck(c[L.g.Vc], !!c[L.g.T]) && (Tk(Cm, b), ok(b)), Qk(b), Wk(Cm, b), Am(b, e, f));
            c[L.g.T] && (Vk(Cm, c[L.g.T], c[L.g.qc], !!c[L.g.Mb], b.prefix), pk(gk(b.prefix), c[L.g.T], c[L.g.qc], !!c[L.g.Mb], b), pk("FPAU", c[L.g.T], c[L.g.qc], !!c[L.g.Mb], b));
            d && Yk(Cm);
            $k(Cm)
        },
        Em = function(a, b, c, d) {
            var e = a.Li,
                f = a.callback,
                h = a.ki;
            if ("function" === typeof f)
                if (e === L.g.kb && void 0 === h) {
                    var l = d(b.prefix, c);
                    0 === l.length ? f(void 0) : 1 === l.length ? f(l[0]) : f(l)
                } else e === L.g.Hb ? (K(65), kk(b, !1), f(ek[gk(b.prefix)])) : f(h)
        },
        Cm = ["aw", "dc", "gb"];

    function Fm(a) {
        var b = T(a.s, L.g.sb),
            c = T(a.s, L.g.rb);
        b && !c ? (a.eventName !== L.g.qa && a.eventName !== L.g.Td && K(131), a.isAborted = !0) : !b && c && (K(132), a.isAborted = !0)
    };
    var Gm = function() {
        var a = Qb && Qb.userAgent || "";
        if (0 > a.indexOf("Safari") || /Chrome|Coast|Opera|Edg|Silk|Android/.test(a)) return !1;
        var b = (/Version\/([\d\.]+)/.exec(a) || [])[1] || "";
        if ("" === b) return !1;
        for (var c = ["14", "1", "1"], d = b.split("."), e = 0; e < d.length; e++) {
            if (void 0 === c[e]) return !0;
            if (d[e] != c[e]) return Number(d[e]) > Number(c[e])
        }
        return d.length >= c.length
    };
    var Hm = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
        Im = /^www.googleadservices.com$/,
        Km = function(a) {
            a || (a = Jm());
            return a.om ? !1 : a.Zk || a.al || a.bl || a.Wf || a.Ne || a.Lk || a.Rk ? !0 : !1
        },
        Jm = function() {
            var a = {},
                b = Sj(!0);
            a.om = !!b._up;
            var c = Fk();
            a.Zk = void 0 !== c.aw;
            a.al = void 0 !== c.dc;
            a.bl = void 0 !== c.gbraid;
            var d = Aj(C.location.href),
                e = yj(d, "query", !1, void 0, "gad");
            a.Wf = void 0 !== e;
            if (!a.Wf) {
                var f = d.hash.replace("#", ""),
                    h = vj(f, "gad");
                a.Wf = void 0 !== h
            }
            a.Ne = void 0;
            if (P(76)) {
                var l = yj(d, "query", !1, void 0, "gad_source");
                a.Ne =
                    l;
                if (void 0 === a.Ne) {
                    var m = d.hash.replace("#", ""),
                        n = vj(m, "gad_source");
                    a.Ne = n
                }
            }
            var p = F.referrer ? yj(Aj(F.referrer), "host") : "";
            a.Rk = Hm.test(p);
            a.Lk = Im.test(p);
            return a
        };
    var Lm = function() {
            var a = C.screen;
            return {
                width: a ? a.width : 0,
                height: a ? a.height : 0
            }
        },
        Mm = function(a) {
            if (F.hidden) return !0;
            var b = a.getBoundingClientRect();
            if (b.top == b.bottom || b.left == b.right || !C.getComputedStyle) return !0;
            var c = C.getComputedStyle(a, null);
            if ("hidden" === c.visibility) return !0;
            for (var d = a, e = c; d;) {
                if ("none" === e.display) return !0;
                var f = e.opacity,
                    h = e.filter;
                if (h) {
                    var l = h.indexOf("opacity(");
                    0 <= l && (h = h.substring(l + 8, h.indexOf(")", l)), "%" == h.charAt(h.length - 1) && (h = h.substring(0, h.length - 1)), f = Math.min(h,
                        f))
                }
                if (void 0 !== f && 0 >= f) return !0;
                (d = d.parentElement) && (e = C.getComputedStyle(d, null))
            }
            return !1
        };
    var Wm = function(a, b, c) {
            var d = a.element,
                e = {
                    U: a.U,
                    type: a.ja,
                    tagName: d.tagName
                };
            b && (e.querySelector = Vm(d));
            c && (e.isVisible = !Mm(d));
            return e
        },
        Xm = function(a, b, c) {
            return Wm({
                element: a.element,
                U: a.U,
                ja: "1"
            }, b, c)
        },
        Ym = function(a) {
            var b = !!a.Gd + "." + !!a.Hd;
            a && a.Le && a.Le.length && (b += "." + a.Le.join("."));
            a && a.eb && (b += "." + a.eb.email + "." + a.eb.phone + "." + a.eb.address);
            return b
        },
        an = function(a) {
            if (0 != a.length) {
                var b;
                b = Zm(a, function(c) {
                    return !$m.test(c.U)
                });
                b = Zm(b, function(c) {
                    return "INPUT" === c.element.tagName.toUpperCase()
                });
                b = Zm(b, function(c) {
                    return !Mm(c.element)
                });
                return b[0]
            }
        },
        bn = function(a, b) {
            if (!b || 0 === b.length) return a;
            for (var c = [], d = 0; d < a.length; d++) {
                for (var e = !0, f = 0; f < b.length; f++) {
                    var h = b[f];
                    if (h && Hd(a[d].element, h)) {
                        e = !1;
                        break
                    }
                }
                e && c.push(a[d])
            }
            return c
        },
        Zm = function(a, b) {
            if (1 >= a.length) return a;
            var c = a.filter(b);
            return 0 == c.length ? a : c
        },
        Vm = function(a) {
            var b;
            if (a === F.body) b = "body";
            else {
                var c;
                if (a.id) c = "#" + a.id;
                else {
                    var d;
                    if (a.parentElement) {
                        var e;
                        a: {
                            var f = a.parentElement;
                            if (f) {
                                for (var h = 0; h < f.childElementCount; h++)
                                    if (f.children[h] ===
                                        a) {
                                        e = h + 1;
                                        break a
                                    }
                                e = -1
                            } else e = 1
                        }
                        d = Vm(a.parentElement) + ">:nth-child(" + e + ")"
                    } else d = "";
                    c = d
                }
                b = c
            }
            return b
        },
        dn = function(a) {
            for (var b = [], c = 0; c < a.length; c++) {
                var d = a[c],
                    e = d.textContent;
                "INPUT" === d.tagName.toUpperCase() && d.value && (e = d.value);
                if (e) {
                    var f = e.match(cn);
                    if (f) {
                        var h = f[0],
                            l;
                        if (C.location) {
                            var m = xj(C.location, "host", !0);
                            l = 0 <= h.toLowerCase().indexOf(m)
                        } else l = !1;
                        l || b.push({
                            element: d,
                            U: h
                        })
                    }
                }
            }
            return b
        },
        hn = function() {
            var a = [],
                b = F.body;
            if (!b) return {
                elements: a,
                status: "4"
            };
            for (var c = b.querySelectorAll("*"),
                    d = 0; d < c.length && 1E4 > d; d++) {
                var e = c[d];
                if (!(0 <= en.indexOf(e.tagName.toUpperCase())) && e.children instanceof HTMLCollection) {
                    for (var f = !1, h = 0; h < e.childElementCount && 1E4 > h; h++)
                        if (!(0 <= fn.indexOf(e.children[h].tagName.toUpperCase()))) {
                            f = !0;
                            break
                        }(!f || P(42) && -1 !== gn.indexOf(e.tagName)) && a.push(e)
                }
            }
            return {
                elements: a,
                status: 1E4 < c.length ? "2" : "1"
            }
        },
        jn = !1;
    var cn = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i,
        kn = /@(gmail|googlemail)\./i,
        $m = /support|noreply/i,
        en = "SCRIPT STYLE IMG SVG PATH BR NOSCRIPT TEXTAREA".split(" "),
        fn = ["BR"],
        ln = {
            ym: "1",
            Om: "2",
            Em: "3",
            Im: "4",
            sm: "5",
            Pm: "6",
            Km: "7"
        },
        mn = {},
        gn = ["INPUT", "SELECT"];
    var Fn = function() {
            var a = {
                Gd: !0,
                Hd: !0,
                Ai: !0
            };
            a = a || {
                Gd: !0,
                Hd: !0
            };
            a.eb = a.eb || {
                email: !0,
                phone: !1,
                address: !1
            };
            var b = Ym(a),
                c = mn[b];
            if (c && 200 > Ka() - c.timestamp) return c.result;
            var d = hn(),
                e = d.status,
                f = [],
                h, l, m = [];
            if (!P(42)) {
                if (a.eb && a.eb.email) {
                    var n = dn(d.elements);
                    f = bn(n, a && a.Le);
                    h = an(f);
                    10 < n.length && (e = "3")
                }!a.Ai && h && (f = [h]);
                for (var p = 0; p < f.length; p++) m.push(Xm(f[p], a.Gd, a.Hd));
                m = m.slice(0, 10)
            } else if (a.eb) {}
            h && (l = Xm(h, a.Gd, a.Hd));
            var D = {
                elements: m,
                Ol: l,
                status: e
            };
            mn[b] = {
                timestamp: Ka(),
                result: D
            };
            return D
        },
        Gn = function(a) {
            return a.tagName + ":" + a.isVisible + ":" + a.U.length + ":" + kn.test(a.U)
        };
    var Hn = {
        ik: Number('') || 500,
        Qj: Number('') || 5E3,
        Fh: Number('') || 10,
        aj: Number('') || 5E3
    };

    function In(a) {
        return a.performance && a.performance.now() || Date.now()
    }
    var Jn = function(a, b) {
        var c;
        return c
    };
    var Kn = "https://" + xe.Gc,
        Ln = Kn + "/gtm/static/",
        Mn = Number('') || 5,
        Nn = Kn,
        On = Ln,
        Pn = !1,
        Qn = 0,
        Rn = za();

    function $n() {
        var a = !1;
        return a
    }

    function ao(a) {}

    function co(a, b, c) {}

    function Wn(a, b, c) {}

    function bo(a, b, c, d) {}

    function eo(a) {}

    function fo(a, b, c, d) {}

    function go() {
        return "attribution-reporting"
    }

    function ho(a) {
        var b;
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !c.allowedFeatures().includes(a))
    };
    var io = !1;

    function jo() {
        if (ho("join-ad-interest-group") && ua(Qb.joinAdInterestGroup)) return !0;
        io || (Kh('AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9'), io = !0);
        return ho("join-ad-interest-group") && ua(Qb.joinAdInterestGroup)
    }

    function ko(a, b) {
        var c = void 0;
        try {
            c = F.querySelector('iframe[data-tagging-id="' + b + '"]')
        } catch (e) {}
        if (c) {
            var d = Number(c.dataset.loadTime);
            if (d && 6E4 > Ka() - d) {
                gb("TAGGING", 9);
                return
            }
            try {
                c.parentNode.removeChild(c)
            } catch (e) {}
            c = void 0
        } else try {
            if (50 <= F.querySelectorAll('iframe[allow="join-ad-interest-group"][data-tagging-id*="-"]').length) {
                gb("TAGGING", 10);
                return
            }
        } catch (e) {}
        Zb(a, void 0, {
            allow: "join-ad-interest-group"
        }, {
            taggingId: b,
            loadTime: Ka()
        }, c)
    }

    function lo() {
        return "https://td.doubleclick.net"
    };
    var mo = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        no = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        oo = /^\d+\.fls\.doubleclick\.net$/,
        po = /;gac=([^;?]+)/,
        qo = /;gacgb=([^;?]+)/,
        ro = /;gclaw=([^;?]+)/,
        so = /;gclgb=([^;?]+)/;

    function to(a, b) {
        if (oo.test(F.location.host)) {
            var c = F.location.href.match(b);
            return c && 2 == c.length && c[1].match(mo) ? decodeURIComponent(c[1]) : ""
        }
        var d = [],
            e;
        for (e in a) {
            for (var f = [], h = a[e], l = 0; l < h.length; l++) f.push(h[l].W);
            d.push(e + ":" + f.join(","))
        }
        return 0 < d.length ? d.join(";") : ""
    }
    var uo = function(a, b, c) {
        var d = wk() ? rk("_gac_gb", !0) : {},
            e = [],
            f = !1,
            h;
        for (h in d) {
            var l = al("_gac_gb_" + h, a, b, c);
            f = f || 0 !== l.length && l.some(function(m) {
                return 1 === m
            });
            e.push(h + ":" + l.join(","))
        }
        return {
            Kk: f ? e.join(";") : "",
            Jk: to(d, qo)
        }
    };

    function vo(a, b, c) {
        if (oo.test(F.location.host)) {
            var d = F.location.href.match(c);
            if (d && 2 == d.length && d[1].match(no)) return [{
                W: d[1]
            }]
        } else return yk((a || "_gcl") + b);
        return []
    }
    var wo = function(a) {
            return vo(a, "_aw", ro).map(function(b) {
                return b.W
            }).join(".")
        },
        xo = function(a) {
            return vo(a, "_gb", so).map(function(b) {
                return b.W
            }).join(".")
        },
        yo = function(a, b) {
            var c = al((b && b.prefix || "_gcl") + "_gb", a, b);
            return 0 === c.length || c.every(function(d) {
                return 0 === d
            }) ? "" : c.join(".")
        };
    var zo = function() {
        if (ua(C.__uspapi)) {
            var a = "";
            try {
                C.__uspapi("getUSPData", 1, function(b, c) {
                    if (c && b) {
                        var d = b.uspString;
                        d && RegExp("^[\\da-zA-Z-]{1,20}$").test(d) && (a = d)
                    }
                })
            } catch (b) {}
            return a
        }
    };
    var Ao = function() {
            return P(61) ? [L.g.H, L.g.N] : [L.g.H]
        },
        Bo = function(a) {
            if (null != a) {
                var b = String(a).substring(0, 512),
                    c = b.indexOf("#");
                return -1 == c ? b : b.substring(0, c)
            }
            return ""
        },
        Co = function() {
            var a = F.title;
            if (void 0 == a || "" == a) return "";
            var b = function(d) {
                try {
                    return decodeURIComponent(d), !0
                } catch (e) {
                    return !1
                }
            };
            a = encodeURIComponent(a);
            for (var c = 256; !b(a.substr(0, c));) c--;
            return decodeURIComponent(a.substr(0, c))
        },
        Do = function(a) {
            a.metadata.speculative_in_message || (a.metadata.speculative = !1)
        },
        Eo = function(a, b) {
            xa(b) ||
                (b = [b]);
            return 0 <= b.indexOf(a.metadata.hit_type)
        },
        Fo = function(a) {
            var b = a.target.O[0];
            if (b) {
                a.h[L.g.kc] = b;
                var c = a.target.O[1];
                c && (a.h[L.g.ab] = c)
            } else a.isAborted = !0
        },
        Go = function(a) {
            if (Eo(a, ["conversion", "remarketing", "user_data_lead", "user_data_web"])) {
                var b = a.h[L.g.ab],
                    c = !0 === T(a.s, L.g.rf);
                c && (a.metadata.remarketing_only = !0);
                switch (a.metadata.hit_type) {
                    case "conversion":
                        !c && b && Do(a);
                        gf() && (a.metadata.is_gcp_conversion = !0);
                        break;
                    case "user_data_lead":
                    case "user_data_web":
                        !c && b && (a.isAborted = !0);
                        break;
                    case "remarketing":
                        !c && b || Do(a)
                }
                a.h[L.g.Ch] = a.metadata.is_gcp_conversion ? "www.google.com" : "www.googleadservices.com"
            }
        },
        Ho = function(a) {
            Eo(a, ["conversion", "remarketing"])
        },
        Io = function(a) {
            if (Eo(a, ["conversion", "remarketing"])) {
                var b = Mh(!1);
                a.h[L.g.gh] = b;
                var c = T(a.s, L.g.za);
                c || (c = 1 === b ? C.top.location.href : C.location.href);
                a.h[L.g.za] = Bo(c);
                a.copyToHitData(L.g.Ia, F.referrer);
                a.h[L.g.tb] = Co();
                a.copyToHitData(L.g.Ga);
                var d = Lm();
                a.h[L.g.ub] = d.width + "x" + d.height;
                if (P(31)) {
                    for (var e, f = C, h = f; f && f != f.parent;) f =
                        f.parent, Ih(f) && (h = f);
                    e = h;
                    var l;
                    var m = e.location.href;
                    if (e === e.top) l = {
                        url: m,
                        rl: !0
                    };
                    else {
                        var n = !1,
                            p = e.document;
                        p && p.referrer && (m = p.referrer, e.parent === e.top && (n = !0));
                        var q = e.location.ancestorOrigins;
                        if (q) {
                            var t = q[q.length - 1];
                            t && -1 === m.indexOf(t) && (n = !1, m = t)
                        }
                        l = {
                            url: m,
                            rl: n
                        }
                    }
                    var r = l;
                    r.url && c !== r.url && (a.h[L.g.Ff] = Bo(r.url))
                }
            }
        },
        Jo = function(a) {
            Eo(a, ["conversion", "remarketing"]) && (a.copyToHitData(L.g.wa), a.copyToHitData(L.g.fa), a.copyToHitData(L.g.sa), "remarketing" !== a.metadata.hit_type && !P(58) || P(61) &&
                !R(L.g.N) || a.copyToHitData(L.g.Pa))
        },
        Ko = function(a) {
            if (P(8))
                if (!mj()) K(87);
                else if (void 0 !== oj) {
                K(85);
                var b = kj();
                b ? sj(b, a) : K(86)
            }
        },
        No = function(a) {
            !Eo(a, ["conversion"]) || P(61) && !R(L.g.N) || (!0 === C._gtmpcm || Gm() ? a.h[L.g.Jb] = "2" : P(5) && (Lo || ho(go()) || (Kh('AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9'), Lo = !0), Mo || (Mo = !0, Kh('A+xK4jmZTgh1KBVry/UZKUE3h6Dr9HPPioFS4KNCzify+KEoOii7z/goKS2zgbAOwhpZ1GZllpdz7XviivJM9gcAAACFeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiQXR0cmlidXRpb25SZXBvcnRpbmdDcm9zc0FwcFdlYiIsImV4cGlyeSI6MTcwNzI2Mzk5OSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ\x3d\x3d')), ho(go()) && (a.h[L.g.Jb] = "1")))
        },
        Oo = function(a) {
            Eo(a, ["conversion", "remarketing"]) && P(6) && R(L.g.H) && (!P(61) || R(L.g.N)) && !1 !==
                T(a.s, L.g.Ca) && !1 !== T(a.s, L.g.X) && !1 !== T(a.s, L.g.Ib) && !1 !== T(a.s, L.g.Oa) && jo() && (a.h[L.g.Pg] = "1", a.metadata.send_fledge_experiment = !0)
        },
        Po = function(a) {
            var b = function(d) {
                return T(a.s, d)
            };
            a.metadata.conversion_linker_enabled = !1 !== b(L.g.Da);
            var c = {
                prefix: b(L.g.Ma) || b(L.g.Na),
                domain: b(L.g.Ra),
                Bb: b(L.g.Fa),
                flags: b(L.g.Sa)
            };
            a.metadata.cookie_options = c;
            a.metadata.redact_ads_data = null != b(L.g.ra) && !1 !== b(L.g.ra);
            a.metadata.allow_ad_personalization = !1 !== b(L.g.X)
        },
        Qo = function(a) {
            if (Fl(a, "ccd_add_1p_data", !1) &&
                R(Ao())) {
                var b = a.s.C[L.g.we];
                if (ef(b)) {
                    var c = T(a.s, L.g.Aa);
                    null === c ? a.metadata.user_data_from_code = null : (b.enable_code && Ya(c) && (a.metadata.user_data_from_code = c), Ya(b.selectors) && (a.metadata.user_data_from_manual = df(b.selectors)))
                }
            }
        },
        Ro = function(a) {
            var b = !a.metadata.send_user_data_hit && Eo(a, ["conversion", "user_data_web"]),
                c = !Fl(a, "ccd_add_1p_data", !1) && Eo(a, "user_data_lead");
            if ((b || c) && R(L.g.H)) {
                var d = "conversion" === a.metadata.hit_type,
                    e = a.s,
                    f = void 0,
                    h = T(e, L.g.Aa);
                if (d) {
                    var l = (T(e, L.g.de) || {})[a.h[L.g.ab]];
                    if (!0 === T(e, L.g.Ud) || l) {
                        var m;
                        var n;
                        if (l) b: {
                            switch (l.enhanced_conversions_mode) {
                                case "manual":
                                    if (h && Ya(h)) {
                                        n = h;
                                        break b
                                    }
                                    var p = l.enhanced_conversions_manual_var;
                                    n = void 0 !== p ? p : C.enhanced_conversion_data;
                                    break b;
                                case "automatic":
                                    n = df(l[L.g.Ng]);
                                    break b
                            }
                            n = void 0
                        }
                        else n = C.enhanced_conversion_data;
                        var q = n,
                            t = (l || {}).enhanced_conversions_mode,
                            r;
                        if (q) {
                            if ("manual" === t) switch (q._tag_mode) {
                                case "CODE":
                                    r = "c";
                                    break;
                                case "AUTO":
                                    r = "a";
                                    break;
                                case "MANUAL":
                                    r = "m";
                                    break;
                                default:
                                    r = "c"
                            } else r = "automatic" === t ? ff(l) ? "a" :
                                "m" : "c";
                            m = {
                                U: q,
                                Ki: r
                            }
                        } else m = {
                            U: q,
                            Ki: void 0
                        };
                        var u = m,
                            v = u.Ki;
                        f = u.U;
                        a.h[L.g.ve] = v
                    }
                } else if (a.s.isGtmEvent) {
                    Do(a);
                    a.metadata.user_data = h;
                    return
                }
                a.metadata.user_data = f
            }
        },
        So = function(a) {
            Eo(a, ["conversion", "remarketing"]) && (a.s.isGtmEvent ? "conversion" !== a.metadata.hit_type && a.eventName && (a.h[L.g.Og] = a.eventName) : a.h[L.g.Og] = a.eventName, k(a.s.h, function(b, c) {
                te[b.split(".")[0]] || (a.h[b] = c)
            }))
        },
        To = function(a) {
            if (a.eventName === L.g.qa && (a.metadata.is_config_command = !0, Eo(a, "conversion") && (a.metadata.speculative = !0), !Eo(a, "remarketing") || !1 !== T(a.s, L.g.Ib) && !1 !== T(a.s, L.g.Oa) || (a.metadata.speculative = !0), Eo(a, "landing_page"))) {
                var b = T(a.s, L.g.nb),
                    c = T(a.s, L.g.Ha) || {},
                    d = T(a.s, L.g.wb),
                    e = a.metadata.conversion_linker_enabled,
                    f = El(a),
                    h = T(a.s, L.g.X),
                    l = a.metadata.cookie_options;
                Dm({
                    Yh: e,
                    yk: b,
                    ji: c,
                    Ii: d,
                    bf: f,
                    Vh: h
                }, l);
                zl(a.target, a.s);
                il({
                    Pf: !1,
                    Ye: a.metadata.redact_ads_data,
                    targetId: a.target.id,
                    s: a.s,
                    xc: e ? l : void 0,
                    Re: e,
                    ai: a.h[L.g.Af],
                    Vf: a.h[L.g.qb],
                    Rf: a.h[L.g.ob]
                });
                a.isAborted = !0
            }
        },
        Uo = function(a) {
            if (!Fl(a, "hasPreAutoPiiCcdRule", !1) && Eo(a, "conversion") && R(L.g.H)) {
                var b = (T(a.s, L.g.de) || {})[a.h[L.g.ab]],
                    c = a.h[L.g.kc],
                    d;
                if (!(d = ff(b)))
                    if (uf())
                        if (jn) d = !0;
                        else {
                            var e = Cl("AW-" + c);
                            d = !!e && !!e.preAutoPii
                        }
                else d = !1;
                if (d) {
                    var f = Ka(),
                        h = Fn();
                    if (0 !== h.elements.length) {
                        for (var l = [], m = 0; m < h.elements.length; ++m) {
                            var n = h.elements[m];
                            l.push(n.querySelector + "*" + Gn(n) + "*" + n.type)
                        }
                        a.h[L.g.rh] = l.join("~");
                        var p = h.Ol;
                        p && (a.h[L.g.sh] = p.querySelector, a.h[L.g.qh] = Gn(p));
                        a.h[L.g.ph] = String(Ka() - f);
                        a.h[L.g.th] = h.status
                    }
                }
            }
        },
        Vo = function(a) {
            if (a.eventName ===
                L.g.La && !a.s.isGtmEvent) {
                if (!a.metadata.consent_updated && Eo(a, "conversion")) {
                    var b = T(a.s, L.g.pb);
                    if ("function" !== typeof b) return;
                    var c = String(T(a.s, L.g.cb)),
                        d = a.h[c],
                        e = T(a.s, c);
                    c === L.g.kb || c === L.g.Hb ? Em({
                        Li: c,
                        callback: b,
                        ki: e
                    }, a.metadata.cookie_options, a.metadata.redact_ads_data, wm) : b(d || e)
                }
                a.isAborted = !0
            }
        },
        Wo = function(a) {
            if (Eo(a, "conversion") && R(L.g.H) && (a.h[L.g.sc] || a.h[L.g.oc])) {
                var b = a.h[L.g.ab],
                    c = z(a.metadata.cookie_options),
                    d = Dk(c.prefix);
                c.prefix = "_gcl" === d ? "" : d;
                if (a.h[L.g.sc]) {
                    var e = yo(b, c);
                    e && (a.h[L.g.wh] = e)
                }
                if (a.h[L.g.oc]) {
                    var f = uo(b, c).Kk;
                    f && (a.h[L.g.Yg] = f)
                }
            }
        },
        Xo = function(a) {
            var b = P(4),
                c = a.s,
                d, e, f;
            if (!b) {
                var h = dh(c, L.g.aa);
                d = Sa(Ya(h) ? h : {})
            }
            var l = dh(c, L.g.aa, 1),
                m = dh(c, L.g.aa, 2);
            e = Sa(Ya(l) ? l : {}, ".");
            f = Sa(Ya(m) ? m : {}, ".");
            b || (a.h[L.g.Af] = d);
            a.h[L.g.qb] = e;
            a.h[L.g.ob] = f
        },
        Yo = function(a) {
            if (Eo(a, ["conversion", "remarketing"])) {
                var b = "conversion" === a.metadata.hit_type;
                b && a.eventName !== L.g.oa || (a.copyToHitData(L.g.Z), b && (a.copyToHitData(L.g.Yd), a.copyToHitData(L.g.Wd), a.copyToHitData(L.g.Xd),
                    a.copyToHitData(L.g.Vd), a.h[L.g.Ig] = a.eventName))
            }
        },
        Zo = function(a) {
            if (Eo(a, ["conversion", "remarketing", "user_data_lead", "user_data_web"])) {
                var b = a.s;
                if (Eo(a, ["conversion", "remarketing"])) {
                    var c = T(b, L.g.Nb);
                    if (!0 === c || !1 === c) a.h[L.g.Nb] = c
                }
                var d = T(b, L.g.X);
                P(41) ? a.h[L.g.vc] = !si(a.s) : !Eo(a, ["conversion", "remarketing"]) || !0 !== d && !1 !== d || (a.h[L.g.vc] = !d);
                !1 === d && Eo(a, "remarketing") && (a.isAborted = !0)
            }
        },
        $o = function(a) {
            Eo(a, "conversion") && (a.copyToHitData(L.g.Wc), a.copyToHitData(L.g.Zd), a.copyToHitData(L.g.bd),
                a.copyToHitData(L.g.ee), a.copyToHitData(L.g.nc), a.copyToHitData(L.g.Sc))
        },
        ap = function(a) {
            Il(a);
        },
        bp = function(a) {
            if (Eo(a, ["conversion", "remarketing"]) && C.__gsaExp && C.__gsaExp.id) {
                var b = C.__gsaExp.id;
                if (ua(b)) try {
                    var c = Number(b());
                    isNaN(c) || (a.h[L.g.fh] = c)
                } catch (d) {}
            }
        },
        cp = function(a) {
            if (Eo(a, ["conversion", "remarketing"])) {
                var b = zo();
                void 0 !== b && (a.h[L.g.vh] = b || "error");
                var c = li();
                c && (a.h[L.g.me] = c);
                var d = ki();
                d && (a.h[L.g.ue] =
                    d)
            }
        },
        dp = function(a) {
            Eo(a, ["conversion"]) && "1" === Sj(!1)._up && (a.h[L.g.oe] = !0)
        },
        ep = function(a) {
            Eo(a, ["conversion"]) && (a.metadata.redact_click_ids = !!a.metadata.redact_ads_data && !R(Ao()))
        },
        fp = function(a) {
            if (Eo(a, ["conversion", "user_data_lead", "user_data_web"]) && R(L.g.H) && a.metadata.conversion_linker_enabled) {
                var b = a.metadata.cookie_options,
                    c = Dk(b.prefix);
                "_gcl" === c && (c = "");
                if (!P(61) || R(L.g.N)) {
                    var d = c;
                    if (oo.test(F.location.host) ? ro.test(F.location.href) || po.test(F.location.href) : !dl(d)) {
                        var e = wo(c);
                        e &&
                            (a.h[L.g.kb] = e);
                        if (!c) {
                            var f = to(wk() ? rk() : {}, po);
                            f && (a.h[L.g.ke] = f)
                        }
                    } else {
                        var h = xo(c);
                        h && (a.h[L.g.sc] = h);
                        if (!c) {
                            var l = a.h[L.g.ab];
                            b = z(b);
                            b.prefix = c;
                            var m = uo(l, b, !0).Jk;
                            m && (a.h[L.g.oc] = m)
                        }
                    }
                }
            }
        },
        gp = function(a) {
            if (Eo(a, ["conversion", "remarketing", "user_data_lead", "user_data_web"]) && a.metadata.conversion_linker_enabled && R(L.g.H)) {
                var b = !P(3);
                if ("remarketing" !== a.metadata.hit_type || b) {
                    var c = a.metadata.cookie_options;
                    kk(c, "conversion" === a.metadata.hit_type && a.eventName !== L.g.La);
                    if (!P(61) || R(L.g.N)) a.h[L.g.Hb] =
                        ek[gk(c.prefix)]
                }
            }
        },
        hp = function(a) {
            Ge || Ie || (nf(a.h[L.g.Hb]), P(90) && P(103) && ao())
        },
        ip = function(a) {
            if (Eo(a, ["conversion"])) {
                var b = Kl(a.metadata.cookie_options);
                if (b && !a.h[L.g.wa]) {
                    var c = Vi(a.h[L.g.ab]);
                    a.h[L.g.wa] = c
                }
                b && (a.h[L.g.vb] = b, a.metadata.send_ccm_parallel_ping = !0)
            }
        },
        jp = function(a) {
            var b = R(Ao());
            switch (a.metadata.hit_type) {
                case "user_data_lead":
                case "user_data_web":
                    a.isAborted = !b || !!a.metadata.consent_updated;
                    break;
                case "remarketing":
                    a.isAborted = !b;
                    break;
                case "conversion":
                    a.metadata.consent_updated &&
                        (a.h[L.g.Sd] = !0)
            }
        },
        kp = function(a) {
            Eo(a, ["conversion"]) && a.s.eventMetadata.is_external_event && (a.h[L.g.Dh] = !0)
        },
        lp = function(a) {
            if (P(73) && Eo(a, ["conversion"])) {
                var b = Jm();
                Km(b) && (a.h[L.g.pe] = "1", a.metadata.add_tag_timing = !0)
            }
        },
        mp = function(a) {
            var b;
            if ("gtag.config" !== a.eventName && a.metadata.send_user_data_hit) switch (a.metadata.hit_type) {
                case "user_data_web":
                    b = 97;
                    Do(a);
                    break;
                case "user_data_lead":
                    b = 98;
                    Do(a);
                    break;
                case "conversion":
                    b = 99
            }!a.metadata.speculative && b && K(b);
            !0 === a.metadata.speculative && (a.isAborted = !0)
        },
        Lo = !1,
        Mo = !1;
    var np = {
        F: {
            ug: "ads_conversion_hit",
            Fc: "container_execute_start",
            xg: "container_setup_end",
            kf: "container_setup_start",
            vg: "container_blocking_end",
            wg: "container_execute_end",
            yg: "container_yield_end",
            lf: "container_yield_start",
            yh: "event_execute_end",
            xh: "event_evaluation_end",
            Hf: "event_evaluation_start",
            zh: "event_setup_end",
            md: "event_setup_start",
            Ah: "ga4_conversion_hit",
            od: "page_load",
            Nm: "pageview",
            zb: "snippet_load",
            Oh: "tag_callback_error",
            Ph: "tag_callback_failure",
            Qh: "tag_callback_success",
            Rh: "tag_execute_end",
            wc: "tag_execute_start"
        }
    };

    function op() {
        function a(c, d) {
            var e = ib(d);
            e && b.push(c + "=" + e)
        }
        var b = [];
        a("&u", "GTM");
        a("&ut", "TAGGING");
        a("&h", "HEALTH");
        return b.join("")
    };
    var pp = !1;
    var Xp = function(a, b) {},
        Yp = function(a, b) {},
        Zp = function(a, b) {},
        $p = function(a, b) {},
        aq = function() {
            var a = {};
            return a
        },
        Pp = function(a) {
            a = void 0 === a ? !0 : a;
            var b = {};
            return b
        },
        bq = function() {},
        cq = function(a, b) {},
        dq = function(a, b, c) {};
    var eq = function(a, b) {
        var c, d = C.GooglebQhCsO;
        d || (d = {}, C.GooglebQhCsO = d);
        c = d;
        if (c[a]) return !1;
        c[a] = [];
        c[a][0] = b;
        return !0
    };
    var fq = function(a, b, c) {
        var d = Fh(a, "fmt");
        if (b) {
            var e = Fh(a, "random"),
                f = Fh(a, "label") || "";
            if (!e) return !1;
            var h = hj(decodeURIComponent(f.replace(/\+/g, " ")) + ":" + decodeURIComponent(e.replace(/\+/g, " ")));
            if (!eq(h, b)) return !1
        }
        d && 4 != d && (a = Hh(a, "rfmt", d));
        var l = Hh(a, "fmt", 4);
        Xb(l, function() {
            C.google_noFurtherRedirects && b && b.call && (C.google_noFurtherRedirects = null, b())
        }, void 0, c, F.getElementsByTagName("script")[0].parentElement || void 0);
        return !0
    };
    var gq = function(a) {
            for (var b = {}, c = 0; c < a.length; c++) {
                var d = a[c],
                    e = void 0;
                if (d.hasOwnProperty("google_business_vertical")) {
                    e = d.google_business_vertical;
                    var f = {};
                    b[e] = b[e] || (f.google_business_vertical = e, f)
                } else e = "", b.hasOwnProperty(e) || (b[e] = {});
                var h = b[e],
                    l;
                for (l in d) "google_business_vertical" !== l && (l in h || (h[l] = []), h[l].push(d[l]))
            }
            return Object.keys(b).map(function(m) {
                return b[m]
            })
        },
        iq = function(a) {
            if (!a || !a.length) return [];
            for (var b = [], c = 0; c < a.length; ++c) {
                var d = a[c];
                if (d) {
                    var e = {};
                    b.push((e.id =
                        hq(d), e.origin = d.origin, e.destination = d.destination, e.start_date = d.start_date, e.end_date = d.end_date, e.location_id = d.location_id, e.google_business_vertical = d.google_business_vertical, e))
                }
            }
            return b
        },
        jq = function(a) {
            if (!a || !a.length) return [];
            for (var b = [], c = 0; c < a.length; ++c) {
                var d = a[c];
                d && b.push({
                    item_id: hq(d),
                    quantity: d.quantity,
                    value: d.price,
                    start_date: d.start_date,
                    end_date: d.end_date
                })
            }
            return b
        },
        hq = function(a) {
            null != a.id && null != a.item_id && K(138);
            var b = a.id;
            P(102) && (null != a.item_id ? b = a.item_id : null ==
                b && (b = a.item_name));
            return b
        },
        lq = function(a) {
            if (!a) return "";
            for (var b = [], c = 0; c < a.length; c++) {
                var d = a[c],
                    e = [];
                d && (e.push(kq(d.value)), e.push(kq(d.quantity)), e.push(kq(d.item_id)), e.push(kq(d.start_date)), e.push(kq(d.end_date)), b.push("(" + e.join("*") + ")"))
            }
            return 0 < b.length ? b.join("") : ""
        },
        kq = function(a) {
            return "number" !== typeof a && "string" !== typeof a ? "" : a.toString()
        },
        nq = function(a, b) {
            var c = mq(b);
            return "" + a + (a && c ? ";" : "") + c
        },
        mq = function(a) {
            if (!a || "object" !== typeof a || "function" === typeof a.join) return "";
            var b = [];
            k(a, function(c, d) {
                var e, f;
                if (xa(d)) {
                    for (var h = [], l = 0; l < d.length; ++l) {
                        var m = oq(d[l]);
                        void 0 != m && h.push(m)
                    }
                    f = 0 !== h.length ? h.join(",") : void 0
                } else f = oq(d);
                e = f;
                var n = oq(c);
                n && void 0 != e && b.push(n + "=" + e)
            });
            return b.join(";")
        },
        oq = function(a) {
            var b = typeof a;
            if (null != a && "object" !== b && "function" !== b) return String(a).replace(/,/g, "\\,").replace(/;/g, "\\;").replace(/=/g, "\\=")
        },
        pq = function(a, b) {
            var c = [],
                d = function(f, h) {
                    null != h && "" !== h && (!0 === h && (h = 1), !1 === h && (h = 0), c.push(f + "=" + encodeURIComponent(h)))
                },
                e = a.metadata.hit_type;
            "conversion" !== e && "remarketing" !== e || d("random", a.metadata.event_start_timestamp_ms);
            k(b, d);
            return c.join("&")
        },
        qq = function(a, b) {
            var c = a.metadata.hit_type,
                d = a.h[L.g.kc],
                e = R(P(61) ? [L.g.H, L.g.N] : [L.g.H]),
                f = [],
                h, l = a.s.onSuccess,
                m, n = aj() ? 2 : 3,
                p = 0,
                q = function(x) {
                    f.push(x);
                    x.Va && p++
                };
            switch (c) {
                case "conversion":
                    m = "pagead/conversion";
                    var t = "";
                    e ? a.metadata.is_gcp_conversion ? (h = "https://www.google.com/", m = "pagead/1p-conversion") : h = "https://www.googleadservices.com/" : h = "https://pagead2.googlesyndication.com/";
                    a.metadata.is_gcp_conversion && (t = "&gcp=1&sscte=1&ct_cookie_present=1");
                    var r = {
                        fb: "" + h + m + "/" + d + "/?" + pq(a, b) + t,
                        format: n,
                        Va: !0
                    };
                    if (!P(61) || R(L.g.N)) r.attributes = {
                        attributionsrc: ""
                    };
                    q(r);
                    a.metadata.send_ccm_parallel_ping && q({
                        fb: "" + h + "ccm/conversion/" + d + "/?" + pq(a, b) + t,
                        format: 2,
                        Va: !0
                    });
                    a.metadata.is_gcp_conversion && (t = "&gcp=1&ct_cookie_present=1", q({
                        fb: "" + (e ? "https://googleads.g.doubleclick.net/" : h) + "pagead/viewthroughconversion/" + d + "/?" + pq(a, b) + t,
                        format: n,
                        Va: !0
                    }));
                    break;
                case "remarketing":
                    var u = b.data ||
                        "",
                        v = gq(iq(a.h[L.g.Z]));
                    if (v.length) {
                        for (var w = 0; w < v.length; w++) b.data = nq(u, v[w]), q({
                            fb: "https://googleads.g.doubleclick.net/pagead/viewthroughconversion/" + d + "/?" + pq(a, b),
                            format: n,
                            Va: !0
                        }), a.metadata.send_fledge_experiment && q({
                            fb: lo() + "/td/rul/" + d + "?" + pq(a, b),
                            format: 4,
                            Va: !1
                        }), a.metadata.event_start_timestamp_ms += 1;
                        a.metadata.send_fledge_experiment = !1
                    } else q({
                        fb: "https://googleads.g.doubleclick.net/pagead/viewthroughconversion/" + d + "/?" + pq(a, b),
                        format: n,
                        Va: !0
                    });
                    break;
                case "user_data_lead":
                    q({
                        fb: "https://google.com/pagead/form-data/" +
                            d + "?" + pq(a, b),
                        format: 1,
                        Va: !0
                    });
                    break;
                case "user_data_web":
                    q({
                        fb: "https://google.com/ccm/form-data/" + d + "?" + pq(a, b),
                        format: 1,
                        Va: !0
                    })
            }
            1 < f.length && ua(a.s.onSuccess) && (l = Ta(a.s.onSuccess, p));
            aj() || "conversion" !== c && "remarketing" !== c || !a.metadata.send_fledge_experiment || q({
                fb: lo() + "/td/rul/" + d + "?" + pq(a, b),
                format: 4,
                Va: !1
            });
            return {
                onSuccess: l,
                fl: f
            }
        },
        rq = function(a, b, c, d, e, f) {
            Yp(c.s.eventId, c.eventName);
            var h = function() {
                e && e()
            };
            switch (b) {
                case 1:
                    gc(a);
                    e && e();
                    break;
                case 2:
                    $b(a, h, void 0, f);
                    break;
                case 3:
                    var l = !1;
                    try {
                        l = fq(a, h, f)
                    } catch (p) {
                        l = !1
                    }
                    l || rq(a, 2, c, d, h, f);
                    break;
                case 4:
                    var m = "AW-" + c.h[L.g.kc],
                        n = c.h[L.g.ab];
                    n && (m = m + "/" + n);
                    ko(a, m)
            }
        },
        sq = {},
        tq = (sq[L.g.Sd] = "gcu", sq[L.g.kb] = "gclaw", sq[L.g.Hb] = "auid", sq[L.g.Vd] = "dscnt", sq[L.g.Wd] = "fcntr", sq[L.g.Xd] = "flng", sq[L.g.Yd] = "mid", sq[L.g.Ig] = "bttype", sq[L.g.ab] = "label", sq[L.g.Jb] = "capi", sq[L.g.sa] = "currency_code", sq[L.g.Zd] = "vdltv", sq[L.g.wj] = "_dbg", sq[L.g.ee] = "oedeld", sq[L.g.ob] = "edid", sq[L.g.Pg] = "fledge", sq[L.g.ke] = "gac", sq[L.g.oc] = "gacgb", sq[L.g.Yg] = "gacmcov",
            sq[L.g.me] = "gdpr", sq[L.g.qb] = "gdid", sq[L.g.fh] = "gsaexp", sq[L.g.gh] = "frm", sq[L.g.oe] = "gtm_up", sq[L.g.pe] = "lps", sq[L.g.Af] = "did", sq[L.g.Wc] = void 0, sq[L.g.tb] = "tiba", sq[L.g.Nb] = "rdp", sq[L.g.vb] = "ecsid", sq[L.g.bd] = "delopc", sq[L.g.ue] = "gdpr_consent", sq[L.g.wa] = "oid", sq[L.g.ph] = "ec_lat", sq[L.g.qh] = "ec_meta", sq[L.g.rh] = "ec_m", sq[L.g.sh] = "ec_sel", sq[L.g.th] = "ec_s", sq[L.g.ve] = "ec_mode", sq[L.g.Pa] = "userId", sq[L.g.vh] = "us_privacy", sq[L.g.fa] = "value", sq[L.g.sc] = "gclgb", sq[L.g.wh] = "mcov", sq[L.g.Ch] = "hn", sq[L.g.Dh] =
            "gtm_ee", sq[L.g.vc] = "npa", sq[L.g.kc] = null, sq[L.g.ub] = null, sq[L.g.Ga] = null, sq[L.g.Z] = null, sq[L.g.za] = null, sq[L.g.Ia] = null, sq[L.g.Ff] = null, sq),
        vq = function(a) {
            uq(a, function(b) {
                for (var c = qq(a, b), d = c.onSuccess, e = c.fl, f = 0; f < e.length; f++) {
                    var h = e[f];
                    rq(h.fb, h.format, a, b, h.Va ? d : void 0, h.attributes)
                }
            })
        },
        uq = function(a, b) {
            var c = a.metadata.hit_type,
                d = {},
                e = {},
                f = [],
                h = a.metadata.event_start_timestamp_ms;
            if ("conversion" === c || "remarketing" === c) d.cv = "11", d.fst = h, d.fmt = 3, d.bg = "ffffff", d.guid = "ON", d.async = "1";
            var l =
                Zk(["aw", "dc"]);
            null != l && (d.gad_source = l);
            d.gtm = cj(El(a));
            "remarketing" !== c && ti() && (d.gcs = ui());
            if (P(37) || "remarketing" !== c && Qf()) d.gcd = yi(a.s);
            P(39) && (Ci() && (d.dma_cps = zi()), d.dma = Bi());
            P(62) && Uh(ci()) && (d.tcfd = Di());
            if (a.h[L.g.ub]) {
                var m = a.h[L.g.ub].split("x");
                2 === m.length && (d.u_w = m[0], d.u_h = m[1])
            }
            if (a.h[L.g.Ga]) {
                var n = a.h[L.g.Ga];
                2 === n.length ? d.hl = n : 5 === n.length && (d.hl = n.substring(0, 2), d.gl = n.substring(3, 5))
            }
            var p = a.metadata.redact_click_ids,
                q = function(y, A) {
                    var B = a.h[A];
                    B && (d[y] = p ? Bj(B) : B)
                };
            q("url",
                L.g.za);
            q("ref", L.g.Ia);
            q("top", L.g.Ff);
            P(8) && (tq[L.g.dd] = "uaa", tq[L.g.ed] = "uab", tq[L.g.fd] = "uafvl", tq[L.g.gd] = "uamb", tq[L.g.hd] = "uam", tq[L.g.jd] = "uap", tq[L.g.kd] = "uapv", tq[L.g.ld] = "uaw");
            k(a.h, function(y, A) {
                if (tq.hasOwnProperty(y)) {
                    var B = tq[y];
                    B && (d[B] = A)
                } else e[y] = A
            });
            var t = a.h[L.g.Wc];
            void 0 != t && "" !== t && (d.vdnc = String(t));
            var r = a.h[L.g.Sc];
            void 0 !== r && (d.shf = r);
            var u = a.h[L.g.nc];
            void 0 !== u && (d.delc = u);
            if (P(73) && a.metadata.add_tag_timing) {
                d.tft = Ka();
                var v = jc();
                void 0 !== v && (d.tfd = Math.round(v))
            }
            d.data =
                mq(e);
            var w = a.h[L.g.Z];
            w && "conversion" === c && (d.iedeld = hf(w), d.item = lq(jq(w)));
            if (!("conversion" !== c && "user_data_lead" !== c && "user_data_web" !== c || !a.metadata.user_data || P(61) && !R(L.g.N) || P(23) && !R(L.g.H))) {
                P(90) && P(103) && !Ge && !Ie && eo({
                    url: "https://www.googleadservices.com/pagead/conversion/" + a.h[L.g.kc],
                    pii: a.metadata.user_data
                });
                var x = fe(a.metadata.user_data);
                x && f.push(x.then(function(y) {
                    d.em = y.li;
                    if ("user_data_web" === c && 0 < y.Ml) {
                        var A = Ll(a.metadata.cookie_options);
                        d.ecsid = A
                    }
                }))
            }
            if (f.length) try {
                Promise.all(f).then(function() {
                    b(d)
                });
                return
            } catch (y) {}
            b(d)
        };
    var wq = function() {
            this.h = {}
        },
        xq = function(a, b, c) {
            null != c && (a.h[b] = c)
        },
        yq = function(a) {
            return Object.keys(a.h).map(function(b) {
                return encodeURIComponent(b) + "=" + encodeURIComponent(a.h[b])
            }).join("&")
        },
        Aq = function(a, b, c, d) {
            if (!Pf()) {
                zq(a, b, c, d);
                return
            }
            cg(function() {
                R(L.g.H) ? zq(a, b, c, d) : d && d()
            }, [L.g.H]);
        };
    var Bq = function(a, b, c) {
            c = void 0 === c ? !0 : c;
            var d = {
                    gclgb: function() {
                        return sm("gb", b, c).join(".")
                    },
                    gacgb: function() {
                        return zm(c)
                    },
                    gclaw: function() {
                        return wm(b, c).join(".")
                    },
                    gac: function() {
                        return ym(c)
                    }
                },
                e = Bm(b),
                f = e ? "gclgb" : "gclaw",
                h = e ? "gacgb" : "gac",
                l = d[h],
                m = (0, d[f])(),
                n = "_gcl" !== b ? "" : l();
            m && xq(a, f, m);
            n && xq(a, h, n)
        },
        zq = function(a, b, c, d) {
            c = c || {};
            var e = c.xc || {},
                f = new wq;
            P(90) && P(103) && !Ge && !Ie && eo({
                url: "https://google.com/pagead/form-data/" + a,
                pii: b
            });
            ee(b, function(h, l) {
                xq(f, "em", h);
                xq(f, "gtm", cj());
                ti() &&
                    xq(f, "gcs", ui());
                (Pf() || P(37)) && xq(f, "gcd", yi());
                P(39) && (Ci() && xq(f, "dma_cps", zi()), xq(f, "dma", Bi()));
                P(41) && xq(f, "npa", si() ? "0" : "1");
                P(62) && Uh(ci()) && xq(f, "tcfd", Di());
                Bq(f, Dk(e.prefix), c.Ye);
                xq(f, "auid", ek[gk(e.prefix)]);
                if (0 < l) {
                    var m = Ll(e);
                    xq(f, "ecsid", m)
                }
                var n = yq(f);
                gc("https://google.com/pagead/form-data/" + a + "?" + n);
                gc("https://google.com/ccm/form-data/" + a + "?" + n);
                d && d()
            })
        };

    function Cq(a, b) {
        if (data.entities && data.entities[a]) return data.entities[a][b]
    };
    var Eq = function(a) {
            var b = ug();
            Dq(b).event && Dq(b).event.push(a)
        },
        Fq = function() {
            var a = Dq(ug());
            return a.event ? a.event : []
        };

    function Dq(a) {
        var b, c = ye.r;
        c || (c = {
            container: {}
        }, ye.r = c);
        b = c;
        var d = b.container[a];
        d || (d = {
            entity: [],
            event: []
        }, b.container[a] = d);
        return d
    };
    var Gq = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        Hq = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        Iq = {
            cl: ["ecl"],
            customPixels: ["customScripts",
                "html"
            ],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        Jq = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" "),
        Mq = function(a) {
            var b = Ye("gtm.allowlist") || Ye("gtm.whitelist");
            b && K(9);
            Ee && (b = ["google", "gtagfl",
                "lcl", "zone"
            ]);
            Kq() && (Ee ? K(116) : (K(117), Lq && (b = [], window.console && window.console.log && window.console.log("GTM blocked. See go/13687728."))));
            var c = b && Oa(Ga(b), Hq),
                d = Ye("gtm.blocklist") || Ye("gtm.blacklist");
            d || (d = Ye("tagTypeBlacklist")) && K(3);
            d ? K(8) : d = [];
            Kq() && (d = Ga(d), d.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
            0 <= Ga(d).indexOf("google") && K(2);
            var e = d && Oa(Ga(d), Iq),
                f = {};
            return function(h) {
                var l = h && h[oc.ma];
                if (!l || "string" != typeof l) return !0;
                l = l.replace(/^_*/, "");
                if (void 0 !== f[l]) return f[l];
                var m = Qe[l] || [],
                    n = a(l, m),
                    p;
                p = Dq(ug()).entity;
                for (var q = 0; q < p.length; q++) try {
                    n = n && p[q](l, m)
                } catch (y) {
                    n = !1
                }
                if (b) {
                    var t;
                    if (t = n) a: {
                        if (0 > c.indexOf(l))
                            if (m && 0 < m.length)
                                for (var r = 0; r < m.length; r++) {
                                    if (0 > c.indexOf(m[r])) {
                                        K(11);
                                        t = !1;
                                        break a
                                    }
                                } else {
                                    t = !1;
                                    break a
                                }
                        t = !0
                    }
                    n = t
                }
                var u = !1;
                if (d) {
                    var v = 0 <= e.indexOf(l);
                    if (v) u = v;
                    else {
                        var w = Ca(e, m || []);
                        w && K(10);
                        u = w
                    }
                }
                var x = !n || u;
                x || !(0 <= m.indexOf("sandboxedScripts")) || c && -1 !== c.indexOf("sandboxedScripts") || (x = Ca(e, Jq));
                return f[l] = x
            }
        },
        Lq = !1;
    Lq = !0;
    var Kq = function() {
            return Gq.test(C.location && C.location.hostname)
        },
        Nq = function() {
            lg && Dq(ug()).entity.push(function(a) {
                var b = {};
                b[oc.ma] = "__" + a;
                for (var c in void 0)(void 0).hasOwnProperty(c) && (b["vtp_" + c] = (void 0)[c]);
                var d;
                if (bd(b)) {
                    var e = b[oc.ma];
                    if (!e) throw "Error: No function name given for function call.";
                    var f = Rc[e];
                    d = !!f && !!f.runInSiloedMode
                } else d = !!Cq(b[oc.ma], 4);
                return d
            })
        };
    var Pq = function(a, b, c, d) {
            if (!Oq() && !Ag(a)) {
                var e = "?id=" + encodeURIComponent(a) + "&l=" + xe.da,
                    f = 0 === a.indexOf("GTM-");
                f || (e += "&cx=c");
                P(53) && (e += "&gtm=" + cj());
                var h = Nl();
                h && (e += "&sign=" + xe.De);
                var l = c ? "/gtag/js" : "/gtm.js",
                    m = Ge || Ie ? Ml(b, l + e) : void 0;
                if (!m) {
                    var n = xe.Gc + l;
                    h && Rb && f && (n = Rb.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
                    m = ol("https://", "http://", n + e)
                }
                var p = a;
                d.siloed && (Cg({
                    ctid: p,
                    isDestination: !1
                }), p = og(p));
                var q = p,
                    t = Bg();
                hg().container[q] = {
                    state: 1,
                    context: d,
                    parent: t
                };
                ig({
                    ctid: q,
                    isDestination: !1
                });
                Xb(m)
            }
        },
        Qq = function(a, b, c) {
            var d;
            if (d = !Oq()) {
                var e = hg().destination[a];
                d = !(e && e.state)
            }
            if (d)
                if (Dg()) hg().destination[a] = {
                    state: 0,
                    transportUrl: b,
                    context: c,
                    parent: Bg()
                }, ig({
                    ctid: a,
                    isDestination: !0
                }), K(91);
                else {
                    var f = "/gtag/destination?id=" + encodeURIComponent(a) + "&l=" + xe.da + "&cx=c";
                    P(53) && (f += "&gtm=" + cj());
                    Nl() && (f += "&sign=" + xe.De);
                    var h = Ge || Ie ? Ml(b, f) : void 0;
                    h || (h = ol("https://", "http://", xe.Gc + f));
                    var l = a;
                    c.siloed && (Cg({
                        ctid: l,
                        isDestination: !0
                    }), l = og(l));
                    hg().destination[l] = {
                        state: 1,
                        context: c,
                        parent: Bg()
                    };
                    ig({
                        ctid: l,
                        isDestination: !0
                    });
                    Xb(h)
                }
        };

    function Oq() {
        if (aj()) {
            return !0
        }
        return !1
    };
    var Rq = !1,
        mr = 0,
        sr = [];

    function tr(a) {
        if (!Rq) {
            var b = F.createEventObject,
                c = "complete" == F.readyState,
                d = "interactive" == F.readyState;
            if (!a || "readystatechange" != a.type || c || !b && d) {
                Rq = !0;
                for (var e = 0; e < sr.length; e++) H(sr[e])
            }
            sr.push = function() {
                for (var f = 0; f < arguments.length; f++) H(arguments[f]);
                return 0
            }
        }
    }

    function ur() {
        if (!Rq && 140 > mr) {
            mr++;
            try {
                F.documentElement.doScroll("left"), tr()
            } catch (a) {
                C.setTimeout(ur, 50)
            }
        }
    }
    var vr = function(a) {
        Rq ? a() : sr.push(a)
    };
    var wr = function(a, b) {
        return {
            entityType: 1,
            indexInOriginContainer: a,
            nameInOriginContainer: b,
            originContainerId: tg()
        }
    };
    var yr = function(a, b) {
            this.h = !1;
            this.K = [];
            this.M = {
                tags: []
            };
            this.R = !1;
            this.C = this.D = 0;
            xr(this, a, b)
        },
        zr = function(a, b, c, d) {
            if (Be.hasOwnProperty(b) || "__zone" === b) return -1;
            var e = {};
            Ya(d) && (e = z(d, e));
            e.id = c;
            e.status = "timeout";
            return a.M.tags.push(e) - 1
        },
        Ar = function(a, b, c, d) {
            var e = a.M.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        Br = function(a) {
            if (!a.h) {
                for (var b = a.K, c = 0; c < b.length; c++) b[c]();
                a.h = !0;
                a.K.length = 0
            }
        },
        xr = function(a, b, c) {
            void 0 !== b && Cr(a, b);
            c && C.setTimeout(function() {
                return Br(a)
            }, Number(c))
        },
        Cr =
        function(a, b) {
            var c = Ma(function() {
                return H(function() {
                    b(tg(), a.M)
                })
            });
            a.h ? c() : a.K.push(c)
        },
        Dr = function(a) {
            a.D++;
            return Ma(function() {
                a.C++;
                a.R && a.C >= a.D && Br(a)
            })
        },
        Er = function(a) {
            a.R = !0;
            a.C >= a.D && Br(a)
        };
    var Fr = {},
        Hr = function() {
            return C[Gr()]
        },
        Ir = !1;
    var Jr = function(a) {
            C.GoogleAnalyticsObject || (C.GoogleAnalyticsObject = a || "ga");
            var b = C.GoogleAnalyticsObject;
            if (C[b]) C.hasOwnProperty(b);
            else {
                var c = function() {
                    c.q = c.q || [];
                    c.q.push(arguments)
                };
                c.l = Number(Ja());
                C[b] = c
            }
            return C[b]
        },
        Kr = function(a) {
            if (Pf()) {
                var b = Hr();
                b(a + "require", "linker");
                b(a + "linker:passthrough", !0)
            }
        };

    function Gr() {
        return C.GoogleAnalyticsObject || "ga"
    }
    var Lr = function(a) {},
        Mr = function(a, b) {
            return function() {
                var c = Hr(),
                    d = c && c.getByName && c.getByName(a);
                if (d) {
                    var e = d.get("sendHitTask");
                    d.set("sendHitTask", function(f) {
                        var h = f.get("hitPayload"),
                            l = f.get("hitCallback"),
                            m = 0 > h.indexOf("&tid=" + b);
                        m && (f.set("hitPayload", h.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                        e(f);
                        m && (f.set("hitPayload",
                            h, !0), f.set("hitCallback", l, !0), f.set("_x_19", void 0, !0), e(f))
                    })
                }
            }
        };
    var Rr = {},
        Sr = {};

    function Tr(a, b) {
        if (Ng) {
            var c;
            c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
            Rr[a] = "&e=" + c + "&eid=" + a;
            Xg(a)
        }
    }

    function Ur(a) {
        var b = a.eventId,
            c = a.Fb;
        if (!Rr[b]) return "";
        var d = Sr[b] ? "" : "&es=1";
        d += Rr[b];
        c && (Sr[b] = !0);
        return d
    };
    var Vr = {};

    function Wr(a, b) {
        Ng && (Vr[a] = Vr[a] || {}, Vr[a][b] = (Vr[a][b] || 0) + 1)
    }

    function Xr(a) {
        var b = a.eventId,
            c = a.Fb,
            d = Vr[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete Vr[b];
        return e.length ? "&md=" + e.join(".") : ""
    };
    var Yr = {},
        Zr = {
            aev: "1",
            c: "2",
            jsm: "3",
            v: "4",
            j: "5",
            smm: "6",
            rmm: "7",
            input: "8"
        };

    function $r(a, b, c) {
        if (Ng) {
            Yr[a] = Yr[a] || [];
            var d = Zr[b] || "0",
                e;
            e = c instanceof C.Element ? "1" : c instanceof C.Event ? "2" : c instanceof C.RegExp ? "3" : c === C ? "4" : c === F ? "5" : c instanceof C.Promise ? "6" : c instanceof C.Storage ? "7" : c instanceof C.Date ? "8" : c instanceof C.History ? "9" : c instanceof C.Performance ? "a" : c === C.crypto ? "b" : c instanceof C.Location ? "c" : c instanceof C.Navigator ? "d" : "object" !== typeof c || Ya(c) ? "0" : "e";
            Yr[a].push("" + d + e)
        }
    }

    function as(a) {
        var b = a.eventId,
            c = Yr[b] || [];
        if (!c.length) return "";
        a.Fb && delete Yr[b];
        return "&pcr=" + c.join(".")
    };
    var bs = {},
        cs = {};

    function ds(a, b, c) {
        if (Ng && b) {
            var d = fg(b);
            bs[a] = bs[a] || [];
            bs[a].push(c + d);
            var e = (bd(b) ? "1" : "2") + d;
            cs[a] = cs[a] || [];
            cs[a].push(e);
            Xg(a)
        }
    }

    function es(a) {
        var b = a.eventId,
            c = a.Fb,
            d = "",
            e = bs[b] || [];
        e.length && (d += "&tr=" + e.join("."));
        var f = cs[b] || [];
        f.length && (d += "&ti=" + f.join("."));
        c && (delete bs[b], delete cs[b]);
        return d
    };

    function fs(a, b, c, d) {
        var e = Pc[a],
            f = gs(a, b, c, d);
        if (!f) return null;
        var h = Zc(e[oc.Nh], c, []);
        if (h && h.length) {
            var l = h[0];
            f = fs(l.index, {
                onSuccess: f,
                onFailure: 1 === l.di ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function gs(a, b, c, d) {
        function e() {
            if (f[oc.Vj]) l();
            else {
                var w = $c(f, c, []),
                    x = w[oc.Qi];
                if (null != x)
                    for (var y = 0; y < x.length; y++)
                        if (!R(x[y])) {
                            l();
                            return
                        }
                var A = zr(c.Sb, String(f[oc.ma]), Number(f[oc.sd]), w[oc.Wj]),
                    B = !1;
                w.vtp_gtmOnSuccess = function() {
                    if (!B) {
                        B = !0;
                        var J = Ka() - I;
                        ds(c.id, Pc[a], "5");
                        Ar(c.Sb, A, "success", J);
                        P(24) && dq(c, f, np.F.Qh);
                        h()
                    }
                };
                w.vtp_gtmOnFailure = function() {
                    if (!B) {
                        B = !0;
                        var J = Ka() - I;
                        ds(c.id, Pc[a], "6");
                        Ar(c.Sb, A, "failure", J);
                        P(24) && dq(c, f, np.F.Ph);
                        l()
                    }
                };
                w.vtp_gtmTagId = f.tag_id;
                w.vtp_gtmEventId =
                    c.id;
                c.priorityId && (w.vtp_gtmPriorityId = c.priorityId);
                ds(c.id, f, "1");
                var D = function() {
                    pf(3);
                    var J = Ka() - I;
                    ds(c.id, f, "7");
                    Ar(c.Sb, A, "exception", J);
                    P(24) && dq(c, f, np.F.Oh);
                    B || (B = !0, l())
                };
                P(24) && cq(c, f);
                var I = Ka();
                try {
                    Yc(w, {
                        event: c,
                        index: a,
                        type: 1
                    })
                } catch (J) {
                    D(J)
                }
                P(24) && dq(c, f, np.F.Rh)
            }
        }
        var f = Pc[a],
            h = b.onSuccess,
            l = b.onFailure,
            m = b.terminate;
        if (c.isBlocked(f)) return null;
        var n = Zc(f[oc.Sh], c, []);
        if (n && n.length) {
            var p = n[0],
                q = fs(p.index, {
                    onSuccess: h,
                    onFailure: l,
                    terminate: m
                }, c, d);
            if (!q) return null;
            h = q;
            l = 2 ===
                p.di ? m : q
        }
        if (f[oc.Ih] || f[oc.Yj]) {
            var t = f[oc.Ih] ? Qc : c.gm,
                r = h,
                u = l;
            if (!t[a]) {
                e = Ma(e);
                var v = hs(a, t, e);
                h = v.onSuccess;
                l = v.onFailure
            }
            return function() {
                t[a](r, u)
            }
        }
        return e
    }

    function hs(a, b, c) {
        var d = [],
            e = [];
        b[a] = is(d, e, c);
        return {
            onSuccess: function() {
                b[a] = js;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = ks;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function is(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function js(a) {
        a()
    }

    function ks(a, b) {
        b()
    };
    var ms = function(a, b) {
            return 1 === arguments.length ? ls("config", a) : ls("config", a, b)
        },
        ns = function(a, b, c) {
            c = c || {};
            c[L.g.Ob] = a;
            return ls("event", b, c)
        };

    function ls(a) {
        return arguments
    }
    var os = function() {
        this.h = [];
        this.C = []
    };
    os.prototype.enqueue = function(a, b, c) {
        var d = this.h.length + 1;
        a["gtm.uniqueEventId"] = b;
        a["gtm.priorityId"] = d;
        c.eventId = b;
        c.fromContainerExecution = !0;
        c.priorityId = d;
        var e = {
            message: a,
            notBeforeEventId: b,
            priorityId: d,
            messageContext: c
        };
        this.h.push(e);
        for (var f = 0; f < this.C.length; f++) try {
            this.C[f](e)
        } catch (h) {}
    };
    os.prototype.listen = function(a) {
        this.C.push(a)
    };
    os.prototype.get = function() {
        for (var a = {}, b = 0; b < this.h.length; b++) {
            var c = this.h[b],
                d = a[c.notBeforeEventId];
            d || (d = [], a[c.notBeforeEventId] = d);
            d.push(c)
        }
        return a
    };
    os.prototype.prune = function(a) {
        for (var b = [], c = [], d = 0; d < this.h.length; d++) {
            var e = this.h[d];
            e.notBeforeEventId === a ? b.push(e) : c.push(e)
        }
        this.h = c;
        return b
    };
    var qs = function(a, b, c) {
            c.eventMetadata = c.eventMetadata || {};
            c.eventMetadata.source_canonical_id = mg.He;
            ps().enqueue(a, b, c)
        },
        ss = function() {
            var a = rs;
            ps().listen(a)
        };

    function ps() {
        var a = ye.mb;
        a || (a = new os, ye.mb = a);
        return a
    }
    var As = function(a) {
            var b = ye.zones;
            return b ? b.getIsAllowedFn(pg(), a) : function() {
                return !0
            }
        },
        Bs = function() {
            Eq(function(a, b) {
                var c = ye.zones;
                return c ? c.isActive(pg(), b) : !0
            })
        };
    var Es = function(a, b) {
        for (var c = [], d = 0; d < Pc.length; d++)
            if (a[d]) {
                var e = Pc[d];
                var f = Dr(b.Sb);
                try {
                    var h = fs(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (h) {
                        var l = e[oc.ma];
                        if (!l) throw "Error: No function name given for function call.";
                        var m = Rc[l];
                        c.push({
                            Gi: d,
                            si: (m ? m.priorityOverride || 0 : 0) || Cq(e[oc.ma], 1) || 0,
                            execute: h
                        })
                    } else Cs(d, b), f()
                } catch (p) {
                    f()
                }
            }
        c.sort(Ds);
        for (var n = 0; n < c.length; n++) c[n].execute();
        return 0 < c.length
    };

    function Ds(a, b) {
        var c, d = b.si,
            e = a.si;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (0 !== c) f = c;
        else {
            var h = a.Gi,
                l = b.Gi;
            f = h > l ? 1 : h < l ? -1 : 0
        }
        return f
    }

    function Cs(a, b) {
        if (Ng) {
            var c = function(d) {
                var e = b.isBlocked(Pc[d]) ? "3" : "4",
                    f = Zc(Pc[d][oc.Nh], b, []);
                f && f.length && c(f[0].index);
                ds(b.id, Pc[d], e);
                var h = Zc(Pc[d][oc.Sh], b, []);
                h && h.length && c(h[0].index)
            };
            c(a)
        }
    }
    var Hs = !1,
        Fs;
    var Ms = function(a) {
        var b = a["gtm.uniqueEventId"],
            c = a["gtm.priorityId"],
            d = a.event;
        if (P(24)) {}
        if ("gtm.js" === d) {
            if (Hs) return !1;
            Hs = !0
        }
        var e, f = !1;
        if (Fq().every(function(t) {
                return t(d, b)
            })) e = As(b);
        else {
            if ("gtm.js" !== d && "gtm.init" !== d && "gtm.init_consent" !== d) return !1;
            f = !0;
            e = As(Number.MAX_SAFE_INTEGER)
        }
        Tr(b, d);
        var h = a.eventCallback,
            l = a.eventTimeout,
            m = {
                id: b,
                priorityId: c,
                name: d,
                isBlocked: Mq(e),
                gm: [],
                logMacroError: function() {
                    K(6);
                    pf(0)
                },
                cachedModelValues: Is(),
                checkPixieIncompatibility: Js(b),
                Sb: new yr(function() {
                    if (P(24)) {}
                    h &&
                        h.apply(h, [].slice.call(arguments, 0))
                }, l),
                originalEventData: z(a)
            };
        P(44) && (m.reportMacroDiscrepancy = Wr);
        P(24) && Zp(m.id, m.name);
        var n = ed(m);
        P(24) && $p(m.id, m.name);
        f && (n = Ks(n));
        if (P(24)) {}
        var p = Es(n, m),
            q = !1;
        Er(m.Sb);
        "gtm.js" !== d && "gtm.sync" !== d || Lr(tg());
        return Ls(n, p) || q
    };

    function Js(a) {
        return function(b) {
            Za(b) || $r(a, "input", b)
        }
    }

    function Is() {
        var a = {};
        a.event = bf("event", 1);
        a.ecommerce = bf("ecommerce", 1);
        a.gtm = bf("gtm");
        a.eventModel = bf("eventModel");
        return a
    }

    function Ks(a) {
        for (var b = [], c = 0; c < a.length; c++)
            if (a[c]) {
                var d = String(Pc[c][oc.ma]);
                if (Ae[d] || void 0 !== Pc[c][oc.Zj] || Re[d] || Cq(d, 2)) b[c] = !0
            }
        return b
    }

    function Ls(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && Pc[c] && !Be[String(Pc[c][oc.ma])]) return !0;
        return !1
    }
    var Ns = {},
        Os = {},
        Ps = function(a, b) {
            for (var c = [], d = [], e = {}, f = 0; f < a.length; e = {
                    Ve: e.Ve,
                    Pe: e.Pe
                }, f++) {
                var h = a[f];
                if (0 <= h.indexOf("-")) {
                    if (e.Ve = ll(h, b), e.Ve) {
                        var l = rg();
                        ya(l, function(t) {
                            return function(r) {
                                return t.Ve.ba === r
                            }
                        }(e)) ? c.push(h) : d.push(h)
                    }
                } else {
                    var m = Ns[h] || [];
                    e.Pe = {};
                    m.forEach(function(t) {
                        return function(r) {
                            return t.Pe[r] = !0
                        }
                    }(e));
                    for (var n = pg(), p = 0; p < n.length; p++)
                        if (e.Pe[n[p]]) {
                            c = c.concat(rg());
                            break
                        }
                    var q = Os[h] || [];
                    q.length && (c = c.concat(q))
                }
            }
            return {
                Dl: c,
                Fl: d
            }
        },
        Qs = function(a) {
            k(Ns, function(b,
                c) {
                var d = c.indexOf(a);
                0 <= d && c.splice(d, 1)
            })
        },
        Rs = function(a) {
            k(Os, function(b, c) {
                var d = c.indexOf(a);
                0 <= d && c.splice(d, 1)
            })
        };
    var Ss = "HA GF G UA AW DC MC".split(" "),
        Ts = !1,
        Us = !1;

    function Vs(a, b) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: Se()
        });
        b.eventId = a["gtm.uniqueEventId"];
        b.priorityId = a["gtm.priorityId"];
        return {
            eventId: b.eventId,
            priorityId: b.priorityId
        }
    }
    var Ws = void 0,
        Xs = void 0;

    function Ys(a, b, c) {
        var d = z(a);
        d.eventId = void 0;
        d.inheritParentConfig = void 0;
        Object.keys(b).some(function(f) {
            return void 0 !== b[f]
        }) && K(136);
        var e = z(b);
        z(c, e);
        qs(ms(pg()[0], e), a.eventId, d)
    }

    function Zs(a) {
        for (var b = ha([L.g.Zc, L.g.Pb]), c = b.next(); !c.done; c = b.next()) {
            var d = c.value,
                e = a && a[d] || dm.D[d];
            if (e) return e
        }
    }
    var $s = {
            config: function(a, b) {
                var c = P(45),
                    d = Vs(a, b);
                if (!(2 > a.length) && g(a[1])) {
                    var e = {};
                    if (2 < a.length) {
                        if (void 0 != a[2] && !Ya(a[2]) || 3 < a.length) return;
                        e = a[2]
                    }
                    var f = ll(a[1], b.isGtmEvent);
                    if (f) {
                        var h, l, m;
                        a: {
                            if (!kg.nd) {
                                var n = vg(Bg());
                                if (Fg(n)) {
                                    var p = n.parent,
                                        q = p.isDestination;
                                    m = {
                                        Jl: vg(p),
                                        Cl: q
                                    };
                                    break a
                                }
                            }
                            m = void 0
                        }
                        var t = m;
                        t && (h = t.Jl, l = t.Cl);
                        Tr(d.eventId, "gtag.config");
                        var r = f.ba,
                            u = f.id !== r;
                        if (u ? -1 === rg().indexOf(r) : -1 === pg().indexOf(r)) {
                            if (!(c && b.inheritParentConfig || e[L.g.sb])) {
                                var v = Zs(e);
                                if (u) Qq(r, v, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                });
                                else if (c && void 0 !== h && -1 !== h.containers.indexOf(r)) {
                                    var w = e;
                                    Ws ? Ys(b, w, Ws) : Xs || (Xs = z(w))
                                } else Pq(r, v, !0, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                })
                            }
                        } else {
                            if (h && (K(128), l && K(130), c && b.inheritParentConfig)) {
                                var x;
                                var y = e;
                                Xs ? (Ys(b, Xs, y), x = !1) : (!y[L.g.Qb] && De && Ws || (Ws = z(y)), x = !0);
                                x && h.containers && h.containers.join(",");
                                return
                            }
                            if (De && !u && !e[L.g.Qb]) {
                                var A = Us;
                                Us = !0;
                                if (A) return
                            }
                            Ts || K(43);
                            if (!b.noTargetGroup)
                                if (u) {
                                    Rs(f.id);
                                    var B = f.id,
                                        D = e[L.g.ne] ||
                                        "default";
                                    D = String(D).split(",");
                                    for (var I = 0; I < D.length; I++) {
                                        var J = Os[D[I]] || [];
                                        Os[D[I]] = J;
                                        0 > J.indexOf(B) && J.push(B)
                                    }
                                } else {
                                    Qs(f.id);
                                    var E = f.id,
                                        G = e[L.g.ne] || "default";
                                    G = G.toString().split(",");
                                    for (var M = 0; M < G.length; M++) {
                                        var Q = Ns[G[M]] || [];
                                        Ns[G[M]] = Q;
                                        0 > Q.indexOf(E) && Q.push(E)
                                    }
                                }
                            delete e[L.g.ne];
                            var ba = b.eventMetadata || {};
                            ba.hasOwnProperty("is_external_event") || (ba.is_external_event = !b.fromContainerExecution);
                            b.eventMetadata = ba;
                            delete e[L.g.Tc];
                            for (var S = u ? [f.id] : rg(), O = 0; O < S.length; O++) {
                                var ca = e,
                                    Z =
                                    z(b),
                                    U = ll(S[O], Z.isGtmEvent);
                                U && dm.push("config", [ca], U, Z)
                            }
                        }
                    }
                }
            },
            consent: function(a, b) {
                if (3 === a.length) {
                    K(39);
                    var c = Vs(a, b),
                        d = a[1],
                        e = a[2];
                    b.fromContainerExecution || (e[L.g.N] && K(139), e[L.g.ya] && K(140));
                    "default" === d ? Zf(e) : "update" === d ? $f(e, c) : "declare" === d ? b.fromContainerExecution && Yf(e) : P(81) && "core_platform_services" === d && ag(e)
                }
            },
            event: function(a, b) {
                var c = a[1];
                if (!(2 > a.length) && g(c)) {
                    var d;
                    if (2 < a.length) {
                        if (!Ya(a[2]) && void 0 != a[2] || 3 < a.length) return;
                        d = a[2]
                    }
                    var e = d,
                        f = {},
                        h = (f.event = c, f);
                    e && (h.eventModel =
                        z(e), e[L.g.Tc] && (h.eventCallback = e[L.g.Tc]), e[L.g.he] && (h.eventTimeout = e[L.g.he]));
                    var l = Vs(a, b),
                        m = l.eventId,
                        n = l.priorityId;
                    h["gtm.uniqueEventId"] = m;
                    n && (h["gtm.priorityId"] = n);
                    if ("optimize.callback" === c) return h.eventModel = h.eventModel || {}, h;
                    var p;
                    var q = d,
                        t = q && q[L.g.Ob];
                    void 0 === t && (t = Ye(L.g.Ob, 2), void 0 === t && (t = "default"));
                    if (g(t) || xa(t)) {
                        var r;
                        b.isGtmEvent ? r = g(t) ? [t] : t : r = t.toString().replace(/\s+/g, "").split(",");
                        var u = Ps(r, b.isGtmEvent),
                            v = u.Dl,
                            w = u.Fl;
                        if (w.length)
                            for (var x = Zs(q), y = 0; y < w.length; y++) {
                                var A =
                                    ll(w[y], b.isGtmEvent);
                                A && Qq(A.ba, x, {
                                    source: 3,
                                    fromContainerExecution: b.fromContainerExecution
                                })
                            }
                        p = nl(v, b.isGtmEvent)
                    } else p = void 0;
                    var B = p;
                    if (B) {
                        Tr(m, c);
                        for (var D = [], I = 0; I < B.length; I++) {
                            var J = B[I],
                                E = z(b);
                            if (-1 !== Ss.indexOf(wg(J.prefix))) {
                                var G = z(d),
                                    M = E.eventMetadata || {};
                                M.hasOwnProperty("is_external_event") || (M.is_external_event = !E.fromContainerExecution);
                                E.eventMetadata = M;
                                delete G[L.g.Tc];
                                em(c, G, J.id, E)
                            }
                            D.push(J.id)
                        }
                        h.eventModel = h.eventModel || {};
                        0 < B.length ? h.eventModel[L.g.Ob] = D.join() : delete h.eventModel[L.g.Ob];
                        Ts || K(43);
                        void 0 === b.noGtmEvent && b.eventMetadata && b.eventMetadata.syn_or_mod && (b.noGtmEvent = !0);
                        h.eventModel[L.g.rb] && (b.noGtmEvent = !0);
                        return b.noGtmEvent ? void 0 : h
                    }
                }
            },
            get: function(a, b) {
                K(53);
                if (4 === a.length && g(a[1]) && g(a[2]) && ua(a[3])) {
                    var c = ll(a[1], b.isGtmEvent),
                        d = String(a[2]),
                        e = a[3];
                    if (c) {
                        Ts || K(43);
                        var f = Zs();
                        if (!ya(rg(), function(l) {
                                return c.ba === l
                            })) Qq(c.ba, f, {
                            source: 4,
                            fromContainerExecution: b.fromContainerExecution
                        });
                        else if (-1 !== Ss.indexOf(wg(c.prefix))) {
                            Vs(a, b);
                            var h = {};
                            Vf(z((h[L.g.cb] = d, h[L.g.pb] =
                                e, h)));
                            fm(d, function(l) {
                                H(function() {
                                    return e(l)
                                })
                            }, c.id, b)
                        }
                    }
                }
            },
            js: function(a, b) {
                if (2 == a.length && a[1].getTime) {
                    Ts = !0;
                    var c = Vs(a, b),
                        d = c.eventId,
                        e = c.priorityId,
                        f = {};
                    return f.event = "gtm.js", f["gtm.start"] = a[1].getTime(), f["gtm.uniqueEventId"] = d, f["gtm.priorityId"] = e, f
                }
            },
            policy: function() {},
            set: function(a, b) {
                var c;
                2 == a.length && Ya(a[1]) ? c = z(a[1]) : 3 == a.length && g(a[1]) && (c = {}, Ya(a[2]) || xa(a[2]) ? c[a[1]] = z(a[2]) : c[a[1]] = a[2]);
                if (c) {
                    var d = Vs(a, b),
                        e = d.eventId,
                        f = d.priorityId;
                    z(c);
                    var h = z(c);
                    dm.push("set", [h],
                        void 0, b);
                    c["gtm.uniqueEventId"] = e;
                    f && (c["gtm.priorityId"] = f);
                    P(13) && delete c.event;
                    b.overwriteModelFields = !0;
                    return c
                }
            }
        },
        at = {
            policy: !0
        };
    var bt = function(a) {
            var b = C[xe.da].hide;
            if (b && void 0 !== b[a] && b.end) {
                b[a] = !1;
                var c = !0,
                    d;
                for (d in b)
                    if (b.hasOwnProperty(d) && !0 === b[d]) {
                        c = !1;
                        break
                    }
                c && (b.end(), b.end = null)
            }
        },
        ct = function(a) {
            var b = C[xe.da],
                c = b && b.hide;
            c && c.end && (c[a] = !0)
        };
    var dt = !1,
        et = [];

    function ft() {
        if (!dt) {
            dt = !0;
            for (var a = 0; a < et.length; a++) H(et[a])
        }
    }
    var gt = function(a) {
        dt ? H(a) : et.push(a)
    };
    var xt = function(a) {
        if (wt(a)) return a;
        this.h = a
    };
    xt.prototype.getUntrustedMessageValue = function() {
        return this.h
    };
    var wt = function(a) {
        return !a || "object" !== Va(a) || Ya(a) ? !1 : "getUntrustedMessageValue" in a
    };
    xt.prototype.getUntrustedMessageValue = xt.prototype.getUntrustedMessageValue;
    var zt = 0,
        At = {},
        Bt = [],
        Ct = [],
        Dt = !1,
        Et = !1;

    function Ft(a, b) {
        return a.messageContext.eventId - b.messageContext.eventId || a.messageContext.priorityId - b.messageContext.priorityId
    }
    var Gt = function(a) {
            return C[xe.da].push(a)
        },
        Ht = function(a, b) {
            if (!va(b) || 0 > b) b = 0;
            var c = ye[xe.da],
                d = 0,
                e = !1,
                f = void 0;
            f = C.setTimeout(function() {
                e || (e = !0, a());
                f = void 0
            }, b);
            return function() {
                var h = c ? c.subscribers : 1;
                ++d === h && (f && (C.clearTimeout(f), f = void 0), e || (a(), e = !0))
            }
        };

    function It(a, b) {
        var c = a._clear || b.overwriteModelFields;
        k(a, function(e, f) {
            "_clear" !== e && (c && af(e), af(e, f))
        });
        Ne || (Ne = a["gtm.start"]);
        var d = a["gtm.uniqueEventId"];
        if (!a.event) return !1;
        "number" !== typeof d && (d = Se(), a["gtm.uniqueEventId"] = d, af("gtm.uniqueEventId", d));
        return Ms(a)
    }

    function Jt(a) {
        if (null == a || "object" !== typeof a) return !1;
        if (a.event) return !0;
        if (Da(a)) {
            var b = a[0];
            if ("config" === b || "event" === b || "js" === b || "get" === b) return !0
        }
        return !1
    }

    function Kt() {
        var a;
        if (Ct.length) a = Ct.shift();
        else if (Bt.length) a = Bt.shift();
        else return;
        var b;
        var c = a;
        if (Dt || !Jt(c.message)) b = c;
        else {
            Dt = !0;
            var d = c.message["gtm.uniqueEventId"];
            "number" !== typeof d && (d = c.message["gtm.uniqueEventId"] = Se());
            var e = {},
                f = {
                    message: (e.event = "gtm.init_consent", e["gtm.uniqueEventId"] = d - 2, e),
                    messageContext: {
                        eventId: d - 2
                    }
                },
                h = {},
                l = {
                    message: (h.event = "gtm.init", h["gtm.uniqueEventId"] = d - 1, h),
                    messageContext: {
                        eventId: d - 1
                    }
                };
            Bt.unshift(l, c);
            if (Ng) {
                var m = mg.ctid;
                if (m) {
                    var n, p = vg(Bg());
                    n = p && p.context;
                    var q, t = Aj(C.location.href);
                    q = t.hostname + t.pathname;
                    var r = n && n.fromContainerExecution,
                        u = n && n.source,
                        v = mg.He,
                        w = kg.nd;
                    Ng && (Pl || (Pl = q), Ql.push(m + ";" + v + ";" + (r ? 1 : 0) + ";" + (u || 0) + ";" + (w ? 1 : 0)))
                }
            }
            b = f
        }
        return b
    }

    function Lt() {
        for (var a = !1, b; !Et && (b = Kt());) {
            Et = !0;
            delete Ve.eventModel;
            Xe();
            var c = b,
                d = c.message,
                e = c.messageContext;
            if (null == d) Et = !1;
            else {
                if (e.fromContainerExecution)
                    for (var f = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], h = 0; h < f.length; h++) {
                        var l = f[h],
                            m = Ye(l, 1);
                        if (xa(m) || Ya(m)) m = z(m);
                        We[l] = m
                    }
                try {
                    if (ua(d)) try {
                        d.call(Ze)
                    } catch (D) {} else if (xa(d)) {
                        var n = d;
                        if (g(n[0])) {
                            var p = n[0].split("."),
                                q = p.pop(),
                                t = n.slice(1),
                                r = Ye(p.join("."), 2);
                            if (null != r) try {
                                r[q].apply(r, t)
                            } catch (D) {}
                        }
                    } else {
                        var u =
                            void 0,
                            v = !1;
                        if (Da(d)) {
                            a: {
                                if (d.length && g(d[0])) {
                                    var w = $s[d[0]];
                                    if (w && (!e.fromContainerExecution || !at[d[0]])) {
                                        u = w(d, e);
                                        break a
                                    }
                                }
                                u = void 0
                            }(v = u && "set" === d[0] && !!u.event) && K(101)
                        }
                        else u = d;
                        if (u) {
                            var x = It(u, e);
                            a = x || a;
                            v && x && K(113)
                        }
                    }
                } finally {
                    e.fromContainerExecution && Xe(!0);
                    var y = d["gtm.uniqueEventId"];
                    if ("number" === typeof y) {
                        for (var A = At[String(y)] || [], B = 0; B < A.length; B++) Ct.push(Mt(A[B]));
                        A.length && Ct.sort(Ft);
                        delete At[String(y)];
                        y > zt && (zt = y)
                    }
                    Et = !1
                }
            }
        }
        return !a
    }

    function Nt() {
        if (P(24)) {
            var a = Ot();
        }
        var b = Lt();
        if (P(24)) {}
        try {
            bt(tg())
        } catch (c) {}
        return b
    }

    function rs(a) {
        if (zt < a.notBeforeEventId) {
            var b = String(a.notBeforeEventId);
            At[b] = At[b] || [];
            At[b].push(a)
        } else Ct.push(Mt(a)), Ct.sort(Ft), H(function() {
            Et || Lt()
        })
    }

    function Mt(a) {
        return {
            message: a.message,
            messageContext: a.messageContext
        }
    }
    var Pt = function() {
            function a(f) {
                var h = {};
                if (wt(f)) {
                    var l = f;
                    f = wt(l) ? l.getUntrustedMessageValue() : void 0;
                    h.fromContainerExecution = !0
                }
                return {
                    message: f,
                    messageContext: h
                }
            }
            var b = Sb(xe.da, []),
                c = ye[xe.da] = ye[xe.da] || {};
            !0 === c.pruned && K(83);
            At = ps().get();
            ss();
            vr(function() {
                if (!c.gtmDom) {
                    c.gtmDom = !0;
                    var f = {};
                    b.push((f.event = "gtm.dom", f))
                }
            });
            gt(function() {
                if (!c.gtmLoad) {
                    c.gtmLoad = !0;
                    var f = {};
                    b.push((f.event = "gtm.load", f))
                }
            });
            c.subscribers = (c.subscribers || 0) + 1;
            var d = b.push;
            b.push = function() {
                var f;
                if (0 < ye.SANDBOXED_JS_SEMAPHORE) {
                    f = [];
                    for (var h = 0; h < arguments.length; h++) f[h] = new xt(arguments[h])
                } else f = [].slice.call(arguments, 0);
                var l = f.map(function(q) {
                    return a(q)
                });
                Bt.push.apply(Bt, l);
                var m = d.apply(b, f),
                    n = Math.max(100, Number("1000") || 300);
                if (this.length > n)
                    for (K(4), c.pruned = !0; this.length > n;) this.shift();
                var p = "boolean" !== typeof m || m;
                return Lt() && p
            };
            var e = b.slice(0).map(function(f) {
                return a(f)
            });
            Bt.push.apply(Bt, e);
            if (Ot()) {
                if (P(24)) {}
                H(Nt)
            }
        },
        Ot = function() {
            var a = !0;
            return a
        };

    function Qt(a) {
        if (null == a || 0 === a.length) return !1;
        var b = Number(a),
            c = Ka();
        return b < c + 3E5 && b > c - 9E5
    }

    function Rt(a) {
        return a && 0 === a.indexOf("pending:") ? Qt(a.substr(8)) : !1
    };
    var lu = function() {};
    var mu = function() {};
    mu.prototype.toString = function() {
        return "undefined"
    };
    var nu = new mu;
    var uu = function(a, b, c) {
            var d = {
                event: b,
                "gtm.element": a,
                "gtm.elementClasses": hc(a, "className"),
                "gtm.elementId": a["for"] || cc(a, "id") || "",
                "gtm.elementTarget": a.formTarget || hc(a, "target") || ""
            };
            c && (d["gtm.triggers"] = c.join(","));
            d["gtm.elementUrl"] = (a.attributes && a.attributes.formaction ? a.formAction : "") || a.action || hc(a, "href") || a.src || a.code || a.codebase || "";
            return d
        },
        vu = function(a) {
            ye.hasOwnProperty("autoEventsSettings") || (ye.autoEventsSettings = {});
            var b = ye.autoEventsSettings;
            b.hasOwnProperty(a) || (b[a] = {});
            return b[a]
        },
        wu = function(a, b, c) {
            vu(a)[b] = c
        },
        xu = function(a, b, c, d) {
            var e = vu(a),
                f = La(e, b, d);
            e[b] = c(f)
        },
        yu = function(a, b, c) {
            var d = vu(a);
            return La(d, b, c)
        };
    var Su = C.clearTimeout,
        Tu = C.setTimeout,
        V = function(a, b, c, d) {
            if (aj()) {
                b && H(b)
            } else return Xb(a, b, c, d)
        },
        Uu = function() {
            return new Date
        },
        Vu = function() {
            return C.location.href
        },
        Wu = function(a) {
            return yj(Aj(a), "fragment")
        },
        Xu = function(a) {
            return zj(Aj(a))
        },
        Yu = function(a, b) {
            return Ye(a, b || 2)
        },
        Zu = function(a, b, c) {
            var d;
            b ? (a.eventCallback = b, c && (a.eventTimeout = c), d = Gt(a)) : d = Gt(a);
            return d
        },
        $u = function(a, b) {
            C[a] = b
        },
        W = function(a, b, c) {
            b &&
                (void 0 === C[a] || c && !C[a]) && (C[a] = b);
            return C[a]
        },
        av = function(a, b, c) {
            return Ii(a, b, void 0 === c ? !0 : !!c)
        },
        bv = function(a, b, c) {
            return 0 === Ri(a, b, c)
        },
        cv = function(a, b) {
            if (aj()) {
                b && H(b)
            } else Zb(a, b)
        },
        dv = function(a) {
            return !!yu(a, "init", !1)
        },
        ev = function(a) {
            wu(a, "init", !0)
        },
        fv = function(a, b, c) {
            Za(a) || $r(c, b, a)
        };

    function Cv(a, b) {
        function c(h) {
            var l = Aj(h),
                m = yj(l, "protocol"),
                n = yj(l, "host", !0),
                p = yj(l, "port"),
                q = yj(l, "path").toLowerCase().replace(/\/$/, "");
            if (void 0 === m || "http" === m && "80" === p || "https" === m && "443" === p) m = "web", p = "default";
            return [m, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function Dv(a) {
        return Ev(a) ? 1 : 0
    }

    function Ev(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Array.isArray(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = z(a, {});
                z({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (Dv(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return 0 <= String(b).indexOf(String(c));
            case "_css":
                var f;
                a: {
                    if (b) try {
                        for (var h = 0; h < vd.length; h++) {
                            var l = vd[h];
                            if (b[l]) {
                                f = b[l](c);
                                break a
                            }
                        }
                    } catch (v) {}
                    f = !1
                }
                return f;
            case "_ew":
                var m, n;
                m = String(b);
                n = String(c);
                var p = m.length - n.length;
                return 0 <= p && m.indexOf(n, p) === p;
            case "_eq":
                return String(b) === String(c);
            case "_ge":
                return Number(b) >= Number(c);
            case "_gt":
                return Number(b) > Number(c);
            case "_lc":
                return 0 <= String(b).split(",").indexOf(String(c));
            case "_le":
                return Number(b) <= Number(c);
            case "_lt":
                return Number(b) < Number(c);
            case "_re":
                var q;
                var t = a.ignore_case ? "i" : void 0;
                try {
                    var r = String(c) + t,
                        u = wd.get(r);
                    u || (u = new RegExp(c, t), wd.set(r, u));
                    q = u.test(b)
                } catch (v) {
                    q = !1
                }
                return q;
            case "_sw":
                return 0 === String(b).indexOf(String(c));
            case "_um":
                return Cv(b, c)
        }
        return !1
    };

    function Fv() {
        var a = ["&cv=3", "&rv=" + xe.Lf, "&tc=" + Pc.filter(function(b) {
            return b
        }).length];
        xe.qd && a.push("&x=" + xe.qd);
        return a.join("")
    };
    var Gv = function(a, b) {
            var c;
            c = b ? [cp, dp, fp, Qo, Uo, ip, Vo, gp, hp, ap, Ro, mp, Wo, ep, Oo, No, jp, Ko] : [Fm, Po, Fo, So, Go, Ho, Io, Jo, Xo, Yo, $o, bp, To, Zo, kp, lp];
            for (var d = 0; d < c.length && (c[d](a), !a.isAborted); d++);
        },
        Hv = function(a, b, c, d) {
            var e = new Dl(b, c, d);
            e.metadata.hit_type = a;
            e.metadata.speculative = !0;
            e.metadata.event_start_timestamp_ms = Ka();
            e.metadata.speculative_in_message = d.eventMetadata.speculative;
            return e
        },
        Iv = function(a, b, c, d) {
            function e() {
                for (var t = 0; t < h.length; t++) {
                    var r = h[t];
                    r.isAborted || (Gv(h[t], !0), r.metadata.speculative ||
                        r.isAborted || vq(r))
                }
            }
            var f = ll(a, d.isGtmEvent);
            if (f) {
                var h = [];
                if (d.eventMetadata.hit_type_override) {
                    var l = d.eventMetadata.hit_type_override;
                    Array.isArray(l) || (l = [l]);
                    for (var m = 0; m < l.length; m++) {
                        var n = Hv(l[m], f, b, d);
                        n.metadata.speculative = !1;
                        h.push(n)
                    }
                } else b === L.g.qa && h.push(Hv("landing_page", f, b, d)), h.push(Hv("conversion", f, b, d)), h.push(Hv("user_data_lead", f, b, d)), h.push(Hv("user_data_web", f, b, d)), h.push(Hv("remarketing", f, b, d));
                for (var p = 0; p < h.length; p++) Gv(h[p], !1);
                var q = [L.g.H];
                P(61) && q.push(L.g.N);
                cg(function() {
                    for (var t = [], r = [], u = 0; u < h.length; u++) {
                        var v = h[u];
                        t.push(v.isAborted);
                        r.push(v.metadata.speculative)
                    }
                    e();
                    R(q) || bg(function(w) {
                        var x = w.consentEventId,
                            y = w.consentPriorityId;
                        if (R(q)) {
                            for (var A = 0; A < h.length; A++) {
                                var B = h[A];
                                B.metadata.consent_updated = !0;
                                B.metadata.speculative = r[A];
                                B.metadata.event_start_timestamp_ms = Ka();
                                B.isAborted = t[A];
                                B.metadata.consent_event_id = x;
                                B.metadata.consent_priority_id = y
                            }
                            e()
                        }
                    }, q)
                }, q)
            }
        };
    var jw = function() {
            var a = !0;
            mi(7) && mi(9) && mi(10) || (a = !1);
            return a
        },
        kw = function() {
            var a = !0;
            mi(3) && mi(4) || (a = !1);
            return a
        };
    var ow = function(a, b) {
            if (!b.isGtmEvent) {
                var c = T(b, L.g.cb),
                    d = T(b, L.g.pb),
                    e = T(b, c);
                if (void 0 === e) {
                    var f = void 0;
                    lw.hasOwnProperty(c) ? f = lw[c] : mw.hasOwnProperty(c) && (f = mw[c]);
                    1 === f && (f = nw(c));
                    g(f) ? Hr()(function() {
                        var h = Hr().getByName(a).get(f);
                        d(h)
                    }) : d(void 0)
                } else d(e)
            }
        },
        pw = function(a, b) {
            var c = a[L.g.qc],
                d = b + ".",
                e = a[L.g.T] || "",
                f = void 0 === c ? !!a.use_anchor : "fragment" === c,
                h = !!a[L.g.Mb];
            e = String(e).replace(/\s+/g, "").split(",");
            var l = Hr();
            l(d + "require", "linker");
            l(d + "linker:autoLink", e, f, h)
        },
        tw = function(a,
            b, c) {
            if (Pf() || P(35))
                if (!c.isGtmEvent || !qw[a]) {
                    var d = !R(L.g.P),
                        e = function(f) {
                            var h, l, m = Hr(),
                                n = rw(b, "", c),
                                p, q = n.createOnlyFields._useUp;
                            if (c.isGtmEvent || sw(b, n.createOnlyFields)) {
                                c.isGtmEvent && (h = "gtm" + Se(), l = n.createOnlyFields, n.gtmTrackerName && (l.name = h));
                                m(function() {
                                    var r = m.getByName(b);
                                    r && (p = r.get("clientId"));
                                    c.isGtmEvent || m.remove(b)
                                });
                                m("create", a, c.isGtmEvent ? l : n.createOnlyFields);
                                d && R(L.g.P) && (d = !1, m(function() {
                                    var r = Hr().getByName(c.isGtmEvent ? h : b);
                                    !r || r.get("clientId") == p && q || (c.isGtmEvent ? (n.fieldsToSet["&gcu"] = "1", n.fieldsToSet["&sst.gcut"] = re[f]) : (n.fieldsToSend["&gcu"] = "1", n.fieldsToSend["&sst.gcut"] = re[f]), r.set(n.fieldsToSet), c.isGtmEvent ? r.send("pageview") : r.send("pageview", n.fieldsToSend))
                                }));
                                c.isGtmEvent && m(function() {
                                    m.remove(h)
                                })
                            }
                        };
                    bg(function() {
                        return e(L.g.P)
                    }, L.g.P);
                    bg(function() {
                            return e(L.g.H)
                        },
                        L.g.H);
                    c.isGtmEvent && (qw[a] = !0)
                }
        },
        uw = function(a, b) {
            Nl() && b && (a[L.g.Kb] = b)
        },
        Dw = function(a, b, c) {
            function d() {
                var E = T(c, L.g.Pc);
                l(function() {
                    if (!c.isGtmEvent && Ya(E)) {
                        var G = u.fieldsToSend,
                            M = m().getByName(n),
                            Q;
                        for (Q in E)
                            if (E.hasOwnProperty(Q) && /^(dimension|metric)\d+$/.test(Q) && void 0 != E[Q]) {
                                var ba = M.get(nw(E[Q]));
                                vw(G, Q, ba)
                            }
                    }
                })
            }

            function e() {
                if (u.displayfeatures) {
                    var E = "_dc_gtm_" + f.replace(/[^A-Za-z0-9-]/g, "");
                    p("require", "displayfeatures", void 0, {
                        cookieName: E
                    })
                }
            }
            var f = a,
                h = "https://www.google-analytics.com/analytics.js",
                l = c.isGtmEvent ? Jr(T(c, "gaFunctionName")) : Jr();
            if (ua(l)) {
                var m = Hr,
                    n;
                c.isGtmEvent ? n = T(c, "name") || T(c, "gtmTrackerName") : n = "gtag_" + f.split("-").join("_");
                var p = function(E) {
                        var G = [].slice.call(arguments, 0);
                        G[0] = n ? n + "." + G[0] : "" + G[0];
                        l.apply(window, G)
                    },
                    q = function(E) {
                        var G = function(ca, Z) {
                                for (var U = 0; Z && U < Z.length; U++) p(ca, Z[U])
                            },
                            M = c.isGtmEvent,
                            Q = M ? ww(u) : xw(b, c);
                        if (Q) {
                            var ba = {};
                            uw(ba, E);
                            p("require", "ec", "ec.js", ba);
                            M && Q.Qf && p("set", "&cu", Q.Qf);
                            var S = Q.action;
                            if (M || "impressions" === S)
                                if (G("ec:addImpression",
                                        Q.ii), !M) return;
                            if ("promo_click" === S || "promo_view" === S || M && Q.Od) {
                                var O = Q.Od;
                                G("ec:addPromo", O);
                                if (O && 0 < O.length && "promo_click" === S) {
                                    M ? p("ec:setAction", S, Q.Ua) : p("ec:setAction", S);
                                    return
                                }
                                if (!M) return
                            }
                            "promo_view" !== S && "impressions" !== S && (G("ec:addProduct", Q.Wb), p("ec:setAction", S, Q.Ua))
                        }
                    },
                    t = function(E) {
                        if (E) {
                            var G = {};
                            if (Ya(E))
                                for (var M in yw) yw.hasOwnProperty(M) && zw(yw[M], M, E[M], G);
                            uw(G, x);
                            p("require", "linkid", G)
                        }
                    },
                    r = function() {
                        if (aj()) {} else {
                            var E =
                                T(c, L.g.Gj);
                            E && (p("require", E, {
                                dataLayer: xe.da
                            }), p("require", "render"))
                        }
                    },
                    u = rw(n, b, c),
                    v = function(E, G, M) {
                        M && (G = "" + G);
                        u.fieldsToSend[E] = G
                    };
                !c.isGtmEvent && sw(n, u.createOnlyFields) && (l(function() {
                    m() && m().remove(n)
                }), Aw[n] = !1);
                l("create", f, u.createOnlyFields);
                if (u.createOnlyFields[L.g.Kb] && !c.isGtmEvent) {
                    var w = Ge || Ie ? Ml(u.createOnlyFields[L.g.Kb], "/analytics.js") : void 0;
                    w && (h = w)
                }
                var x = c.isGtmEvent ? u.fieldsToSet[L.g.Kb] : u.createOnlyFields[L.g.Kb];
                if (x) {
                    var y = c.isGtmEvent ? u.fieldsToSet[L.g.je] : u.createOnlyFields[L.g.je];
                    y && !Aw[n] && (Aw[n] = !0, l(Mr(n, y)))
                }
                c.isGtmEvent ? u.enableRecaptcha && p("require", "recaptcha", "recaptcha.js") : (d(), t(u.linkAttribution));
                var A = u[L.g.Ha];
                A && A[L.g.T] && pw(A, n);
                p("set", u.fieldsToSet);
                if (c.isGtmEvent) {
                    if (u.enableLinkId) {
                        var B = {};
                        uw(B, x);
                        p("require", "linkid", "linkid.js", B)
                    }
                    tw(f, n, c)
                }
                if (b === L.g.jc)
                    if (c.isGtmEvent) {
                        e();
                        if (u.remarketingLists) {
                            var D = "_dc_gtm_" + f.replace(/[^A-Za-z0-9-]/g, "");
                            p("require", "adfeatures", {
                                cookieName: D
                            })
                        }
                        q(x);
                        p("send", "pageview");
                        u.createOnlyFields._useUp && Kr(n + ".")
                    } else r(),
                        p("send", "pageview", u.fieldsToSend);
                else b === L.g.qa ? (r(), zl(f, c), T(c, L.g.wb) && (Yk(["aw", "dc"]), Kr(n + ".")), $k(["aw", "dc"]), 0 != u.sendPageView && p("send", "pageview", u.fieldsToSend), tw(f, n, c)) : b === L.g.La ? ow(n, c) : "screen_view" === b ? p("send", "screenview", u.fieldsToSend) : "timing_complete" === b ? (u.fieldsToSend.hitType = "timing", v("timingCategory", u.eventCategory, !0), c.isGtmEvent ? v("timingVar", u.timingVar, !0) : v("timingVar", u.name, !0), v("timingValue", Ea(u.value)), void 0 !== u.eventLabel && v("timingLabel", u.eventLabel, !0), p("send", u.fieldsToSend)) : "exception" === b ? p("send", "exception", u.fieldsToSend) : "" === b && c.isGtmEvent || ("track_social" === b && c.isGtmEvent ? (u.fieldsToSend.hitType = "social", v("socialNetwork", u.socialNetwork, !0), v("socialAction", u.socialAction, !0), v("socialTarget", u.socialTarget, !0)) : ((c.isGtmEvent || Bw[b]) && q(x), c.isGtmEvent && e(), u.fieldsToSend.hitType = "event", v("eventCategory", u.eventCategory, !0), v("eventAction", u.eventAction || b, !0), void 0 !== u.eventLabel && v("eventLabel", u.eventLabel, !0), void 0 !== u.value &&
                    v("eventValue", Ea(u.value))), p("send", u.fieldsToSend));
                if (!Cw && !c.isGtmEvent) {
                    Cw = !0;
                    var I = function() {
                            c.onFailure()
                        },
                        J = function() {
                            m().loaded || I()
                        };
                    aj() ? H(J) : Xb(h, J, I)
                }
            } else H(c.onFailure)
        },
        Ew = function(a, b, c, d) {
            cg(function() {
                Dw(a, b, d)
            }, [L.g.P, L.g.H])
        },
        Gw = function(a) {
            function b(e) {
                function f(l, m) {
                    for (var n = 0; n < m.length; n++) {
                        var p = m[n];
                        if (e[p]) {
                            h[l] = e[p];
                            break
                        }
                    }
                }
                var h = z(e);
                f("id", ["id", "item_id", "promotion_id"]);
                f("name", ["name", "item_name", "promotion_name"]);
                f("brand", ["brand", "item_brand"]);
                f("variant", ["variant", "item_variant"]);
                f("list", ["list_name", "item_list_name"]);
                f("position", ["list_position", "creative_slot", "index"]);
                (function() {
                    if (e.category) h.category = e.category;
                    else {
                        for (var l = "", m = 0; m < Fw.length; m++) void 0 !== e[Fw[m]] && (l && (l += "/"), l += e[Fw[m]]);
                        l && (h.category = l)
                    }
                })();
                f("listPosition", ["list_position"]);
                f("creative", ["creative_name"]);
                f("list", ["list_name"]);
                f("position", ["list_position", "creative_slot"]);
                return h
            }
            for (var c = [], d = 0; a && d < a.length; d++) a[d] && Ya(a[d]) && c.push(b(a[d]));
            return c.length ?
                c : void 0
        },
        Hw = function(a) {
            return R(a)
        },
        Iw = !1;
    var Cw, Aw = {},
        qw = {},
        Jw = {},
        Kw = Object.freeze((Jw.page_hostname = 1, Jw[L.g.X] = 1, Jw[L.g.Za] = 1, Jw[L.g.Ra] = 1, Jw[L.g.Fa] = 1, Jw[L.g.Sa] = 1, Jw[L.g.mc] = 1, Jw[L.g.Oc] = 1, Jw[L.g.Na] = 1, Jw[L.g.nb] = 1, Jw[L.g.za] = 1, Jw[L.g.Xc] = 1, Jw[L.g.Ia] = 1, Jw[L.g.tb] = 1, Jw)),
        Lw = {},
        lw = Object.freeze((Lw.client_storage = "storage", Lw.sample_rate = 1, Lw.site_speed_sample_rate = 1, Lw.store_gac = 1, Lw.use_amp_client_id =
            1, Lw[L.g.lb] = 1, Lw[L.g.Da] = "storeGac", Lw[L.g.Ra] = 1, Lw[L.g.Fa] = 1, Lw[L.g.Sa] = 1, Lw[L.g.mc] = 1, Lw[L.g.Oc] = 1, Lw[L.g.nb] = 1, Lw)),
        Mw = {},
        Nw = Object.freeze((Mw._cs = 1, Mw._useUp = 1, Mw.allowAnchor = 1, Mw.allowLinker = 1, Mw.alwaysSendReferrer = 1, Mw.clientId = 1, Mw.cookieDomain = 1, Mw.cookieExpires = 1, Mw.cookieFlags = 1, Mw.cookieName = 1, Mw.cookiePath = 1, Mw.cookieUpdate = 1, Mw.legacyCookieDomain = 1, Mw.legacyHistoryImport = 1, Mw.name = 1, Mw.sampleRate = 1, Mw.siteSpeedSampleRate = 1, Mw.storage = 1, Mw.storeGac = 1, Mw.useAmpClientId = 1, Mw._cd2l = 1, Mw)),
        Ow = Object.freeze({
            anonymize_ip: 1
        }),
        Pw = {},
        mw = Object.freeze((Pw.campaign = {
                content: "campaignContent",
                id: "campaignId",
                medium: "campaignMedium",
                name: "campaignName",
                source: "campaignSource",
                term: "campaignKeyword"
            }, Pw.app_id = 1, Pw.app_installer_id = 1, Pw.app_name = 1, Pw.app_version = 1, Pw.description = "exDescription", Pw.fatal = "exFatal", Pw.language = 1, Pw.page_hostname = "hostname", Pw.transport_type = "transport", Pw[L.g.sa] = "currencyCode", Pw[L.g.ih] = 1, Pw[L.g.za] = "location", Pw[L.g.Xc] = "page", Pw[L.g.Ia] = "referrer", Pw[L.g.tb] =
            "title", Pw[L.g.Df] = 1, Pw[L.g.Pa] = 1, Pw)),
        Qw = {},
        Rw = Object.freeze((Qw.content_id = 1, Qw.event_action = 1, Qw.event_category = 1, Qw.event_label = 1, Qw.link_attribution = 1, Qw.name = 1, Qw[L.g.Ha] = 1, Qw[L.g.hh] = 1, Qw[L.g.Oa] = 1, Qw[L.g.fa] = 1, Qw)),
        Sw = Object.freeze({
            displayfeatures: 1,
            enableLinkId: 1,
            enableRecaptcha: 1,
            eventAction: 1,
            eventCategory: 1,
            eventLabel: 1,
            gaFunctionName: 1,
            gtmEcommerceData: 1,
            gtmTrackerName: 1,
            linker: 1,
            remarketingLists: 1,
            socialAction: 1,
            socialNetwork: 1,
            socialTarget: 1,
            timingVar: 1,
            value: 1
        }),
        Fw = Object.freeze(["item_category",
            "item_category2", "item_category3", "item_category4", "item_category5"
        ]),
        Tw = {},
        yw = Object.freeze((Tw.levels = 1, Tw[L.g.Fa] = "duration", Tw[L.g.mc] = 1, Tw)),
        Uw = {},
        Vw = Object.freeze((Uw.anonymize_ip = 1, Uw.fatal = 1, Uw.send_page_view = 1, Uw.store_gac = 1, Uw.use_amp_client_id = 1, Uw[L.g.Da] = 1, Uw[L.g.ih] = 1, Uw)),
        zw = function(a, b, c, d) {
            if (void 0 !== c)
                if (Vw[b] && (c = Fa(c)), "anonymize_ip" !== b || c || (c = void 0), 1 === a) d[nw(b)] = c;
                else if (g(a)) d[a] = c;
            else
                for (var e in a) a.hasOwnProperty(e) && void 0 !== c[e] && (d[a[e]] = c[e])
        },
        nw = function(a) {
            return a &&
                g(a) ? a.replace(/(_[a-z])/g, function(b) {
                    return b[1].toUpperCase()
                }) : a
        },
        Ww = {},
        Bw = Object.freeze((Ww.checkout_progress = 1, Ww.select_content = 1, Ww.set_checkout_option = 1, Ww[L.g.bc] = 1, Ww[L.g.fc] = 1, Ww[L.g.Gb] = 1, Ww[L.g.hc] = 1, Ww[L.g.Xa] = 1, Ww[L.g.jb] = 1, Ww[L.g.Ya] = 1, Ww[L.g.oa] = 1, Ww[L.g.ic] = 1, Ww[L.g.Ba] = 1, Ww)),
        Xw = {},
        Yw = Object.freeze((Xw.checkout_progress = 1, Xw.set_checkout_option = 1, Xw[L.g.Eg] = 1, Xw[L.g.Fg] = 1, Xw[L.g.bc] = 1, Xw[L.g.fc] = 1, Xw[L.g.Gg] = 1, Xw[L.g.Gb] = 1, Xw[L.g.oa] = 1, Xw[L.g.ic] = 1, Xw[L.g.Hg] = 1, Xw)),
        Zw = {},
        $w = Object.freeze((Zw.generate_lead =
            1, Zw.login = 1, Zw.search = 1, Zw.select_content = 1, Zw.share = 1, Zw.sign_up = 1, Zw.view_search_results = 1, Zw[L.g.hc] = 1, Zw[L.g.Xa] = 1, Zw[L.g.jb] = 1, Zw[L.g.Ya] = 1, Zw[L.g.Ba] = 1, Zw)),
        ax = function(a) {
            var b = "general";
            Yw[a] ? b = "ecommerce" : $w[a] ? b = "engagement" : "exception" === a && (b = "error");
            return b
        },
        bx = {},
        cx = Object.freeze((bx.view_search_results = 1, bx[L.g.Xa] = 1, bx[L.g.Ya] = 1, bx[L.g.Ba] = 1, bx)),
        vw = function(a, b, c) {
            a.hasOwnProperty(b) || (a[b] = c)
        },
        dx = function(a) {
            if (xa(a)) {
                for (var b = [], c = 0; c < a.length; c++) {
                    var d = a[c];
                    if (void 0 != d) {
                        var e =
                            d.id,
                            f = d.variant;
                        void 0 != e && void 0 != f && b.push(String(e) + "." + String(f))
                    }
                }
                return 0 < b.length ? b.join("!") : void 0
            }
        },
        rw = function(a, b, c) {
            var d = function(M) {
                    return T(c, M)
                },
                e = {},
                f = {},
                h = {},
                l = {},
                m = dx(d(L.g.Ej));
            !c.isGtmEvent && m && vw(f, "exp", m);
            h["&gtm"] = cj(c.eventMetadata.source_canonical_id, !0);
            c.isGtmEvent || (h._no_slc = !0);
            Pf() && (l._cs = Hw);
            var n = d(L.g.Pc);
            if (!c.isGtmEvent && Ya(n))
                for (var p in n)
                    if (n.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) && void 0 != n[p]) {
                        var q = d(String(n[p]));
                        void 0 !== q && vw(f, p, q)
                    }
            for (var t = !c.isGtmEvent, r = ch(c), u = 0; u < r.length; ++u) {
                var v = r[u];
                if (c.isGtmEvent) {
                    var w = d(v);
                    Sw.hasOwnProperty(v) ? e[v] = w : Nw.hasOwnProperty(v) ? l[v] = w : h[v] = w
                } else {
                    var x = void 0;
                    x = v !== L.g.aa ? d(v) : dh(c, v);
                    if (Rw.hasOwnProperty(v)) zw(Rw[v], v, x, e);
                    else if (Ow.hasOwnProperty(v)) zw(Ow[v], v, x, h);
                    else if (mw.hasOwnProperty(v)) zw(mw[v], v, x, f);
                    else if (lw.hasOwnProperty(v)) zw(lw[v], v, x, l);
                    else if (/^(dimension|metric|content_group)\d+$/.test(v)) zw(1, v, x, f);
                    else if (v === L.g.aa) {
                        if (!Iw) {
                            var y = Sa(x);
                            y && (f["&did"] = y)
                        }
                        var A = void 0,
                            B = void 0;
                        b === L.g.qa ? A = Sa(dh(c, v), ".") : (A = Sa(dh(c, v, 1), "."), B = Sa(dh(c, v, 2), "."));
                        A && (f["&gdid"] = A);
                        B && (f["&edid"] = B)
                    } else v === L.g.Na && 0 > r.indexOf(L.g.mc) && (l.cookieName = x + "_ga");
                    P(33) && Kw[v] && (c.D.hasOwnProperty(v) || b === L.g.qa && c.h.hasOwnProperty(v)) && (t = !1)
                }
            }
            P(33) && t && (f["&jsscut"] = "1");
            !1 !== d(L.g.qf) && !1 !== d(L.g.Za) && jw() || (h.allowAdFeatures = !1);
            si(c) && (P(62) || kw()) ? P(41) && (h.allowAdPersonalizationSignals = !0) : h.allowAdPersonalizationSignals = !1;
            !c.isGtmEvent && d(L.g.wb) && (l._useUp = !0);
            if (c.isGtmEvent) {
                l.name =
                    l.name || e.gtmTrackerName;
                var D = h.hitCallback;
                h.hitCallback = function() {
                    ua(D) && D();
                    c.onSuccess()
                }
            } else {
                vw(l, "cookieDomain", "auto");
                vw(h, "forceSSL", !0);
                vw(e, "eventCategory", ax(b));
                cx[b] && vw(f, "nonInteraction", !0);
                "login" === b || "sign_up" === b || "share" === b ? vw(e, "eventLabel", d(L.g.hh)) : "search" === b || "view_search_results" === b ? vw(e, "eventLabel", d(L.g.Mj)) : "select_content" === b && vw(e, "eventLabel", d(L.g.vj));
                var I = e[L.g.Ha] || {},
                    J = I[L.g.Vc];
                J || 0 != J && I[L.g.T] ? l.allowLinker = !0 : !1 === J && vw(l, "useAmpClientId", !1);
                f.hitCallback =
                    c.onSuccess;
                l.name = a
            }
            ti() && (h["&gcs"] = ui());
            P(37) && (h["&gcd"] = yi(c));
            Pf() && (R(L.g.P) || (l.storage = "none"), R(L.g.H) || (h.allowAdFeatures = !1, l.storeGac = !1));
            P(39) && (Ci() && (h["&dma_cps"] = zi()), h["&dma"] = Bi());
            P(62) && Uh(ci()) && (h["&tcfd"] = Di());
            var E = Ol(c) || d(L.g.Kb),
                G = d(L.g.je);
            E && (c.isGtmEvent || (l[L.g.Kb] = E), l._cd2l = !0);
            G && !c.isGtmEvent && (l[L.g.je] = G);
            e.fieldsToSend = f;
            e.fieldsToSet = h;
            e.createOnlyFields = l;
            return e
        },
        ww = function(a) {
            var b = a.gtmEcommerceData;
            if (!b) return null;
            var c = {};
            b.currencyCode && (c.Qf =
                b.currencyCode);
            if (b.impressions) {
                c.action = "impressions";
                var d = b.impressions;
                c.ii = "impressions" === b.translateIfKeyEquals ? Gw(d) : d
            }
            if (b.promoView) {
                c.action = "promo_view";
                var e = b.promoView.promotions;
                c.Od = "promoView" === b.translateIfKeyEquals ? Gw(e) : e
            }
            if (b.promoClick) {
                c.action = "promo_click";
                var f = b.promoClick.promotions;
                c.Od = "promoClick" === b.translateIfKeyEquals ? Gw(f) : f;
                c.Ua = b.promoClick.actionField;
                return c
            }
            for (var h in b)
                if (b.hasOwnProperty(h) && "translateIfKeyEquals" !== h && "impressions" !== h && "promoView" !==
                    h && "promoClick" !== h && "currencyCode" !== h) {
                    c.action = h;
                    var l = b[h].products;
                    c.Wb = "products" === b.translateIfKeyEquals ? Gw(l) : l;
                    c.Ua = b[h].actionField;
                    break
                }
            return Object.keys(c).length ? c : null
        },
        xw = function(a, b) {
            function c(u) {
                return {
                    id: d(L.g.wa),
                    affiliation: d(L.g.Lg),
                    revenue: d(L.g.fa),
                    tax: d(L.g.vf),
                    shipping: d(L.g.Sc),
                    coupon: d(L.g.Mg),
                    list: d(L.g.uf) || d(L.g.Rc) || u
                }
            }
            for (var d = function(u) {
                    return T(b, u)
                }, e = d(L.g.Z), f, h = 0; e && h < e.length && !(f = e[h][L.g.uf] || e[h][L.g.Rc]); h++);
            var l = d(L.g.Pc);
            if (Ya(l))
                for (var m = 0; e &&
                    m < e.length; ++m) {
                    var n = e[m],
                        p;
                    for (p in l) l.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) && void 0 != l[p] && vw(n, p, n[l[p]])
                }
            var q = null,
                t = d(L.g.zj);
            if (a === L.g.oa || a === L.g.ic) q = {
                action: a,
                Ua: c(),
                Wb: Gw(e)
            };
            else if (a === L.g.bc) q = {
                action: "add",
                Ua: c(),
                Wb: Gw(e)
            };
            else if (a === L.g.fc) q = {
                action: "remove",
                Ua: c(),
                Wb: Gw(e)
            };
            else if (a === L.g.Ba) q = {
                action: "detail",
                Ua: c(f),
                Wb: Gw(e)
            };
            else if (a === L.g.Xa) q = {
                action: "impressions",
                ii: Gw(e)
            };
            else if (a === L.g.Ya) q = {
                action: "promo_view",
                Od: Gw(t) || Gw(e)
            };
            else if ("select_content" ===
                a && t && 0 < t.length || a === L.g.jb) q = {
                action: "promo_click",
                Od: Gw(t) || Gw(e)
            };
            else if ("select_content" === a || a === L.g.hc) q = {
                action: "click",
                Ua: {
                    list: d(L.g.uf) || d(L.g.Rc) || f
                },
                Wb: Gw(e)
            };
            else if (a === L.g.Gb || "checkout_progress" === a) {
                var r = {
                    step: a === L.g.Gb ? 1 : d(L.g.tf),
                    option: d(L.g.ae)
                };
                q = {
                    action: "checkout",
                    Wb: Gw(e),
                    Ua: z(c(), r)
                }
            } else "set_checkout_option" === a && (q = {
                action: "checkout_option",
                Ua: {
                    step: d(L.g.tf),
                    option: d(L.g.ae)
                }
            });
            q && (q.Qf = d(L.g.sa));
            return q
        },
        ex = {},
        sw = function(a, b) {
            var c = ex[a];
            ex[a] = z(b);
            if (!c) return !1;
            for (var d in b)
                if (b.hasOwnProperty(d) && b[d] !== c[d]) return !0;
            for (var e in c)
                if (c.hasOwnProperty(e) && c[e] !== b[e]) return !0;
            return !1
        };
    uf();

    function px() {
        return C.gaGlobal = C.gaGlobal || {}
    }
    var qx = function() {
            var a = px();
            a.hid = a.hid || za();
            return a.hid
        },
        rx = function(a, b) {
            var c = px();
            if (void 0 == c.vid || b && !c.from_cookie) c.vid = a, c.from_cookie = b
        };
    var Zx = function(a) {
            this.C = a;
            this.D = "";
            this.h = this.C
        },
        $x = function(a, b) {
            a.h = b;
            return a
        };

    function ay(a) {
        var b = a.search;
        return a.protocol + "//" + a.hostname + a.pathname + (b ? b + "&richsstsse" : "?richsstsse")
    }

    function by(a, b) {
        var c = a || [];
        if (Array.isArray(c))
            for (var d = 0; d < c.length; d++) b(c[d])
    };
    var qy = window,
        ry = document,
        sy = function(a) {
            var b = qy._gaUserPrefs;
            if (b && b.ioo && b.ioo() || ry.documentElement.hasAttribute("data-google-analytics-opt-out") || a && !0 === qy["ga-disable-" + a]) return !0;
            try {
                var c = qy.external;
                if (c && c._gaUserPrefs && "oo" == c._gaUserPrefs) return !0
            } catch (f) {}
            for (var d = Ei("AMP_TOKEN", String(ry.cookie), !0), e = 0; e < d.length; e++)
                if ("$OPT_OUT" == d[e]) return !0;
            return ry.getElementById("__gaOptOutExtension") ? !0 : !1
        };

    function By(a) {
        k(a, function(c) {
            "_" === c.charAt(0) && delete a[c]
        });
        var b = a[L.g.Ta] || {};
        k(b, function(c) {
            "_" === c.charAt(0) && delete b[c]
        })
    };
    var Jy = function(a, b) {};

    function Iy(a, b) {
        var c = function() {};
        return c
    }

    function Ky(a, b, c) {};
    var Ly = Iy;
    Object.freeze({
        dl: 1,
        id: 1
    });
    Object.freeze(["config", "event", "get", "set"]);
    var Ny = encodeURI,
        X = encodeURIComponent,
        Oy = function(a, b, c) {
            $b(a, b, c)
        },
        Py = function(a, b) {
            if (!a) return !1;
            var c = yj(Aj(a),
                "host");
            if (!c) return !1;
            for (var d = 0; b && d < b.length; d++) {
                var e = b[d] && b[d].toLowerCase();
                if (e) {
                    var f = c.length - e.length;
                    0 < f && "." != e.charAt(0) && (f--, e = "." + e);
                    if (0 <= f && c.indexOf(e, f) == f) return !0
                }
            }
            return !1
        },
        Qy = function(a, b, c) {
            for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
            return e ? d : null
        };
    var Y = {
        m: {}
    };

    Y.m.e = ["google"],
        function() {
            (function(a) {
                Y.__e = a;
                Y.__e.o = "e";
                Y.__e.isVendorTemplate = !0;
                Y.__e.priorityOverride = 0;
                Y.__e.isInfrastructure = !1;
                Y.__e.runInSiloedMode = !0
            })(function(a) {
                return String(a.vtp_gtmCachedValues.event)
            })
        }();
    Y.m.f = ["google"],
        function() {
            (function(a) {
                Y.__f = a;
                Y.__f.o = "f";
                Y.__f.isVendorTemplate = !0;
                Y.__f.priorityOverride = 0;
                Y.__f.isInfrastructure = !1;
                Y.__f.runInSiloedMode = !1
            })(function(a) {
                var b = Yu("gtm.referrer", 1) || F.referrer;
                return b ? a.vtp_component && "URL" != a.vtp_component ? yj(Aj(String(b)), a.vtp_component, a.vtp_stripWww, a.vtp_defaultPages, a.vtp_queryKey) : Xu(String(b)) : String(b)
            })
        }();
    Y.m.cl = ["google"],
        function() {
            function a(b) {
                var c = b.target;
                if (c) {
                    var d = uu(c, "gtm.click");
                    Zu(d)
                }
            }(function(b) {
                Y.__cl = b;
                Y.__cl.o = "cl";
                Y.__cl.isVendorTemplate = !0;
                Y.__cl.priorityOverride = 0;
                Y.__cl.isInfrastructure = !1;
                Y.__cl.runInSiloedMode = !1
            })(function(b) {
                if (!dv("cl")) {
                    var c = W("document");
                    ac(c, "click", a, !0);
                    ev("cl")
                }
                H(b.vtp_gtmOnSuccess)
            })
        }();
    Y.m.u = ["google"],
        function() {
            var a = function(b) {
                return {
                    toString: function() {
                        return b
                    }
                }
            };
            (function(b) {
                Y.__u = b;
                Y.__u.o = "u";
                Y.__u.isVendorTemplate = !0;
                Y.__u.priorityOverride = 0;
                Y.__u.isInfrastructure = !1;
                Y.__u.runInSiloedMode = !1
            })(function(b) {
                var c;
                c = (c = b.vtp_customUrlSource ? b.vtp_customUrlSource : Yu("gtm.url", 1)) || Vu();
                var d = b[a("vtp_component")];
                if (!d || "URL" == d) return Xu(String(c));
                var e = Aj(String(c)),
                    f;
                if ("QUERY" === d) a: {
                    var h = b[a("vtp_multiQueryKeys").toString()],
                        l = b[a("vtp_queryKey").toString()] || "",
                        m =
                        b[a("vtp_ignoreEmptyQueryParam").toString()],
                        n;h ? xa(l) ? n = l : n = String(l).replace(/\s+/g, "").split(",") : n = [String(l)];
                    for (var p = 0; p < n.length; p++) {
                        var q = yj(e, "QUERY", void 0, void 0, n[p]);
                        if (void 0 != q && (!m || "" !== q)) {
                            f = q;
                            break a
                        }
                    }
                    f = void 0
                }
                else f = yj(e, d, "HOST" == d ? b[a("vtp_stripWww")] : void 0, "PATH" == d ? b[a("vtp_defaultPages")] : void 0);
                return f
            })
        }();
    Y.m.v = ["google"],
        function() {
            (function(a) {
                Y.__v = a;
                Y.__v.o = "v";
                Y.__v.isVendorTemplate = !0;
                Y.__v.priorityOverride = 0;
                Y.__v.isInfrastructure = !1;
                Y.__v.runInSiloedMode = !1
            })(function(a) {
                var b = a.vtp_name;
                if (!b || !b.replace) return !1;
                var c = Yu(b.replace(/\\\./g, "."), a.vtp_dataLayerVersion || 1),
                    d = void 0 !== c ? c : a.vtp_defaultValue;
                fv(d, "v", a.vtp_gtmEventId);
                return d
            })
        }();




    Y.m.gclidw = ["google"],
        function() {
            var a = ["aw", "dc", "gf", "ha", "gb"];
            (function(b) {
                Y.__gclidw = b;
                Y.__gclidw.o = "gclidw";
                Y.__gclidw.isVendorTemplate = !0;
                Y.__gclidw.priorityOverride = 100;
                Y.__gclidw.isInfrastructure = !1;
                Y.__gclidw.runInSiloedMode = !1
            })(function(b) {
                H(b.vtp_gtmOnSuccess);
                var c, d, e, f;
                b.vtp_enableCookieOverrides && (e = b.vtp_cookiePrefix, c = b.vtp_path, d = b.vtp_domain, f = b.vtp_cookieFlags);
                var h = {
                    prefix: e,
                    path: c,
                    domain: d,
                    flags: f
                };
                !b.vtp_enableCrossDomainFeature || b.vtp_enableCrossDomain && !1 === b.vtp_acceptIncoming ||
                    !b.vtp_enableCrossDomain && !bk() || (Tk(a, h), ok(h));
                Qk(h);
                Wk(["aw", "dc"], h);
                Am(h);
                if (b.vtp_enableCrossDomainFeature && b.vtp_enableCrossDomain && b.vtp_linkerDomains) {
                    var l = b.vtp_linkerDomains.toString().replace(/\s+/g, "").split(",");
                    Vk(a, l, b.vtp_urlPosition, !!b.vtp_formDecoration, h.prefix);
                    pk(gk(h.prefix), l, b.vtp_urlPosition, !!b.vtp_formDecoration, h);
                    pk("FPAU", l, b.vtp_urlPosition, !!b.vtp_formDecoration, h)
                }
                var m = Yu(L.g.ra);
                il({
                    s: qh(new fh(b.vtp_gtmEventId, b.vtp_gtmPriorityId)),
                    Pf: !1,
                    Ye: void 0 != m && !1 !== m,
                    xc: h,
                    Re: !0
                });
                b.vtp_enableUrlPassthrough && Yk(["aw", "dc", "gb"]);
                $k(["aw", "dc", "gb"])
            })
        }();

    Y.m.aev = ["google"],
        function() {
            function a(t, r, u, v, w) {
                w || (w = "element");
                var x = r + "." + u,
                    y;
                if (n.hasOwnProperty(x)) y = n[x];
                else {
                    var A = t[w];
                    if (A && (y = v(A), n[x] = y, p.push(x), 35 < p.length)) {
                        var B = p.shift();
                        delete n[B]
                    }
                }
                return y
            }

            function b(t, r, u) {
                var v = t[q[r]];
                return void 0 !== v ? v : u
            }

            function c(t, r) {
                if (!t) return !1;
                var u = d(Vu());
                xa(r) || (r = String(r || "").replace(/\s+/g, "").split(","));
                for (var v = [u], w = 0; w < r.length; w++) {
                    var x = r[w];
                    if (x.hasOwnProperty("is_regex"))
                        if (x.is_regex) try {
                            x = new RegExp(x.domain)
                        } catch (B) {
                            continue
                        } else x =
                            x.domain;
                    var y = d(t);
                    if (x instanceof RegExp) {
                        if (x.test(y)) return !1
                    } else {
                        var A = x;
                        if (0 != A.length) {
                            if (0 <= y.indexOf(A)) return !1;
                            v.push(d(A))
                        }
                    }
                }
                return !Py(t, v)
            }

            function d(t) {
                m.test(t) || (t = "http://" + t);
                return yj(Aj(t), "HOST", !0)
            }

            function e(t, r, u, v) {
                switch (t) {
                    case "SUBMIT_TEXT":
                        return a(r, u, "FORM." + t, f, "formSubmitElement") || v;
                    case "LENGTH":
                        var w = a(r, u, "FORM." + t, h);
                        return void 0 === w ? v : w;
                    case "INTERACTED_FIELD_ID":
                        return l(r, "id", v);
                    case "INTERACTED_FIELD_NAME":
                        return l(r, "name", v);
                    case "INTERACTED_FIELD_TYPE":
                        return l(r,
                            "type", v);
                    case "INTERACTED_FIELD_POSITION":
                        var x = r.interactedFormFieldPosition;
                        return void 0 === x ? v : x;
                    case "INTERACT_SEQUENCE_NUMBER":
                        var y = r.interactSequenceNumber;
                        return void 0 === y ? v : y;
                    default:
                        return v
                }
            }

            function f(t) {
                switch (t.tagName.toLowerCase()) {
                    case "input":
                        return cc(t, "value");
                    case "button":
                        return dc(t);
                    default:
                        return null
                }
            }

            function h(t) {
                if ("form" === t.tagName.toLowerCase() && t.elements) {
                    for (var r = 0, u = 0; u < t.elements.length; u++) Bu(t.elements[u]) && r++;
                    return r
                }
            }

            function l(t, r, u) {
                var v = t.interactedFormField;
                return v && cc(v, r) || u
            }
            var m = /^https?:\/\//i,
                n = {},
                p = [],
                q = {
                    ATTRIBUTE: "elementAttribute",
                    CLASSES: "elementClasses",
                    ELEMENT: "element",
                    ID: "elementId",
                    HISTORY_CHANGE_SOURCE: "historyChangeSource",
                    HISTORY_NEW_STATE: "newHistoryState",
                    HISTORY_NEW_URL_FRAGMENT: "newUrlFragment",
                    HISTORY_OLD_STATE: "oldHistoryState",
                    HISTORY_OLD_URL_FRAGMENT: "oldUrlFragment",
                    TARGET: "elementTarget"
                };
            (function(t) {
                Y.__aev = t;
                Y.__aev.o = "aev";
                Y.__aev.isVendorTemplate = !0;
                Y.__aev.priorityOverride = 0;
                Y.__aev.isInfrastructure = !1;
                Y.__aev.runInSiloedMode = !1
            })(function(t) {
                var r = t.vtp_gtmEventId,
                    u = t.vtp_defaultValue,
                    v = t.vtp_varType,
                    w = t.vtp_gtmCachedValues.gtm;
                switch (v) {
                    case "TAG_NAME":
                        var x = w.element;
                        return x && x.tagName || u;
                    case "TEXT":
                        return a(w, r, v, dc) || u;
                    case "URL":
                        var y;
                        a: {
                            var A = String(w.elementUrl || u || ""),
                                B = Aj(A),
                                D = String(t.vtp_component || "URL");
                            switch (D) {
                                case "URL":
                                    y = A;
                                    break a;
                                case "IS_OUTBOUND":
                                    y = c(A, t.vtp_affiliatedDomains);
                                    break a;
                                default:
                                    y = yj(B, D, t.vtp_stripWww, t.vtp_defaultPages, t.vtp_queryKey)
                            }
                        }
                        return y;
                    case "ATTRIBUTE":
                        var I;
                        if (void 0 ===
                            t.vtp_attribute) I = b(w, v, u);
                        else {
                            var J = w.element;
                            I = J && cc(J, t.vtp_attribute) || u || ""
                        }
                        return I;
                    case "MD":
                        var E = t.vtp_mdValue,
                            G = a(w, r, "MD", Nu);
                        return E && G ? Qu(G, E) || u : G || u;
                    case "FORM":
                        return e(String(t.vtp_component || "SUBMIT_TEXT"), w, r, u);
                    default:
                        var M = b(w, v, u);
                        fv(M, "aev", t.vtp_gtmEventId);
                        return M
                }
            })
        }();








    Y.m.ua = ["google"],
        function() {
            function a(m, n) {
                for (var p in m)
                    if (!l[p] && m.hasOwnProperty(p)) {
                        var q = h[p] ? Fa(m[p]) : m[p];
                        "anonymizeIp" != p || q || (q = void 0);
                        n[p] = q
                    }
            }

            function b(m) {
                var n = {};
                m.vtp_gaSettings && z(Qy(m.vtp_gaSettings.vtp_fieldsToSet, "fieldName", "value"), n);
                z(Qy(m.vtp_fieldsToSet, "fieldName", "value"), n);
                Fa(n.urlPassthrough) && (n._useUp = !0);
                m.vtp_transportUrl && (n._x_19 = m.vtp_transportUrl);
                return n
            }

            function c(m, n) {
                return void 0 === n ? n : m(n)
            }

            function d(m, n, p) {}

            function e(m, n) {
                if (!f) {
                    var p = m.vtp_useDebugVersion ? "u/analytics_debug.js" : "analytics.js";
                    m.vtp_useInternalVersion && !m.vtp_useDebugVersion && (p = "internal/" + p);
                    f = !0;
                    var q = m.vtp_gtmOnFailure,
                        t = Ge || Ie ? Ml(n._x_19, "/analytics.js") : void 0,
                        r = ol("https:", "http:", "//www.google-analytics.com/" + p, n && !!n.forceSSL);
                    V("analytics.js" === p && t ? t : r, function() {
                            var u = Hr();
                            u && u.loaded || q();
                        },
                        q)
                }
            }
            var f, h = {
                    allowAnchor: !0,
                    allowLinker: !0,
                    alwaysSendReferrer: !0,
                    anonymizeIp: !0,
                    cookieUpdate: !0,
                    exFatal: !0,
                    forceSSL: !0,
                    javaEnabled: !0,
                    legacyHistoryImport: !0,
                    nonInteraction: !0,
                    useAmpClientId: !0,
                    useBeacon: !0,
                    storeGac: !0,
                    allowAdFeatures: !0,
                    allowAdPersonalizationSignals: !0,
                    _cd2l: !0
                },
                l = {
                    urlPassthrough: !0
                };
            (function(m) {
                Y.__ua = m;
                Y.__ua.o = "ua";
                Y.__ua.isVendorTemplate = !0;
                Y.__ua.priorityOverride = 0;
                Y.__ua.isInfrastructure = !1;
                Y.__ua.runInSiloedMode = !1
            })(function(m) {
                function n() {
                    if (m.vtp_doubleClick || "DISPLAY_FEATURES" == m.vtp_advertisingFeaturesType) v.displayfeatures = !0
                }
                var p = {},
                    q = {},
                    t = {};
                if (m.vtp_gaSettings) {
                    var r = m.vtp_gaSettings;
                    z(Qy(r.vtp_contentGroup, "index", "group"), p);
                    z(Qy(r.vtp_dimension, "index", "dimension"), q);
                    z(Qy(r.vtp_metric, "index", "metric"), t);
                    var u = z(r);
                    u.vtp_fieldsToSet = void 0;
                    u.vtp_contentGroup = void 0;
                    u.vtp_dimension = void 0;
                    u.vtp_metric = void 0;
                    m = z(m, u)
                }
                z(Qy(m.vtp_contentGroup, "index", "group"), p);
                z(Qy(m.vtp_dimension, "index",
                    "dimension"), q);
                z(Qy(m.vtp_metric, "index", "metric"), t);
                var v = b(m),
                    w = String(m.vtp_trackingId || ""),
                    x = "",
                    y = "",
                    A = "";
                m.vtp_setTrackerName && "string" == typeof m.vtp_trackerName ? "" !== m.vtp_trackerName && (A = m.vtp_trackerName, y = A + ".") : (A = "gtm" + Se(), y = A + ".");
                var B = function(Z, U) {
                    for (var Aa in U) U.hasOwnProperty(Aa) && (v[Z + Aa] = U[Aa])
                };
                B("contentGroup", p);
                B("dimension", q);
                B("metric", t);
                m.vtp_enableEcommerce && (x = m.vtp_gtmCachedValues.event, v.gtmEcommerceData = d(m, v, x));
                if ("TRACK_EVENT" === m.vtp_trackType) x = "track_event",
                    n(), v.eventCategory = String(m.vtp_eventCategory), v.eventAction = String(m.vtp_eventAction), v.eventLabel = c(String, m.vtp_eventLabel), v.value = c(Ea, m.vtp_eventValue);
                else if ("TRACK_PAGEVIEW" == m.vtp_trackType) {
                    if (x = L.g.jc, n(), "DISPLAY_FEATURES_WITH_REMARKETING_LISTS" == m.vtp_advertisingFeaturesType && (v.remarketingLists = !0), m.vtp_autoLinkDomains) {
                        var D = {};
                        D[L.g.T] = m.vtp_autoLinkDomains;
                        D.use_anchor = m.vtp_useHashAutoLink;
                        D[L.g.Mb] = m.vtp_decorateFormsAutoLink;
                        v[L.g.Ha] = D
                    }
                } else "TRACK_SOCIAL" === m.vtp_trackType ?
                    (x = "track_social", v.socialNetwork = String(m.vtp_socialNetwork), v.socialAction = String(m.vtp_socialAction), v.socialTarget = String(m.vtp_socialActionTarget)) : "TRACK_TIMING" == m.vtp_trackType && (x = "timing_complete", v.eventCategory = String(m.vtp_timingCategory), v.timingVar = String(m.vtp_timingVar), v.value = Ea(m.vtp_timingValue), v.eventLabel = c(String, m.vtp_timingLabel));
                m.vtp_enableRecaptcha && (v.enableRecaptcha = !0);
                m.vtp_enableLinkId && (v.enableLinkId = !0);
                var I = {};
                a(v, I);
                v.name || (I.gtmTrackerName = A);
                I.gaFunctionName =
                    m.vtp_functionName;
                void 0 !== m.vtp_nonInteraction && (I.nonInteraction = m.vtp_nonInteraction);
                var J = qh(ph(oh(nh(gh(new fh(m.vtp_gtmEventId, m.vtp_gtmPriorityId), I), m.vtp_gtmOnSuccess), m.vtp_gtmOnFailure), !0));
                Ew(w, x, Date.now(), J);
                var E = Jr(m.vtp_functionName);
                if (ua(E)) {
                    var G = function(Z) {
                        var U = [].slice.call(arguments, 0);
                        U[0] = y + U[0];
                        E.apply(window, U)
                    };
                    if ("TRACK_TRANSACTION" == m.vtp_trackType) {} else if ("DECORATE_LINK" == m.vtp_trackType) {} else if ("DECORATE_FORM" == m.vtp_trackType) {} else if ("TRACK_DATA" == m.vtp_trackType) {}
                    e(m, v)
                } else H(m.vtp_gtmOnFailure)
            })
        }();


    Y.m.gas = ["google"],
        function() {
            (function(a) {
                Y.__gas = a;
                Y.__gas.o = "gas";
                Y.__gas.isVendorTemplate = !0;
                Y.__gas.priorityOverride = 0;
                Y.__gas.isInfrastructure = !1;
                Y.__gas.runInSiloedMode = !1
            })(function(a) {
                var b = z(a),
                    c = b;
                c[oc.ma] = null;
                c[oc.Kf] = null;
                var d = b = c;
                d.vtp_fieldsToSet = d.vtp_fieldsToSet || [];
                var e = d.vtp_cookieDomain;
                void 0 !== e && (d.vtp_fieldsToSet.push({
                    fieldName: "cookieDomain",
                    value: e
                }), delete d.vtp_cookieDomain);
                return b
            })
        }();
    Y.m.awct = ["google"],
        function() {
            function a(b, c, d) {
                return function(e, f, h) {
                    c[e] = "DATA_LAYER" === d ? Yu(h) : b[f]
                }
            }(function(b) {
                Y.__awct = b;
                Y.__awct.o = "awct";
                Y.__awct.isVendorTemplate = !0;
                Y.__awct.priorityOverride = 0;
                Y.__awct.isInfrastructure = !1;
                Y.__awct.runInSiloedMode = !1
            })(function(b) {
                var c = !b.hasOwnProperty("vtp_enableConversionLinker") || !!b.vtp_enableConversionLinker,
                    d = !!b.vtp_enableEnhancedConversions || !!b.vtp_enableEnhancedConversion,
                    e = Qy(b.vtp_customVariables, "varName", "value") || {},
                    f = {},
                    h = (f[L.g.fa] = b.vtp_conversionValue ||
                        0, f[L.g.sa] = b.vtp_currencyCode, f[L.g.wa] = b.vtp_orderId, f[L.g.Ma] = b.vtp_conversionCookiePrefix, f[L.g.Da] = c, f[L.g.Ud] = d, f[L.g.ra] = Yu(L.g.ra), f[L.g.aa] = Yu("developer_id"), f);
                h[L.g.Ca] = Yu(L.g.Ca), h[L.g.X] = Yu(L.g.X), h[L.g.Ib] = Yu(L.g.Ib), h[L.g.Oa] = Yu(L.g.Oa);
                b.vtp_rdp && (h[L.g.Nb] = !0);
                if (b.vtp_enableCustomParams)
                    for (var l in e) te.hasOwnProperty(l) || (h[l] = e[l]);
                if (b.vtp_enableProductReporting) {
                    var m = a(b, h, b.vtp_productReportingDataSource);
                    m(L.g.Yd, "vtp_awMerchantId", "aw_merchant_id");
                    m(L.g.Wd, "vtp_awFeedCountry", "aw_feed_country");
                    m(L.g.Xd, "vtp_awFeedLanguage", "aw_feed_language");
                    m(L.g.Vd, "vtp_discount", "discount");
                    m(L.g.Z, "vtp_items", "items")
                }
                b.vtp_enableShippingData && (h[L.g.bd] = b.vtp_deliveryPostalCode, h[L.g.ee] = b.vtp_estimatedDeliveryDate, h[L.g.nc] = b.vtp_deliveryCountry, h[L.g.Sc] = b.vtp_shippingFee);
                b.vtp_transportUrl && (h[L.g.Pb] = b.vtp_transportUrl);
                if (b.vtp_enableNewCustomerReporting) {
                    var n = a(b, h, b.vtp_newCustomerReportingDataSource);
                    n(L.g.Wc, "vtp_awNewCustomer", "new_customer");
                    n(L.g.Zd, "vtp_awCustomerLTV", "customer_lifetime_value")
                }
                var p;
                a: {
                    if (b.vtp_enableEnhancedConversion) {
                        var q = b.vtp_cssProvidedEnhancedConversionValue || b.vtp_enhancedConversionObject;
                        if (q) {
                            p = {
                                enhanced_conversions_mode: "manual",
                                enhanced_conversions_manual_var: q
                            };
                            break a
                        }
                    }
                    p = void 0
                }
                var t = p;
                if (t) {
                    var r = {};
                    h[L.g.de] = (r[b.vtp_conversionLabel] = t, r)
                }
                var u = "AW-" + b.vtp_conversionId,
                    v = u + "/" + b.vtp_conversionLabel;
                if (P(46)) {
                    Qq(u, b.vtp_transportUrl, {
                        source: 7,
                        fromContainerExecution: !0,
                        siloed: !0
                    });
                    var w = {},
                        x = {
                            eventMetadata: (w.hit_type_override = "conversion", w),
                            noGtmEvent: !0,
                            isGtmEvent: !0,
                            onSuccess: b.vtp_gtmOnSuccess,
                            onFailure: b.vtp_gtmOnFailure
                        };
                    qs(ns(og(v), L.g.oa, h), b.vtp_gtmEventId, x)
                } else {
                    var y = qh(ph(oh(nh(gh(new fh(b.vtp_gtmEventId, b.vtp_gtmPriorityId), h), b.vtp_gtmOnSuccess), b.vtp_gtmOnFailure), !0));
                    y.eventMetadata.hit_type_override = "conversion";
                    Iv(v, L.g.oa, Date.now(), y)
                }
            })
        }();






    var lA = {};
    lA.dataLayer = Ze;
    lA.callback = function(a) {
        Pe.hasOwnProperty(a) && ua(Pe[a]) && Pe[a]();
        delete Pe[a]
    };
    lA.bootstrap = 0;
    lA._spx = !1;

    function mA() {
        ye[tg()] = ye[tg()] || lA;
        zg();
        Dg() || k(Eg(), function(a, b) {
            Qq(a, b.transportUrl, b.context);
            K(92)
        });
        Na(Qe, Y.m);
        P(67) && vg(Bg());
        Wc = fd
    }
    (function(a) {
        function b() {
            m = F.documentElement.getAttribute("data-tag-assistant-present");
            Qt(m) && (l = h.Oj)
        }
        if (!C["__TAGGY_INSTALLED"]) {
            var c = !1;
            if (F.referrer) {
                var d = Aj(F.referrer);
                c = "cct.google" === xj(d, "host")
            }
            if (!c) {
                var e = Ii("googTaggyReferrer");
                c = e.length && e[0].length
            }
            c && (C["__TAGGY_INSTALLED"] = !0, Xb("https://cct.google/taggy/agent.js"))
        }
        if (Ke) a();
        else {
            var f = function(u) {
                    var v = "GTM",
                        w = "GTM";
                    Ee ? (v = "OGT", w = "GTAG") : Ke && (w = v = "OPT");
                    var x = C["google.tagmanager.debugui2.queue"];
                    x || (x = [],
                        C["google.tagmanager.debugui2.queue"] = x, Xb("https://" + xe.Gc + "/debug/bootstrap?id=" + mg.ctid + "&src=" + w + "&cond=" + u + "&gtm=" + cj()));
                    var y = {
                        messageType: "CONTAINER_STARTING",
                        data: {
                            scriptSource: Rb,
                            containerProduct: v,
                            debug: !1,
                            id: mg.ctid,
                            targetRef: {
                                ctid: mg.ctid,
                                isDestination: kg.nd
                            },
                            aliases: ng(),
                            destinations: qg()
                        }
                    };
                    y.data.resume = function() {
                        a()
                    };
                    xe.Ri && (y.data.initialPublish = !0);
                    x.push(y)
                },
                h = {
                    Fm: 1,
                    Pj: 2,
                    dk: 3,
                    Ti: 4,
                    Oj: 5
                },
                l = void 0,
                m = void 0,
                n = yj(C.location, "query", !1, void 0, "gtm_debug");
            Qt(n) && (l = h.Pj);
            if (!l && F.referrer) {
                var p = Aj(F.referrer);
                "tagassistant.google.com" === xj(p, "host") && (l = h.dk)
            }
            if (!l) {
                var q = Ii("__TAG_ASSISTANT");
                q.length && q[0].length && (l = h.Ti)
            }
            l || b();
            if (!l && Rt(m)) {
                var t = function() {
                        if (r) return !0;
                        r = !0;
                        b();
                        l && Rb ? f(l) : a()
                    },
                    r = !1;
                ac(F, "TADebugSignal", function() {
                    t()
                }, !1);
                C.setTimeout(function() {
                    t()
                }, 200)
            } else l && Rb ? f(l) : a()
        }
    })(function() {
        try {
            xg();
            if (P(24)) {}
            zf().C();
            ji();
            var a = ug();
            if (hg().canonical[a]) {
                var b =
                    ye.zones;
                b && b.unregisterChild(pg());
            } else {
                (P(7) || P(8) || P(19) || P(16)) && pj();
                Nq();
                for (var c = data.resource || {}, d = c.macros || [], e = 0; e < d.length; e++) Mc.push(d[e]);
                for (var f = c.tags || [], h = 0; h < f.length; h++) Pc.push(f[h]);
                for (var l = c.predicates || [], m = 0; m < l.length; m++) Oc.push(l[m]);
                for (var n = c.rules || [], p = 0; p < n.length; p++) {
                    for (var q = n[p],
                            t = {}, r = 0; r < q.length; r++) {
                        var u = q[r][0];
                        t[u] = Array.prototype.slice.call(q[r], 1);
                        "if" !== u && "unless" !== u || Vc(t[u])
                    }
                    Nc.push(t)
                }
                Rc = Y;
                Sc = Dv;
                mA();
                if (P(35) && !Ke) {
                    for (var v = qf["7"], w = v ? v.split("|") : [], x = {}, y = 0; y < w.length; y++) x[w[y]] = !0;
                    for (var A = 0; A < Xf.length; A++) {
                        var B = Xf[A],
                            D = x[B] ? "granted" : "denied";
                        Ef().implicit(B, D)
                    }
                }
                Pt();
                Rq = !1;
                mr = 0;
                if ("interactive" == F.readyState && !F.createEventObject || "complete" == F.readyState) tr();
                else {
                    ac(F, "DOMContentLoaded", tr);
                    ac(F, "readystatechange", tr);
                    if (F.createEventObject && F.documentElement.doScroll) {
                        var I = !0;
                        try {
                            I = !C.frameElement
                        } catch (Q) {}
                        I && ur()
                    }
                    ac(C, "load", tr)
                }
                dt = !1;
                "complete" === F.readyState ? ft() : ac(C, "load", ft);
                Ng && (Ig($g), C.setInterval(Zg, 864E5));
                Ig(Fv);
                Ig(Ur);
                Ig(op);
                Ig(cm);
                Ig(es);
                Ig(Tl);
                Ig(ej);
                Ig(Rl);
                Ig(as);
                P(44) && Ig(Xr);
                lu();
                pf(1);
                Bs();
                Oe = Ka();
                lA.bootstrap = Oe;
                if (P(24)) {}
            }
        } catch (Q) {
            if (pf(4),
                Ng) {
                var M = Ug(!0, !0);
                $b(M)
            }
        }
    });

})()